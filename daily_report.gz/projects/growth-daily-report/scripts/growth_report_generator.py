#!/usr/bin/env python3
"""
增长日报生成器 - 整合版

功能：
- 整合三个分析部分到一个脚本中
- Axon基础数据监控分析【T-3、T-2、T-1】
- 内部与Axon平台单日对比分析【T-2】
- 内部与Axon平台对比分析【滚动7日汇总】
- 统一数据聚合逻辑：group by campaign, dt，指标加权聚合
- 输出Markdown表格格式，直接用于飞书文档

数据来源：
- 第一部分：~/.openclaw/workspace/exports/axon_monitor_cache.csv
- 第二部分：axon_monitor_cache.csv + ~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite
- 第三部分：~/.openclaw/workspace/data_analysis/roi_predict/data/roi_predict_campaign_distribute_roi1_180_last4m.sqlite（不含actual的ROI）+ ~/.openclaw/workspace/exports/axon_roi_predict.csv

作者：Growth Daily Report Skill
日期：2025-03-09
"""

import sqlite3
import csv
import json
import argparse
import sys
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict


# ============================================================================
# 基础工具函数
# ============================================================================

def safe_float(value: Any, default: float = 0.0) -> float:
    """安全转换为浮点数"""
    try:
        return float(value) if value is not None else default
    except (ValueError, TypeError):
        return default


def safe_str(value: Any, default: str = "") -> str:
    """安全转换为字符串"""
    try:
        return str(value) if value is not None else default
    except (ValueError, TypeError):
        return default


def find_column_index(headers: List[str], keywords: List[str]) -> Optional[int]:
    """
    查找列索引（支持模糊匹配）

    Args:
        headers: 列名列表
        keywords: 关键词列表（按优先级排序）

    Returns:
        列索引，未找到返回None
    """
    for i, header in enumerate(headers):
        header_lower = header.lower()
        header_clean = re.sub(r'[_\s\-]', '', header_lower)

        for keyword in keywords:
            keyword_lower = keyword.lower()
            keyword_clean = re.sub(r'[_\s\-]', '', keyword_lower)

            # 精确匹配或包含匹配
            if header_clean == keyword_clean or keyword_clean in header_clean:
                return i

    return None


def normalize_column_name(name: str) -> str:
    """
    规范化列名，用于更好的匹配

    Args:
        name: 原始列名

    Returns:
        规范化后的列名
    """
    # 移除特殊字符，统一大小写
    normalized = re.sub(r'[_\s\-]', '', name.lower())
    return normalized


def find_column_by_patterns(headers: List[str], patterns: List[str]) -> Optional[int]:
    """
    通过正则表达式模式查找列索引

    Args:
        headers: 列名列表
        patterns: 正则表达式模式列表（按优先级排序）

    Returns:
        列索引，未找到返回None
    """
    for pattern_str in patterns:
        pattern = re.compile(pattern_str, re.IGNORECASE)
        for i, header in enumerate(headers):
            if pattern.search(header):
                return i
    return None


def auto_detect_columns(headers: List[str]) -> Dict[str, Optional[int]]:
    """
    自动检测列索引（智能匹配）

    Args:
        headers: 列名列表

    Returns:
        列名到索引的映射字典
    """
    columns = {
        'campaign': None,
        'date': None,
        'spend': None,
        'conversions': None,
        'roi1': None,
        'roi3': None,
        'roi7': None,
        'roi14_predict': None,
        'roi30_predict': None,
        'roi45_predict': None,
        'roi60_predict': None,
        'roi120_predict': None,
        'roi180_predict': None
    }

    # 按优先级检测
    for i, header in enumerate(headers):
        header_lower = header.lower()

        # 检测campaign
        if columns['campaign'] is None:
            if re.search(r'campaign|camp|活动|ad.?group|推广组', header_lower):
                columns['campaign'] = i

        # 检测date
        if columns['date'] is None:
            if re.search(r'日期|date|dt|t|ts|datetime|time|day', header_lower):
                columns['date'] = i

        # 检测spend
        if columns['spend'] is None:
            if re.search(r'消耗|spend|cost|花费|支出|expense', header_lower):
                columns['spend'] = i

        # 检测conversions
        if columns['conversions'] is None:
            if re.search(r'转化|激活|conversion|act.?count|install|user', header_lower):
                columns['conversions'] = i

        # 检测ROI相关列
        # 预测列优先检测
        if 'actual' not in header_lower and 'predict' in header_lower or '预测' in header_lower:
            if columns['roi14_predict'] is None and re.search(r'14|14d|14.?day', header_lower):
                columns['roi14_predict'] = i
            elif columns['roi30_predict'] is None and re.search(r'30|30d|30.?day', header_lower):
                columns['roi30_predict'] = i
            elif columns['roi45_predict'] is None and re.search(r'45|45d|45.?day', header_lower):
                columns['roi45_predict'] = i
            elif columns['roi60_predict'] is None and re.search(r'60|60d|60.?day', header_lower):
                columns['roi60_predict'] = i
            elif columns['roi120_predict'] is None and re.search(r'120|120d|120.?day', header_lower):
                columns['roi120_predict'] = i
            elif columns['roi180_predict'] is None and re.search(r'180|180d|180.?day', header_lower):
                columns['roi180_predict'] = i

        # 检测标准ROI列（排除预测列）
        if 'predict' not in header_lower and 'actual' not in header_lower:
            if columns['roi1'] is None and re.search(r'roi.*1|1.*roi|day1|首日', header_lower):
                columns['roi1'] = i
            elif columns['roi3'] is None and re.search(r'roi.*3|3.*roi|day3', header_lower):
                columns['roi3'] = i
            elif columns['roi7'] is None and re.search(r'roi.*7|7.*roi|day7', header_lower):
                columns['roi7'] = i

    return columns


def aggregate_by_campaign_dt(rows: List[Dict[str, Any]], date_range: Optional[List[datetime]] = None) -> List[Dict[str, Any]]:
    """
    按campaign和dt分组聚合数据（加权聚合）

    Args:
        rows: 原始数据列表
        date_range: 日期范围过滤（可选）

    Returns:
        聚合后的数据
    """
    # 日期过滤
    if date_range:
        rows = [row for row in rows if row['date'] in date_range]

    # 分组聚合
    groups = defaultdict(lambda: {
        'spend': 0.0,
        'conversions': 0.0,
        'weighted_roi1': 0.0,
        'weighted_roi3': 0.0,
        'weighted_roi7': 0.0,
    })

    for row in rows:
        key = (row['campaign'], row['date'])
        groups[key]['spend'] += row.get('spend', 0.0)
        groups[key]['conversions'] += row.get('conversions', 0.0)

        # ROI加权（权重为消耗）
        if 'roi1' in row:
            groups[key]['weighted_roi1'] += row['roi1'] * row.get('spend', 0.0)
        if 'roi3' in row:
            groups[key]['weighted_roi3'] += row['roi3'] * row.get('spend', 0.0)
        if 'roi7' in row:
            groups[key]['weighted_roi7'] += row['roi7'] * row.get('spend', 0.0)

    # 计算聚合指标
    aggregated = []
    for (campaign, date), values in groups.items():
        spend = values['spend']
        conversions = values['conversions']

        # 计算CPA
        cpa = spend / conversions if conversions > 0 else 0.0

        # 计算加权平均ROI
        roi1 = values['weighted_roi1'] / spend if spend > 0 else 0.0
        roi3 = values['weighted_roi3'] / spend if spend > 0 else 0.0
        roi7 = values['weighted_roi7'] / spend if spend > 0 else 0.0

        result = {
            'campaign': campaign,
            'date': date,
            'conversions': int(conversions),
            'spend': round(spend, 2),
            'cpa': round(cpa, 2),
            'roi1': round(roi1, 2)
        }

        if values['weighted_roi3'] > 0:
            result['roi3'] = round(roi3, 2)
        if values['weighted_roi7'] > 0:
            result['roi7'] = round(roi7, 2)

        aggregated.append(result)

    return aggregated


def sort_campaign_dt(data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    排序数据：campaign升序、dt倒序

    Args:
        data: 聚合后的数据

    Returns:
        排序后的数据
    """
    return sorted(data, key=lambda x: (x['campaign'], -x['date'].timestamp()))


# ============================================================================
# 第一部分：Axon基础数据监控分析【T-3、T-2、T-1】
# ============================================================================

class AxonMonitorAnalyzer:
    """Axon监控数据分析器（T-3、T-2、T-1）"""

    def __init__(self, cache_path: str, target_date: str):
        self.cache_path = Path(cache_path)
        self.target_date_obj = datetime.strptime(target_date, "%Y-%m-%d")
        self.date_range = [self.target_date_obj - timedelta(days=i) for i in [1, 2, 3]]  # T-1, T-2, T-3

    def load_data(self) -> List[Dict[str, Any]]:
        """加载CSV数据"""
        if not self.cache_path.exists():
            print(f"警告：Axon缓存文件不存在: {self.cache_path}", file=sys.stderr)
            return []

        rows = []
        try:
            with open(self.cache_path, 'r', encoding='utf-8-sig') as f:
                reader = csv.reader(f)
                headers = next(reader)

                # 查找列索引
                campaign_col = find_column_index(headers, [
                    'campaign', 'camp', '活动', 'campaign_name', 
                    'ad_group', '广告组', '推广组', 'group_name'
                ])
                date_col = find_column_index(headers, [
                    '日期', 'date', 'dt', 't', 'ts', 
                    '日期时间', 'datetime', 'time', 'day'
                ])
                spend_col = find_column_index(headers, [
                    '消耗', 'spend', 'cost', '花费', 
                    '支出', 'expense', '现金消耗', 'cost_amount'
                ])
                conversions_col = find_column_index(headers, [
                    '转化', '激活', 'conversion', 'act_count', 
                    'active_count', 'installs', 'user_count'
                ])
                roi1_col = find_column_index(headers, [
                    'roi1', 'roi_1', '首日roi', '1日roi', '1日ROI', 
                    'day1_roi', 'roi_day1', 'roas1'
                ])

                print(f"Axon监控 - 列索引: campaign={campaign_col}, date={date_col}, spend={spend_col}, conversions={conversions_col}, roi1={roi1_col}", file=sys.stderr)

                # 读取数据
                for row in reader:
                    try:
                        # 确保行长度足够
                        max_col = max([c for c in [campaign_col, date_col, spend_col, conversions_col, roi1_col] if c is not None], default=0)
                        if len(row) <= max_col:
                            continue

                        campaign = safe_str(row[campaign_col]) if campaign_col is not None else "Unknown"

                        # 解析日期
                        date_str = safe_str(row[date_col]) if date_col is not None else ""
                        date_str = date_str.split()[0]
                        try:
                            date_obj = datetime.strptime(date_str, "%Y-%m-%d")
                        except ValueError:
                            continue  # 日期解析失败，跳过该行

                        # 只保留T-3到T-1的数据
                        if date_obj in self.date_range:
                            spend = safe_float(row[spend_col]) if spend_col is not None else 0.0
                            conversions = safe_float(row[conversions_col]) if conversions_col is not None else 0.0
                            roi1 = safe_float(row[roi1_col]) if roi1_col is not None else 0.0

                            rows.append({
                                'campaign': campaign,
                                'date': date_obj,
                                'spend': spend,
                                'conversions': conversions,
                                'roi1': roi1
                            })

                    except (ValueError, IndexError) as e:
                        print(f"Axon监控 - 跳过无效行: {e}", file=sys.stderr)
                        continue

        except Exception as e:
            print(f"读取Axon缓存文件失败: {e}", file=sys.stderr)
            return []

        print(f"Axon监控 - 加载了 {len(rows)} 条数据", file=sys.stderr)
        return rows

    def analyze(self) -> Dict[str, Any]:
        """执行分析"""
        # 加载数据
        rows = self.load_data()
        if not rows:
            return {'exists': False, 'data': [], 'markdown_table': '', 'summary': {}}

        # 聚合数据
        aggregated = aggregate_by_campaign_dt(rows, self.date_range)

        # 排序
        sorted_data = sort_campaign_dt(aggregated)

        # 生成Markdown表格
        markdown_table = self.generate_markdown_table(sorted_data)

        # 计算汇总指标
        summary = self.calculate_summary(sorted_data)

        return {
            'exists': True,
            'data': sorted_data,
            'markdown_table': markdown_table,
            'summary': summary
        }

    def generate_markdown_table(self, data: List[Dict[str, Any]]) -> str:
        """生成Markdown表格"""
        if not data:
            return "| campaign | dt | 激活量 | 消耗 | CPA | 首日ROI |\n|----------|----|--------|------|-----|---------|\n| 无数据 | | | | | |"

        table = "| campaign | dt | 激活量 | 消耗 | CPA | 首日ROI |\n"
        table += "|----------|----|--------|------|-----|---------|\n"

        for row in data:
            date_str = row['date'].strftime("%Y-%m-%d")
            table += f"| {row['campaign']} | {date_str} | {row['conversions']} | {row['spend']:.2f} | {row['cpa']:.2f} | {row['roi1']:.2f} |\n"

        return table

    def calculate_summary(self, data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """计算汇总指标"""
        summary = {
            'total_spend': sum(row['spend'] for row in data),
            'total_conversions': sum(row['conversions'] for row in data),
            'avg_cpa': 0.0,
            'avg_roi1': 0.0
        }

        if summary['total_conversions'] > 0:
            summary['avg_cpa'] = summary['total_spend'] / summary['total_conversions']

        if summary['total_spend'] > 0:
            summary['avg_roi1'] = sum(row['roi1'] * row['spend'] for row in data) / summary['total_spend']

        summary['total_spend'] = round(summary['total_spend'], 2)
        summary['avg_cpa'] = round(summary['avg_cpa'], 2)
        summary['avg_roi1'] = round(summary['avg_roi1'], 2)

        return summary


# ============================================================================
# 第二部分：内部与Axon平台单日对比分析【T-2】
# ============================================================================

class PlatformDailyComparator:
    """平台单日对比分析器（T-2）"""

    def __init__(self, axon_cache_path: str, internal_db_path: str, target_date: str):
        self.axon_cache_path = Path(axon_cache_path)
        self.internal_db_path = Path(internal_db_path)
        self.target_date_obj = datetime.strptime(target_date, "%Y-%m-%d")
        self.target_date_minus_2 = self.target_date_obj - timedelta(days=2)  # T-2

    def load_axon_data(self) -> List[Dict[str, Any]]:
        """加载Axon数据"""
        if not self.axon_cache_path.exists():
            print(f"警告：Axon缓存文件不存在: {self.axon_cache_path}", file=sys.stderr)
            return []

        rows = []
        try:
            with open(self.axon_cache_path, 'r', encoding='utf-8-sig') as f:
                reader = csv.reader(f)
                headers = next(reader)

                campaign_col = find_column_index(headers, ['campaign', 'camp', '活动'])
                date_col = find_column_index(headers, ['日期', 'date', 'dt', 't'])
                spend_col = find_column_index(headers, ['消耗', 'spend', 'cost', '花费'])
                conversions_col = find_column_index(headers, ['转化', '激活', 'conversion'])
                roi1_col = find_column_index(headers, ['roi1', 'roi_1', '首日roi'])

                print(f"平台单日对比 - Axon列索引: campaign={campaign_col}, date={date_col}, spend={spend_col}, conversions={conversions_col}, roi1={roi1_col}", file=sys.stderr)

                for row in reader:
                    try:
                        # 确保行长度足够
                        max_col = max([c for c in [campaign_col, date_col, spend_col, conversions_col, roi1_col] if c is not None], default=0)
                        if len(row) <= max_col:
                            continue

                        # 解析日期
                        date_str = safe_str(row[date_col]) if date_col is not None else ""
                        date_str = date_str.split()[0]
                        try:
                            date_obj = datetime.strptime(date_str, "%Y-%m-%d")
                        except ValueError:
                            continue  # 日期解析失败，跳过该行

                        # 只保留T-2的数据
                        if date_obj == self.target_date_minus_2:
                            rows.append({
                                'campaign': safe_str(row[campaign_col]) if campaign_col is not None else "Unknown",
                                'platform': 'Axon',
                                'spend': safe_float(row[spend_col]) if spend_col is not None else 0.0,
                                'conversions': safe_float(row[conversions_col]) if conversions_col is not None else 0.0,
                                'roi1': safe_float(row[roi1_col]) if roi1_col is not None else 0.0
                            })

                    except (ValueError, IndexError) as e:
                        print(f"平台单日对比 - Axon跳过无效行: {e}", file=sys.stderr)
                        continue

        except Exception as e:
            print(f"读取Axon缓存文件失败: {e}", file=sys.stderr)

        print(f"平台单日对比 - Axon加载了 {len(rows)} 条数据", file=sys.stderr)
        return rows

    def load_internal_data(self) -> List[Dict[str, Any]]:
        """加载内部数据"""
        if not self.internal_db_path.exists():
            print(f"警告：内部数据库不存在: {self.internal_db_path}", file=sys.stderr)
            return []

        rows = []
        try:
            conn = sqlite3.connect(str(self.internal_db_path))
            cursor = conn.cursor()

            # 查询表结构
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()

            print(f"平台单日对比 - 内部数据库表: {[t[0] for t in tables]}", file=sys.stderr)

            for table_info in tables:
                table_name = table_info[0]

                # 查询列信息
                cursor.execute(f"PRAGMA table_info({table_name})")
                columns_info = cursor.fetchall()
                headers = [col[1] for col in columns_info]

                # 查找关键列
                campaign_col = find_column_index(headers, [
                    'campaign', 'camp', '活动', 'campaign_name', 
                    'ad_group', '广告组', '推广组', 'group_name'
                ])
                date_col = find_column_index(headers, [
                    '日期', 'date', 'dt', 't', 'ts', 
                    '日期时间', 'datetime', 'time', 'day'
                ])
                spend_col = find_column_index(headers, [
                    '消耗', 'spend', 'cost', '花费', 
                    '支出', 'expense', '现金消耗', 'cost_amount'
                ])
                conversions_col = find_column_index(headers, [
                    '转化', '激活', 'conversion', 'act_count', 
                    'active_count', 'installs', 'user_count'
                ])
                roi1_col = find_column_index(headers, [
                    'roi1', 'roi_1', '首日roi', '1日roi', '1日ROI', 
                    'day1_roi', 'roi_day1', 'roas1'
                ])

                if campaign_col is None or spend_col is None:
                    continue

                print(f"平台单日对比 - 内部表[{table_name}]列索引: campaign={campaign_col}, date={date_col}, spend={spend_col}, conversions={conversions_col}, roi1={roi1_col}", file=sys.stderr)

                # 查询数据
                query_cols = []
                if campaign_col is not None:
                    query_cols.append(f"\"{headers[campaign_col]}\" as campaign")
                if date_col is not None:
                    query_cols.append(f"\"{headers[date_col]}\" as dt")
                if spend_col is not None:
                    query_cols.append(f"\"{headers[spend_col]}\" as spend")
                if conversions_col is not None:
                    query_cols.append(f"\"{headers[conversions_col]}\" as conversions")
                if roi1_col is not None:
                    query_cols.append(f"\"{headers[roi1_col]}\" as roi1")

                query = f"SELECT {', '.join(query_cols)} FROM {table_name}"
                cursor.execute(query)
                results = cursor.fetchall()

                for result in results:
                    try:
                        # 安全提取日期，处理可能的None值
                        # 注意：查询结果中dt列的索引是1（索引1对应别名"dt"）
                        dt_obj = None
                        if len(result) > 1 and result[1]:  # dt列在结果中是第2列（索引1）
                            dt_str = str(result[1])
                            dt_str = dt_str.split()[0]
                            try:
                                dt_obj = datetime.strptime(dt_str, "%Y-%m-%d")
                            except ValueError:
                                continue

                        # 如果日期解析失败，跳过该行
                        if dt_obj is None:
                            continue

                        # 只保留T-2的数据
                        if dt_obj == self.target_date_minus_2:
                            # 安全提取各列数据（使用查询后的别名索引）
                            # 查询顺序: campaign(索引0), dt(索引1), spend(索引2), conversions(索引3), roi1(索引4)
                            campaign_val = result[0] if len(result) > 0 else "Unknown"
                            spend_val = result[2] if len(result) > 2 else 0.0
                            conversions_val = result[3] if len(result) > 3 else 0.0
                            roi1_val = result[4] if len(result) > 4 else 0.0

                            rows.append({
                                'campaign': str(campaign_val) if campaign_val else "Unknown",
                                'platform': '内部',
                                'spend': float(spend_val) if spend_val else 0.0,
                                'conversions': float(conversions_val) if conversions_val else 0.0,
                                'roi1': float(roi1_val) if roi1_val else 0.0
                            })

                    except (ValueError, IndexError, TypeError) as e:
                        print(f"跳过无效行: {e}", file=sys.stderr)
                        continue

            conn.close()

        except Exception as e:
            print(f"读取内部数据库失败: {e}", file=sys.stderr)

        print(f"平台单日对比 - 内部加载了 {len(rows)} 条数据", file=sys.stderr)
        return rows

    def analyze(self) -> Dict[str, Any]:
        """执行分析"""
        # 加载两个平台的数据
        axon_rows = self.load_axon_data()
        internal_rows = self.load_internal_data()

        all_rows = axon_rows + internal_rows

        if not all_rows:
            return {'exists': False, 'data': [], 'markdown_table': '', 'summary': {}}

        # 聚合数据（按campaign和platform）
        grouped = defaultdict(lambda: {'spend': 0.0, 'conversions': 0.0, 'weighted_roi1': 0.0})

        for row in all_rows:
            key = (row['campaign'], row['platform'])
            grouped[key]['spend'] += row['spend']
            grouped[key]['conversions'] += row['conversions']
            grouped[key]['weighted_roi1'] += row['roi1'] * row['spend']

        # 计算聚合指标
        aggregated = []
        for (campaign, platform), values in grouped.items():
            spend = values['spend']
            conversions = values['conversions']
            cpa = spend / conversions if conversions > 0 else 0.0
            roi1 = values['weighted_roi1'] / spend if spend > 0 else 0.0

            aggregated.append({
                'campaign': campaign,
                'platform': platform,
                'conversions': int(conversions),
                'spend': round(spend, 2),
                'cpa': round(cpa, 2),
                'roi1': round(roi1, 2)
            })

        # 排序：campaign升序、platform升序
        sorted_data = sorted(aggregated, key=lambda x: (x['campaign'], x['platform']))

        # 生成Markdown表格
        markdown_table = self.generate_markdown_table(sorted_data)

        # 计算汇总指标
        summary = self.calculate_summary(sorted_data)

        return {
            'exists': True,
            'data': sorted_data,
            'markdown_table': markdown_table,
            'summary': summary
        }

    def generate_markdown_table(self, data: List[Dict[str, Any]]) -> str:
        """生成Markdown表格"""
        if not data:
            return "| campaign | 平台 | 消耗 | 激活量 | CPA | 1日ROI |\n|----------|------|------|--------|-----|--------|\n| 无数据 | | | | | |"

        table = "| campaign | 平台 | 消耗 | 激活量 | CPA | 1日ROI |\n"
        table += "|----------|------|------|--------|-----|--------|\n"

        for row in data:
            table += f"| {row['campaign']} | {row['platform']} | {row['spend']:.2f} | {row['conversions']} | {row['cpa']:.2f} | {row['roi1']:.2f} |\n"

        return table

    def calculate_summary(self, data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """计算汇总指标"""
        summary = {
            'total_spend': sum(row['spend'] for row in data),
            'total_conversions': sum(row['conversions'] for row in data),
            'platform_stats': defaultdict(lambda: {'spend': 0.0, 'roi1': 0.0})
        }

        for row in data:
            platform = row['platform']
            summary['platform_stats'][platform]['spend'] += row['spend']
            summary['platform_stats'][platform]['roi1'] += row['roi1'] * row['spend']

        # 计算各平台平均ROI
        for platform, stats in summary['platform_stats'].items():
            if stats['spend'] > 0:
                stats['avg_roi1'] = stats['roi1'] / stats['spend']
                stats['avg_roi1'] = round(stats['avg_roi1'], 2)
            else:
                stats['avg_roi1'] = 0.0
            stats['spend'] = round(stats['spend'], 2)

        summary['total_spend'] = round(summary['total_spend'], 2)

        return summary


# ============================================================================
# 第三部分：内部与Axon平台对比分析【滚动7日汇总】
# ============================================================================

class Platform7DayComparator:
    """平台7日汇总对比分析器（T-15~T-9）"""

    def __init__(self, axon_roi_path: str, internal_roi_path: str, target_date: str):
        self.axon_roi_path = Path(axon_roi_path)
        self.internal_roi_path = Path(internal_roi_path)
        self.target_date_obj = datetime.strptime(target_date, "%Y-%m-%d")
        self.date_range = [self.target_date_obj - timedelta(days=i) for i in range(9, 16)]  # T-9到T-15

    def load_axon_data(self) -> List[Dict[str, Any]]:
        """加载Axon ROI预测数据"""
        if not self.axon_roi_path.exists():
            print(f"警告：Axon ROI预测文件不存在: {self.axon_roi_path}", file=sys.stderr)
            return []

        rows = []
        try:
            with open(self.axon_roi_path, 'r', encoding='utf-8-sig') as f:
                reader = csv.reader(f)
                headers = next(reader)

                campaign_col = find_column_index(headers, ['campaign', 'camp', '活动'])
                date_col = find_column_index(headers, ['日期', 'date', 'dt', 't'])
                spend_col = find_column_index(headers, ['消耗', 'spend', 'cost', '花费'])
                conversions_col = find_column_index(headers, ['转化', '激活', 'conversion'])
                roi1_col = find_column_index(headers, ['roi1', 'roi_1', '首日roi'])
                roi3_col = find_column_index(headers, ['roi3', 'roi_3'])
                roi7_col = find_column_index(headers, ['roi7', 'roi_7'])

                # 预测ROI列
                predict_cols = {}
                for i, h in enumerate(headers):
                    if 'predict' in h.lower() and 'roi' in h.lower():
                        if '14' in h: predict_cols['roi14_predict'] = i
                        elif '30' in h: predict_cols['roi30_predict'] = i
                        elif '45' in h: predict_cols['roi45_predict'] = i
                        elif '60' in h: predict_cols['roi60_predict'] = i
                        elif '120' in h: predict_cols['roi120_predict'] = i
                        elif '180' in h: predict_cols['roi180_predict'] = i

                print(f"平台7日对比 - Axon列索引: campaign={campaign_col}, date={date_col}, spend={spend_col}, conversions={conversions_col}", file=sys.stderr)
                print(f"平台7日对比 - Axon预测列: {predict_cols}", file=sys.stderr)

                for row in reader:
                    try:
                        date_str = row[date_col] if date_col is not None else ""
                        date_str = date_str.split()[0]
                        date_obj = datetime.strptime(date_str, "%Y-%m-%d")

                        # 只保留T-15~T-9的数据
                        if date_obj in self.date_range:
                            row_data = {
                                'campaign': row[campaign_col] if campaign_col is not None else "Unknown",
                                'platform': 'Axon',
                                'spend': float(row[spend_col]) if spend_col is not None else 0.0,
                                'conversions': float(row[conversions_col]) if conversions_col is not None else 0.0,
                                'roi1': float(row[roi1_col]) if roi1_col is not None else 0.0,
                            }

                            if roi3_col is not None:
                                row_data['roi3'] = float(row[roi3_col])
                            if roi7_col is not None:
                                row_data['roi7'] = float(row[roi7_col])

                            # 预测ROI
                            for pred_name, col_idx in predict_cols.items():
                                if col_idx is not None:
                                    row_data[pred_name] = float(row[col_idx])

                            rows.append(row_data)

                    except (ValueError, IndexError):
                        continue

        except Exception as e:
            print(f"读取Axon ROI预测文件失败: {e}", file=sys.stderr)

        print(f"平台7日对比 - Axon加载了 {len(rows)} 条数据", file=sys.stderr)
        return rows

    def load_internal_data(self) -> List[Dict[str, Any]]:
        """加载内部ROI预测数据（不含actual的ROI字段）"""
        if not self.internal_roi_path.exists():
            print(f"警告：内部ROI数据库不存在: {self.internal_roi_path}", file=sys.stderr)
            return []

        rows = []
        try:
            conn = sqlite3.connect(str(self.internal_roi_path))
            cursor = conn.cursor()

            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()

            print(f"平台7日对比 - 内部ROI数据库表: {[t[0] for t in tables]}", file=sys.stderr)

            for table_info in tables:
                table_name = table_info[0]

                cursor.execute(f"PRAGMA table_info({table_name})")
                columns_info = cursor.fetchall()
                headers = [col[1] for col in columns_info]

                # 查找关键列（排除actual字段）
                campaign_col = find_column_index(headers, [
                    'campaign', 'camp', '活动', 'campaign_name', 
                    'ad_group', '广告组', '推广组'
                ])
                date_col = find_column_index(headers, [
                    '日期', 'date', 'dt', 't', 'ts', 
                    '日期时间', 'datetime', 'time'
                ])
                spend_col = find_column_index(headers, [
                    '消耗', 'spend', 'cost', '花费', 
                    '支出', 'expense', 'cost', '现金消耗'
                ])

                # ROI列（仅使用预测字段，不包含actual）
                roi1_col = None
                roi3_col = None
                roi7_col = None
                predict_cols = {}

                for i, h in enumerate(headers):
                    h_lower = h.lower()

                    # 排除actual字段
                    if 'actual' in h_lower:
                        continue

                    # 优先匹配预测列（包含predict和roi的列）
                    if 'predict' in h_lower or '预测' in h_lower:
                        # 支持多种命名格式：roi14_predict, roi14d_predict, roi_14_predict, roi14_day_predict 等
                        if re.search(r'14|14d|14_day', h_lower):
                            predict_cols['roi14_predict'] = i
                        elif re.search(r'30|30d|30_day', h_lower):
                            predict_cols['roi30_predict'] = i
                        elif re.search(r'45|45d|45_day', h_lower):
                            predict_cols['roi45_predict'] = i
                        elif re.search(r'60|60d|60_day', h_lower):
                            predict_cols['roi60_predict'] = i
                        elif re.search(r'120|120d|120_day', h_lower):
                            predict_cols['roi120_predict'] = i
                        elif re.search(r'180|180d|180_day', h_lower):
                            predict_cols['roi180_predict'] = i
                    elif 'agg' in h_lower and 'roi' in h_lower:
                        # 处理 roi1_agg, roi3_agg 等聚合字段
                        if re.search(r'roi.*1|1.*roi', h_lower):
                            roi1_col = i
                        elif re.search(r'roi.*3|3.*roi', h_lower):
                            roi3_col = i
                        elif re.search(r'roi.*7|7.*roi', h_lower):
                            roi7_col = i
                    elif 'roi' in h_lower:
                        # 其他ROI字段（排除预测列）
                        if re.search(r'roi.*1|1.*roi', h_lower) and 'predict' not in h_lower:
                            roi1_col = i
                        elif re.search(r'roi.*3|3.*roi', h_lower) and 'predict' not in h_lower:
                            roi3_col = i
                        elif re.search(r'roi.*7|7.*roi', h_lower) and 'predict' not in h_lower:
                            roi7_col = i

                if campaign_col is None or spend_col is None:
                    continue

                print(f"平台7日对比 - 内部表[{table_name}]列索引: campaign={campaign_col}, date={date_col}, spend={spend_col}", file=sys.stderr)
                print(f"平台7日对比 - 内部表[{table_name}]预测列: {predict_cols}", file=sys.stderr)

                # 查询数据
                query_cols = [f"\"{headers[campaign_col]}\" as campaign"]
                if date_col is not None:
                    query_cols.append(f"\"{headers[date_col]}\" as dt")
                query_cols.append(f"\"{headers[spend_col]}\" as spend")

                if roi1_col is not None:
                    query_cols.append(f"\"{headers[roi1_col]}\" as roi1")
                if roi3_col is not None:
                    query_cols.append(f"\"{headers[roi3_col]}\" as roi3")
                if roi7_col is not None:
                    query_cols.append(f"\"{headers[roi7_col]}\" as roi7")

                for pred_name, col_idx in predict_cols.items():
                    query_cols.append(f"\"{headers[col_idx]}\" as {pred_name}")

                query = f"SELECT {', '.join(query_cols)} FROM {table_name}"
                cursor.execute(query)
                results = cursor.fetchall()

                for result in results:
                    try:
                        # 构建列索引映射（根据查询语句的构建顺序）
                        col_mapping = {}
                        current_idx = 0
                        
                        # campaign (索引0)
                        col_mapping['campaign'] = current_idx
                        current_idx += 1
                        
                        # dt (索引1，如果date_col存在)
                        if date_col is not None:
                            col_mapping['dt'] = current_idx
                            current_idx += 1
                        
                        # spend
                        col_mapping['spend'] = current_idx
                        current_idx += 1
                        
                        # roi1 (如果存在)
                        if roi1_col is not None:
                            col_mapping['roi1'] = current_idx
                            current_idx += 1
                        
                        # roi3 (如果存在)
                        if roi3_col is not None:
                            col_mapping['roi3'] = current_idx
                            current_idx += 1
                        
                        # roi7 (如果存在)
                        if roi7_col is not None:
                            col_mapping['roi7'] = current_idx
                            current_idx += 1
                        
                        # predict_cols
                        for pred_name in predict_cols.keys():
                            col_mapping[pred_name] = current_idx
                            current_idx += 1
                        
                        # 安全提取日期，处理可能的None值
                        dt_obj = None
                        if 'dt' in col_mapping and len(result) > col_mapping['dt'] and result[col_mapping['dt']]:
                            dt_str = str(result[col_mapping['dt']])
                            dt_str = dt_str.split()[0]
                            try:
                                dt_obj = datetime.strptime(dt_str, "%Y-%m-%d")
                            except ValueError:
                                continue

                        # 如果日期解析失败，跳过该行
                        if dt_obj is None:
                            continue

                        # 只保留T-15~T-9的数据
                        if dt_obj in self.date_range:
                            row_data = {
                                'date': dt_obj  # 添加日期字段
                            }

                            # 提取campaign
                            if 'campaign' in col_mapping and len(result) > col_mapping['campaign']:
                                row_data['campaign'] = str(result[col_mapping['campaign']]) if result[col_mapping['campaign']] else "Unknown"
                            else:
                                continue

                            # 提取spend（必需字段）
                            if 'spend' in col_mapping and len(result) > col_mapping['spend']:
                                try:
                                    row_data['spend'] = float(result[col_mapping['spend']]) if result[col_mapping['spend']] else 0.0
                                except (ValueError, TypeError):
                                    row_data['spend'] = 0.0
                            else:
                                continue

                            row_data['platform'] = '内部'

                            # 提取roi1
                            if 'roi1' in col_mapping and len(result) > col_mapping['roi1']:
                                try:
                                    row_data['roi1'] = float(result[col_mapping['roi1']]) if result[col_mapping['roi1']] else 0.0
                                except (ValueError, TypeError):
                                    row_data['roi1'] = 0.0
                            else:
                                row_data['roi1'] = 0.0

                            # 提取roi3
                            if 'roi3' in col_mapping and len(result) > col_mapping['roi3']:
                                try:
                                    row_data['roi3'] = float(result[col_mapping['roi3']]) if result[col_mapping['roi3']] else 0.0
                                except (ValueError, TypeError):
                                    pass  # 可选字段，不强制

                            # 提取roi7
                            if 'roi7' in col_mapping and len(result) > col_mapping['roi7']:
                                try:
                                    row_data['roi7'] = float(result[col_mapping['roi7']]) if result[col_mapping['roi7']] else 0.0
                                except (ValueError, TypeError):
                                    pass  # 可选字段，不强制

                            # 提取预测ROI
                            for pred_name in predict_cols.keys():
                                if pred_name in col_mapping and len(result) > col_mapping[pred_name]:
                                    try:
                                        row_data[pred_name] = float(result[col_mapping[pred_name]]) if result[col_mapping[pred_name]] else 0.0
                                    except (ValueError, TypeError):
                                        pass  # 可选字段，不强制

                            rows.append(row_data)

                    except (ValueError, IndexError):
                        continue

            conn.close()

        except Exception as e:
            print(f"读取内部ROI数据库失败: {e}", file=sys.stderr)

        print(f"平台7日对比 - 内部加载了 {len(rows)} 条数据", file=sys.stderr)
        return rows

    def analyze(self) -> Dict[str, Any]:
        """执行分析"""
        # 加载两个平台的数据
        axon_rows = self.load_axon_data()
        internal_rows = self.load_internal_data()

        all_rows = axon_rows + internal_rows

        if not all_rows:
            return {'exists': False, 'data': [], 'markdown_table': '', 'summary': {}}

        # 聚合数据（按campaign和platform）
        grouped = defaultdict(lambda: {
            'spend': 0.0,
            'weighted_roi1': 0.0,
            'weighted_roi3': 0.0,
            'weighted_roi7': 0.0,
            'predict_rois': defaultdict(float)
        })

        for row in all_rows:
            key = (row['campaign'], row['platform'])
            group = grouped[key]
            group['spend'] += row['spend']

            # 加权ROI
            group['weighted_roi1'] += row['roi1'] * row['spend']
            if 'roi3' in row:
                group['weighted_roi3'] += row['roi3'] * row['spend']
            if 'roi7' in row:
                group['weighted_roi7'] += row['roi7'] * row['spend']

            # 预测ROI加权
            for pred_name in ['roi14_predict', 'roi30_predict', 'roi45_predict', 'roi60_predict', 'roi120_predict', 'roi180_predict']:
                if pred_name in row:
                    group['predict_rois'][pred_name] += row[pred_name] * row['spend']

        # 计算聚合指标
        aggregated = []
        for (campaign, platform), values in grouped.items():
            spend = values['spend']
            roi1 = values['weighted_roi1'] / spend if spend > 0 else 0.0
            roi3 = values['weighted_roi3'] / spend if spend > 0 and values['weighted_roi3'] > 0 else 0.0
            roi7 = values['weighted_roi7'] / spend if spend > 0 and values['weighted_roi7'] > 0 else 0.0

            row_data = {
                'campaign': campaign,
                'platform': platform,
                'spend': round(spend, 2),
                'roi1': round(roi1, 2)
            }

            if roi3 > 0:
                row_data['roi3'] = round(roi3, 2)
            if roi7 > 0:
                row_data['roi7'] = round(roi7, 2)

            # 预测ROI
            for pred_name in ['roi14_predict', 'roi30_predict', 'roi45_predict', 'roi60_predict', 'roi120_predict', 'roi180_predict']:
                if values['predict_rois'][pred_name] > 0:
                    pred_value = values['predict_rois'][pred_name] / spend
                    row_data[pred_name] = round(pred_value, 2)

            aggregated.append(row_data)

        # 排序：campaign升序、platform升序
        sorted_data = sorted(aggregated, key=lambda x: (x['campaign'], x['platform']))

        # 生成Markdown表格
        markdown_table = self.generate_markdown_table(sorted_data)

        # 计算汇总指标
        summary = self.calculate_summary(sorted_data)

        return {
            'exists': True,
            'data': sorted_data,
            'markdown_table': markdown_table,
            'summary': summary
        }

    def generate_markdown_table(self, data: List[Dict[str, Any]]) -> str:
        """生成Markdown表格"""
        if not data:
            return "| campaign | 平台 | 消耗 | 1日ROI | 3日ROI | 7日ROI | 14日预测ROI | 30日预测ROI | 45日预测ROI | 60日预测ROI | 120日预测ROI | 180日预测ROI |\n|----------|------|------|--------|--------|--------|-------------|-------------|-------------|-------------|--------------|--------------|\n| 无数据 | | | | | | | | | | |"

        table = "| campaign | 平台 | 消耗 | 1日ROI | 3日ROI | 7日ROI | 14日预测ROI | 30日预测ROI | 45日预测ROI | 60日预测ROI | 120日预测ROI | 180日预测ROI |\n"
        table += "|----------|------|------|--------|--------|--------|-------------|-------------|-------------|-------------|--------------|--------------|\n"

        for row in data:
            line = f"| {row['campaign']} | {row['platform']} | {row['spend']:.2f} | {row['roi1']:.2f}"
            line += f" | {row.get('roi3', 0):.2f}" if 'roi3' in row else " | -"
            line += f" | {row.get('roi7', 0):.2f}" if 'roi7' in row else " | -"
            line += f" | {row.get('roi14_predict', 0):.2f}"
            line += f" | {row.get('roi30_predict', 0):.2f}"
            line += f" | {row.get('roi45_predict', 0):.2f}"
            line += f" | {row.get('roi60_predict', 0):.2f}"
            line += f" | {row.get('roi120_predict', 0):.2f}"
            line += f" | {row.get('roi180_predict', 0):.2f}"
            line += " |\n"

            table += line

        return table

    def calculate_summary(self, data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """计算汇总指标"""
        summary = {
            'total_spend': sum(row['spend'] for row in data),
            'platform_stats': defaultdict(lambda: {
                'spend': 0.0,
                'roi1': 0.0,
                'roi3': 0.0,
                'roi7': 0.0,
                'predict_rois': defaultdict(float)
            })
        }

        for row in data:
            platform = row['platform']
            stats = summary['platform_stats'][platform]
            stats['spend'] += row['spend']
            stats['roi1'] += row['roi1'] * row['spend']
            if 'roi3' in row:
                stats['roi3'] += row['roi3'] * row['spend']
            if 'roi7' in row:
                stats['roi7'] += row['roi7'] * row['spend']

            # 预测ROI加权
            for pred_name in ['roi14_predict', 'roi30_predict', 'roi45_predict', 'roi60_predict', 'roi120_predict', 'roi180_predict']:
                if pred_name in row:
                    stats['predict_rois'][pred_name] += row[pred_name] * row['spend']

        # 计算各平台平均ROI
        for platform, stats in summary['platform_stats'].items():
            if stats['spend'] > 0:
                stats['avg_roi1'] = stats['roi1'] / stats['spend']
                stats['avg_roi1'] = round(stats['avg_roi1'], 2)

                if stats['roi3'] > 0:
                    stats['avg_roi3'] = stats['roi3'] / stats['spend']
                    stats['avg_roi3'] = round(stats['avg_roi3'], 2)

                if stats['roi7'] > 0:
                    stats['avg_roi7'] = stats['roi7'] / stats['spend']
                    stats['avg_roi7'] = round(stats['avg_roi7'], 2)

                # 预测ROI
                for pred_name in ['roi14_predict', 'roi30_predict', 'roi45_predict', 'roi60_predict', 'roi120_predict', 'roi180_predict']:
                    if stats['predict_rois'][pred_name] > 0:
                        pred_value = stats['predict_rois'][pred_name] / stats['spend']
                        stats[f'avg_{pred_name}'] = round(pred_value, 2)
            else:
                stats['avg_roi1'] = 0.0

            stats['spend'] = round(stats['spend'], 2)

        summary['total_spend'] = round(summary['total_spend'], 2)

        return summary


# ============================================================================
# 主函数
# ============================================================================

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='增长日报生成器 - 整合版')
    parser.add_argument('--target-date', required=True, help='目标日期（T），格式YYYY-MM-DD')
    parser.add_argument('--section', default='all', choices=['all', 'monitor', 'daily-compare', '7day-compare'],
                        help='生成的部分：all=全部, monitor=仅Axon监控, daily-compare=仅单日对比, 7day-compare=仅7日对比')
    parser.add_argument('--output-format', default='markdown', choices=['markdown', 'json'],
                        help='输出格式：markdown=Markdown表格, json=JSON格式（包含汇总指标）')

    # 数据源路径
    parser.add_argument('--axon-cache-path', default='~/.openclaw/workspace/exports/axon_monitor_cache.csv',
                        help='Axon监控缓存CSV文件路径')
    parser.add_argument('--internal-db-path', default='~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite',
                        help='内部投放数据库路径')
    parser.add_argument('--axon-roi-path', default='~/.openclaw/workspace/exports/axon_roi_predict.csv',
                        help='Axon ROI预测CSV文件路径')
    parser.add_argument('--internal-roi-path', default='~/.openclaw/workspace/data_analysis/roi_predict/data/roi_predict_campaign_distribute_roi1_180_last4m.sqlite',
                        help='内部ROI预测数据库路径')

    args = parser.parse_args()

    # 展开路径
    axon_cache_path = Path(args.axon_cache_path).expanduser()
    internal_db_path = Path(args.internal_db_path).expanduser()
    axon_roi_path = Path(args.axon_roi_path).expanduser()
    internal_roi_path = Path(args.internal_roi_path).expanduser()

    results = {}

    # 生成指定的部分
    if args.section in ['all', 'monitor']:
        print("=== 第一部分：Axon基础数据监控分析【T-3、T-2、T-1】 ===", file=sys.stderr)
        monitor_analyzer = AxonMonitorAnalyzer(str(axon_cache_path), args.target_date)
        results['monitor'] = monitor_analyzer.analyze()

    if args.section in ['all', 'daily-compare']:
        print("\n=== 第二部分：内部与Axon平台单日对比分析【T-2】 ===", file=sys.stderr)
        daily_comparator = PlatformDailyComparator(str(axon_cache_path), str(internal_db_path), args.target_date)
        results['daily_compare'] = daily_comparator.analyze()

    if args.section in ['all', '7day-compare']:
        print("\n=== 第三部分：内部与Axon平台对比分析【滚动7日汇总】 ===", file=sys.stderr)
        seven_day_comparator = Platform7DayComparator(str(axon_roi_path), str(internal_roi_path), args.target_date)
        results['seven_day_compare'] = seven_day_comparator.analyze()

    # 输出结果
    if args.output_format == 'json':
        # 序列化日期对象
        for section_name, result in results.items():
            result['data'] = [
                {
                    'campaign': row['campaign'],
                    'date': row['date'].strftime("%Y-%m-%d") if 'date' in row else None,
                    'platform': row.get('platform', ''),
                    'conversions': row['conversions'],
                    'spend': row['spend'],
                    'cpa': row['cpa'],
                    'roi1': row['roi1'],
                    **{k: v for k, v in row.items() if k.startswith('roi') and k not in ['roi1']}
                }
                for row in result['data']
            ]

        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        # 输出Markdown表格
        if 'monitor' in results:
            print("## 一、Axon基础数据监控分析【T-3、T-2、T-1】\n")
            print(results['monitor']['markdown_table'])

        if 'daily_compare' in results:
            print("\n## 二、内部与Axon平台单日对比分析【T-2】\n")
            print(results['daily_compare']['markdown_table'])

        if 'seven_day_compare' in results:
            print("\n## 三、内部与Axon平台对比分析【滚动7日汇总】\n")
            print(results['seven_day_compare']['markdown_table'])


if __name__ == '__main__':
    main()
