---
name: growth-daily-report
description: 从内部数据源和Axon平台自动生成增长日报，整合投放数据和ROI预测，提供核心指标分析、趋势对比和优化建议；当用户需要生成日报、查看投放效果、分析增长趋势或制作运营汇报时使用
dependency:
  python: []
  system:
    - echo "确保agent助手应用已配置文档编辑和消息发送权限"
---

# 增长日报生成 Skill

## 任务目标
- 本 Skill 用于：基于内部投放数据和Axon平台数据自动生成增长日报
- 能力包含：多平台数据查询、指标计算、趋势分析、洞察提炼、Markdown报告生成
- 触发条件：用户请求生成日报、查看投放效果、分析增长趋势或制作运营汇报时使用

## 日期定义（重要约定）

**日期标识说明**：
- **T** = 今天（生成日报的日期）
- **T-1** = 昨天
- **T-2** = 前天
- **T-3** = 大前天
- **T-N** = N天前

**示例**：
- 如果今天是2025-01-15（T）
- 那么T-1 = 2025-01-14
- T-2 = 2025-01-13
- T-3 = 2025-01-12

**日期使用场景**：
- Axon监控分析：查看T-3、T-2、T-1的数据（最近3天）
- 单日对比分析：对比T-2的数据（2天前）
- 7日汇总对比：汇总T-15~T-9的数据（7天滚动窗口）

## 前置准备
- 内部数据准备：确保以下SQLite数据库已通过数据获取脚本更新到最新
  - 投放基础数据：`~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite`
  - ROI预测数据：`~/.openclaw/workspace/data_analysis/roi_predict/data/roi_predict_campaign_distribute_roi1_180_last4m.sqlite`
- Axon平台数据准备：
  - **数据源**：使用已存在的Axon数据文件
    - 基础数据：`~/.openclaw/workspace/exports/axon_monitor_cache.csv`
      - 表头：产品, 日期, Campaign, 国家, 消耗, 转化数, ROI1, ROI3, ROI7
      - 数据范围：T-45~T-1所有产品数据
      - 获取脚本：`~/.openclaw/workspace/data_analysis/axon/projects/axon-reporting-api/scripts/export_products_fix.py`
    - ROI预测数据：`~/.openclaw/workspace/exports/axon_roi_predict.csv`
      - 表头：产品, 日期, Campaign, 消耗, roi1, roi3, roi7, roi14_predict, roi30_predict, roi45_predict, roi60_predict, roi120_predict, roi180_predict
      - 数据范围：45天所有产品的预测数据
      - 获取脚本：`~/.openclaw/workspace/data_analysis/roi_predict/scripts/axon_roi_predict.py`
  - **数据更新**：如需更新数据，运行对应的获取脚本（详情见`references/data_sources_config.md`）
- 依赖说明：无额外依赖（使用Python标准库sqlite3和csv）

## 操作步骤

### 标准流程

#### 1. 生成增长日报数据

调用整合脚本生成所有分析部分的数据：

- **执行**：`scripts/growth_report_generator.py --target-date YYYY-MM-DD --section all --output-format markdown`
- **日期参数**：传入的日期为T（今天），脚本自动计算相关日期
- **数据源**：自动使用以下数据文件
  - Axon监控缓存：`~/.openclaw/workspace/exports/axon_monitor_cache.csv`
  - 内部投放数据：`~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite`
  - Axon ROI预测：`~/.openclaw/workspace/exports/axon_roi_predict.csv`
  - 内部ROI预测：`~/.openclaw/workspace/data_analysis/roi_predict/data/roi_predict_campaign_distribute_roi1_180_last4m.sqlite`
- **数据处理**：
  - 按campaign和dt分组聚合
  - 激活量：求和
  - 消耗：求和
  - CPA：加权平均 = 总消耗 / 总激活量
  - ROI：加权平均，权重为消耗
  - 内部ROI预测：仅使用预测字段，不包含actual字段
- **输出格式**：
  - Markdown表格（用于飞书文档）
  - JSON格式（包含汇总指标，可选）
- **三个分析部分**：

  **第一部分：Axon基础数据监控分析【T-3、T-2、T-1】**
  - 数据来源：axon_monitor_cache.csv
  - 数据周期：T-3、T-2、T-1（最近3天）
  - 排序规则：campaign升序、dt倒序
  - 表格字段：campaign、dt、激活量、消耗、CPA、首日ROI

  **第二部分：内部与Axon平台单日对比分析【T-2】**
  - 数据来源：axon_monitor_cache.csv + activate_performance_creative_last4m.sqlite
  - 数据周期：T-2（2天前）
  - 排序规则：campaign升序、平台升序
  - 表格字段：campaign、平台、消耗、激活量、CPA、1日ROI

  **第三部分：内部与Axon平台对比分析【滚动7日汇总】**
  - 数据来源：roi_predict_campaign_distribute_roi1_180_last4m.sqlite（不含actual）+ axon_roi_predict.csv
  - 数据周期：T-15~T-9（7天滚动窗口）
  - 排序规则：campaign升序、平台升序
  - 表格字段：campaign、平台、消耗、激活量、CPA、1日ROI、3日ROI、7日ROI、14/30/45/60/120/180日预测ROI

**示例命令**：
```bash
# 生成所有三部分的Markdown表格（用于飞书文档）
python scripts/growth_report_generator.py --target-date 2025-03-09 --section all --output-format markdown

# 仅生成第一部分（Axon监控）
python scripts/growth_report_generator.py --target-date 2025-03-09 --section monitor --output-format markdown

# 仅生成第二部分（单日对比）
python scripts/growth_report_generator.py --target-date 2025-03-09 --section daily-compare --output-format markdown

# 仅生成第三部分（7日对比）
python scripts/growth_report_generator.py --target-date 2025-03-09 --section 7day-compare --output-format markdown

# 输出JSON格式（包含汇总指标）
python scripts/growth_report_generator.py --target-date 2025-03-09 --section all --output-format json
```

#### 2. 生成日报内容
   - 参考：`references/report_template.md` 的格式和结构
   - **报告日期**：使用T（今天）作为报告日期
   - 标准日报应包含以下三个分析部分：

     **2.1 Axon基础数据监控分析【T-3、T-2、T-1】**
     - 数据来源：脚本输出Markdown表格（第一部分）
     - 内容：数据表呈现 + 结论分析
     - 排序规则：campaign升序、dt倒序
     - 表格字段：campaign、dt、激活量、消耗、CPA、首日ROI
     - **结论分析**：参考`references/axon_monitor_conclusion_template.md`，包含数据概览、Campaign表现分析和建议

     **2.2 内部与Axon平台单日对比分析【T-2】**
     - 数据来源：脚本输出Markdown表格（第二部分）
     - 内容：数据表呈现 + 结论分析
     - 排序规则：campaign升序、平台升序
     - 表格字段：campaign、平台、消耗、激活量、CPA、1日ROI

     **2.3 内部与Axon平台对比分析【滚动7日汇总】**
     - 数据来源：脚本输出Markdown表格（第三部分）
     - 内容：数据表呈现 + 结论分析
     - 排序规则：campaign升序、平台升序
     - 表格字段：campaign、平台、消耗、激活量、CPA、1日ROI、3日ROI、7日ROI、14/30/45/60/120/180日预测ROI

   - **建议格式要求**：
     - 描述现象
     - 简述原因 + 建议（简短、明确、可执行）
     - 每条建议控制在2-3行内

#### 3. 发送日报

您的agent助手应用负责执行以下发送操作：

**3.1 飞书卡片消息**
- **目标**：快速发送日报摘要，展示关键数据和简单描述
- **内容结构**：
  - 标题：26Y游戏业务线增长日报 - YYYY-MM-DD
  - 数据概览：核心指标表格（总消耗、总激活量、平均CPA、平均ROI及环比变化）
  - 关键洞察：3-5条要点
  - 简要分析：各分析部分的简要数据（支持Markdown表格）
  - 核心建议：按标准格式的建议
  - 行动按钮：跳转到详细飞书文档
- **格式要求**：
  - 使用飞书卡片消息的JSON格式
  - 表格使用Markdown格式（支持在飞书卡片中展示）
  - 参考：`references/report_template.md` 的"飞书卡片消息格式"章节
- **发送方式**：
  - 使用飞书消息API：`POST /open-apis/message/v4/send`
  - 发送到指定的群聊

**3.2 飞书文档更新**
- **目标**：更新"26Y游戏业务线增长日报"文档，提供详细分析内容
- **文档Token**：Oab8wMiFliZlCJk3mPFclh9VnOh
- **文档链接**：https://cootek.feishu.cn/wiki/Oab8wMiFliZlCJk3mPFclh9VnOh
- **更新方式**：覆盖更新（替换原有内容）
- **内容结构**：
  - 标题：增长日报 YYYY-MM-DD
  - 数据周期：T-3、T-2、T-1（YYYY-MM-DD-2 至 YYYY-MM-DD）
  - 三个核心分析部分：
    1. Axon基础数据监控分析【T-3、T-2、T-1】
       - 数据表格（3天的完整数据）
       - 结论分析（数据概览、Campaign表现、建议）
    2. 内部与Axon平台单日对比分析【T-2】
       - 数据表格
       - 结论分析
    3. 内部与Axon平台对比分析【滚动7日汇总】
       - 数据表格
       - 结论分析
- **格式要求**：
  - 使用Markdown格式
  - 表格使用Markdown表格语法（可在飞书文档中正常展示）
  - 参考：`references/report_template.md` 的"标准日报格式"章节
- **更新方式**：
  - 使用飞书文档API：`POST /open-apis/docx/v1/documents/{document_token}/blocks/batchUpdate`
  - 或者使用Markdown方式直接更新文档内容

## 资源索引

- 必要脚本：
  - [scripts/growth_report_generator.py](scripts/growth_report_generator.py)（用途：整合三个分析部分，生成Axon监控、单日对比和7日汇总的Markdown表格）
- 领域参考：
  - [references/metrics_definition.md](references/metrics_definition.md)（何时读取：需要理解指标含义和计算方式时）
  - [references/report_template.md](references/report_template.md)（何时读取：需要了解报告格式和写作要点时）
  - [references/axon_monitor_conclusion_template.md](references/axon_monitor_conclusion_template.md)（何时读取：需要生成Axon监控分析的结论和建议时）
  - [references/data_aggregation_guide.md](references/data_aggregation_guide.md)（何时读取：需要了解数据聚合逻辑、配置和故障排除时）
  - [references/data_sources_config.md](references/data_sources_config.md)（何时读取：需要了解数据源结构、路径和更新方式时）

## 注意事项

### 执行职责分工
- **智能体职责**：
  - 数据理解与分析：理解脚本输出的JSON数据，进行趋势分析和洞察提炼
  - 内容生成：根据数据生成日报内容，包括结论分析和建议
  - 格式化：按照模板格式生成Markdown报告和飞书卡片消息
  - 调用飞书API：使用agent助手应用的凭证调用飞书API更新文档和发送消息

- **脚本职责**：
  - 数据查询：从SQLite数据库和CSV文件查询并聚合数据
  - 指标计算：计算各平台的消耗、激活量、CPA、ROI等指标
  - 数据输出：输出结构化的JSON数据供智能体分析

- **agent助手应用职责**：
  - 身份认证：提供App ID和App Secret用于API调用
  - 权限管理：确保应用有文档读写和消息发送权限
  - API访问：提供访问飞书文档和消息的接口

### 数据质量要求
- 确保内部数据库已更新到最新数据（包含目标日期的数据）
- 确保Axon缓存文件已生成（包含T-15至T-1的数据）
- 如遇数据缺失，应在日报中明确标注

### 内容质量要求
- 建议要简短、明确、可执行，避免冗长描述
- 关注异常值和趋势变化，提供有价值的洞察
- 数据表格必须完整，确保分析的准确性
- 飞书卡片消息要简洁，重点突出关键数据和洞察

### API调用要求
- 飞书文档更新：使用文档API批量更新文档块
- 飞书消息发送：使用消息API发送卡片消息
- 确保agent助手应用有相应的权限（docx:document、message:send）
- 处理API调用的错误和异常情况

### 其他注意事项
- 仅在需要时读取参考文档，保持上下文简洁
- 脚本输出的JSON数据应完整读取，确保分析的准确性
- 日报生成由智能体完成，充分利用语言理解和分析能力
- 关注数据的异常值和趋势变化，提供有价值的洞察

## 使用示例

### 示例1：生成昨日日报
- 功能：生成2025-01-15的增长日报
- 执行方式：智能体调用脚本获取数据，然后生成报告
- 关键参数：`--target-date 2025-01-15`
- 命令示例：
```bash
python /workspace/projects/growth-daily-report/scripts/data_query.py --target-date 2025-01-15
```

### 示例2：生成指定日期的日报
- 功能：生成特定日期的日报进行历史回顾
- 执行方式：智能体调用脚本获取数据，然后生成报告
- 关键参数：`--target-date 2025-01-10`
- 命令示例：
```bash
python /workspace/projects/growth-daily-report/scripts/data_query.py --target-date 2025-01-10 --db-path-creative ~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite
```

### 示例3：使用自定义数据库路径
- 功能：当数据库不在默认位置时指定路径
- 执行方式：智能体调用脚本获取数据，然后生成报告
- 关键参数：提供完整的数据库路径
- 命令示例：
```bash
python /workspace/projects/growth-daily-report/scripts/data_query.py --target-date 2025-01-15 --db-path-creative /path/to/custom/db.sqlite --db-path-roi /path/to/custom/roi.db.sqlite
```

### 示例4：仅查询Axon平台数据
- 功能：生成Axon平台的增长日报
- 执行方式：智能体调用脚本获取数据，然后生成报告
- 关键参数：`--platform axon`
- 命令示例：
```bash
python /workspace/projects/growth-daily-report/scripts/data_query.py --target-date 2025-01-15 --platform axon
```

### 示例5：查询所有平台并生成对比报告
- 功能：生成包含内部平台和Axon平台的对比报告
- 执行方式：智能体调用脚本获取数据，然后生成报告
- 关键参数：`--platform all`（默认）
- 命令示例：
```bash
python /workspace/projects/growth-daily-report/scripts/data_query.py --target-date 2025-01-15 --platform all
```

### 示例6：Axon基础数据监控分析
- 功能：获取Axon基础数据的监控表格，用于详细分析
- 执行方式：智能体调用脚本获取表格数据，然后生成分析结论
- 关键参数：`--output-type monitor-table`
- 命令示例：
```bash
python /workspace/projects/growth-daily-report/scripts/data_query.py --target-date 2025-01-15 --platform axon --output-type monitor-table
```

**输出说明**：
- 表格字段：campaign、dt、激活量、消耗、CPA、首日ROI
- 排序规则：camp升序、dt倒序
- 适用场景：需要查看详细数据、进行 Campaign 级别的监控和分析

### 示例7：内部与Axon平台单日对比分析（看GAP）
- 功能：对比两个平台在单日（T-1）的表现，快速识别GAP
- 执行方式：智能体调用脚本获取对比数据，然后生成分析结论
- 关键参数：`--output-type daily-comparison`
- 命令示例：
```bash
python /workspace/projects/growth-daily-report/scripts/data_query.py --target-date 2025-01-15 --output-type daily-comparison
```

**输出说明**：
- 对比周期：T-1（单日）
- 表格字段：campaign、平台、消耗、激活量、CPA、1日ROI
- 排序规则：campaign升序、平台升序
- 适用场景：快速识别单日表现差异、发现异常GAP

### 示例8：内部与Axon平台对比分析（滚动7日）
- 功能：对比两个平台在滚动周期内的表现，评估投放数据本身
- 执行方式：智能体调用脚本获取对比数据，然后生成分析结论
- 关键参数：`--output-type platform-comparison`
- 命令示例：
```bash
python /workspace/projects/growth-daily-report/scripts/data_query.py --target-date 2025-01-15 --output-type platform-comparison
```

**输出说明**：
- 对比周期：T-15~T-9（7天滚动窗口）
- 表格字段：campaign、平台、消耗、激活量、CPA、1日ROI、3日ROI、7日ROI、14日预测ROI、30日预测ROI、45日预测ROI、60日预测ROI、120日预测ROI、180日预测ROI
- 排序规则：campaign升序、平台升序
- 适用场景：跨平台对比、评估平台优势、优化预算分配、分析长期价值

### 示例9：完整的日报生成与发送流程
- 功能：从数据查询到飞书文档更新和消息发送的完整流程
- 执行方式：智能体协调脚本和飞书API调用
- 执行步骤：
  1. 调用脚本获取三类数据：
     ```bash
     python /workspace/projects/growth-daily-report/scripts/data_query.py --target-date 2025-01-15 --platform axon --output-type monitor-table
     python /workspace/projects/growth-daily-report/scripts/data_query.py --target-date 2025-01-15 --output-type daily-comparison
     python /workspace/projects/growth-daily-report/scripts/data_query.py --target-date 2025-01-15 --output-type platform-comparison
     ```
  2. 智能体分析数据，生成日报内容（参考report_template.md）
  3. 智能体生成Markdown格式的飞书文档内容
  4. 智能体生成飞书卡片消息的JSON格式
  5. 智能体调用飞书文档API更新文档（文档Token: Oab8wMiFliZlCJk3mPFclh9VnOh）
  6. 智能体调用飞书消息API发送卡片消息到群聊
- 关键点：
  - 数据分析由智能体完成，充分利用语言理解能力
  - 飞书API调用使用agent助手应用的凭证
  - 确保agent助手应用有文档编辑和消息发送权限
  - 文档更新采用覆盖更新方式
  - 消息发送包含链接到详细文档的按钮
- 适用场景：自动化日报生成，每日定时执行或手动触发
