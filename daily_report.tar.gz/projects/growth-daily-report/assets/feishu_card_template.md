# 飞书卡片消息模板

本文档提供了增长日报的飞书卡片消息格式模板，用于快速发送日报摘要。

## 模板设计原则

1. **简洁明了**：卡片消息只包含核心数据和结论
2. **结构清晰**：三个分析部分清晰分隔
3. **表格展示**：使用Markdown表格展示关键数据
4. **建议突出**：重要建议单独列出

## 标准卡片模板

```markdown
**【26Y游戏业务线增长日报】**

📅 **报告日期**：2025-01-15

---

### 📊 Axon基础数据监控【T-1】

| Campaign | 激活量 | 消耗 | CPA | 首日ROI |
|----------|--------|------|-----|---------|
| CMP-001 | 100 | 1,000 | 10.0 | 1.5 |
| CMP-002 | 80 | 800 | 10.0 | 1.2 |
| CMP-003 | 60 | 600 | 10.0 | 0.8 |

📈 **核心指标**
- 总消耗：2,400 | 总激活：240 | 平均CPA：10.0 | 平均首日ROI：1.17

⚠️ **关键建议**
- CMP-003首日ROI低于1.0，建议停止投放

---

### ⚖️ 平台单日对比分析【T-1】

| 平台 | 消耗 | 激活量 | CPA | 1日ROI |
|------|------|--------|-----|--------|
| 内部 | 2,400 | 240 | 10.0 | 1.17 |
| Axon | 2,600 | 260 | 10.0 | 1.27 |

📈 **核心指标**
- Axon平台ROI比内部高8.5%

⚠️ **关键建议**
- Axon平台ROI优于内部，建议增加Axon平台预算占比

---

### 📈 平台7日汇总对比【T-15~T-9】

| 平台 | 消耗 | 激活量 | CPA | 1日ROI | 7日ROI | 180日预测ROI |
|------|------|--------|-----|--------|--------|--------------|
| 内部 | 12,000 | 1,200 | 10.0 | 1.17 | 1.37 | 2.87 |
| Axon | 13,000 | 1,300 | 10.0 | 1.27 | 1.47 | 2.97 |

📈 **核心指标**
- Axon平台长期价值（180日预测ROI）比内部高3.5%

⚠️ **关键建议**
- 建议预算分配：内部45%、Axon55%

---

📄 **完整报告**：[查看详细文档](https://cootek.feishu.cn/wiki/Oab8wMiFliZlCJk3mPFclh9VnOh)
```

## 模板使用说明

### 动态字段

以下字段需要根据实际数据动态替换：

1. **报告日期**：使用T（今天）的日期
2. **数据周期**：
   - Axon监控：T-1
   - 单日对比：T-1
   - 7日汇总：T-15~T-9
3. **表格数据**：从脚本输出中获取对应表格数据
4. **核心指标**：从表格数据中计算汇总指标
5. **关键建议**：从日报分析中提取最重要的1-2条建议
6. **文档链接**：飞书文档的实际链接

### 表格简化规则

为了在卡片消息中保持简洁，可以对表格进行简化：

1. **Axon监控表**：保留所有列（数据量较小）
2. **单日对比表**：可以按平台汇总，只显示两行（内部、Axon）
3. **7日汇总表**：可以按平台汇总，只显示两行（内部、Axon），只展示核心ROI列（1日、7日、180日预测）

### 建议提取规则

1. **优先级**：优先提取影响最大的建议（如停止亏损Campaign）
2. **数量控制**：每个部分最多保留2条建议
3. **格式统一**：使用"现象 + 建议"的简化格式

## 卡片消息生成脚本示例

```python
def generate_card_message(report_date, monitor_data, daily_comparison, platform_comparison, doc_url):
    """
    生成飞书卡片消息

    Args:
        report_date: 报告日期（T）
        monitor_data: Axon监控数据（DataFrame）
        daily_comparison: 单日对比数据（DataFrame）
        platform_comparison: 7日汇总对比数据（DataFrame）
        doc_url: 飞书文档链接

    Returns:
        卡片消息文本
    """
    # 生成卡片消息
    card_message = f"""**【26Y游戏业务线增长日报】**

📅 **报告日期**：{report_date}

---

### 📊 Axon基础数据监控【T-1】

{format_monitor_table(monitor_data)}

📈 **核心指标**
{format_monitor_summary(monitor_data)}

⚠️ **关键建议**
{extract_monitor_suggestions(monitor_data)}

---

### ⚖️ 平台单日对比分析【T-1】

{format_daily_comparison_table(daily_comparison)}

📈 **核心指标**
{format_daily_comparison_summary(daily_comparison)}

⚠️ **关键建议**
{extract_daily_comparison_suggestions(daily_comparison)}

---

### 📈 平台7日汇总对比【T-15~T-9】

{format_platform_comparison_table(platform_comparison)}

📈 **核心指标**
{format_platform_comparison_summary(platform_comparison)}

⚠️ **关键建议**
{extract_platform_comparison_suggestions(platform_comparison)}

---

📄 **完整报告**：[查看详细文档]({doc_url})
"""

    return card_message
```

## 注意事项

1. **Markdown表格**：使用标准的Markdown表格格式，确保在飞书中正确显示
2. **表情符号**：适当使用表情符号提升可读性，但不要过多
3. **链接格式**：确保文档链接可点击
4. **换行控制**：保持适当的换行，避免卡片过长
5. **数据精度**：数值保留1-2位小数，避免过多小数位
