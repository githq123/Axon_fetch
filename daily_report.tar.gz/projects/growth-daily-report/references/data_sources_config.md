# 数据源配置

## 内部数据源

### 内部基础数据
- **获取脚本**: `~/.openclaw/workspace/data_analysis/act_performance/scripts/activate_performace_fetch.py`
- **存储文件**: `~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite`
- **数据范围**: 近4个月投放基础数据（创意/活动粒度）
- **表头**:
  ```
  dt, app_name, media_source, campaign_name, deep_conversion_type, country, country_tier,
  video_url, img_url, cover_url, h5_url,
  act_count, 现金消耗, CPA,
  2留, 3留, 7留, 4留, 14留, 30留,
  1日ROI, 2日ROI, 3日ROI, 4日ROI, 7日ROI, 14日ROI, 30日ROI,
  1日LTV_总, 3日LTV_总, 4日LTV_总, 7日LTV_总, 14日LTV_总, 30日LTV_总,
  付费率_1日, 付费率_3日, 付费率_7日, 付费率_14日, 付费率_30日,
  累计客单价_1日, 累计客单价_3日, 累计客单价_7日, 累计客单价_14日,
  1日付费用户成本, 3日付费用户成本, 7日付费用户成本, 14日付费用户成本, 30日付费用户成本
  ```
- **关键字段**:
  - 日期: `dt`
  - 维度: `campaign_name`, `app_name`, `media_source`
  - 消耗: `现金消耗`
  - 转化: `act_count`
  - ROI: `1日ROI`, `3日ROI`, `7日ROI`, `14日ROI`, `30日ROI`
  - CPA: `CPA`

### 内部ROI预测数据
- **获取脚本**: `~/.openclaw/workspace/data_analysis/roi_predict/scripts/roi_predict_fetch.py`
- **存储文件**: `~/.openclaw/workspace/data_analysis/roi_predict/data/roi_predict_campaign_distribute_roi1_180_last4m.sqlite`
- **数据范围**: 近4个月ROI预测与分布相关聚合数据
- **表头**:
  ```
  ts, campaign, app_name,
  spend, roi1_agg, roi3_agg, roi7_agg, roi14_agg, roi30_agg, roi45_agg, roi60_agg, roi90_agg, roi180_agg,
  actual_roi1_agg, actual_roi3_agg, actual_roi7_agg, actual_roi14_agg, actual_roi30_agg,
  actual_roi45_agg, actual_roi60_agg, actual_roi90_agg, actual_roi180_agg
  ```
- **关键字段**:
  - 日期: `ts`
  - 维度: `campaign`, `app_name`
  - 消耗: `spend`
  - 预测ROI: `roi1_agg` ~ `roi180_agg`
  - 实际ROI: `actual_roi1_agg` ~ `actual_roi180_agg`

## Axon数据源

### Axon基础数据
- **获取脚本**: `~/.openclaw/workspace/data_analysis/axon/projects/axon-reporting-api/scripts/export_products_fix.py`
- **存储文件**: `~/.openclaw/workspace/exports/axon_monitor_cache.csv`
- **数据范围**: T-45~T-1所有产品数据
- **表头**:
  ```
  产品, 日期, Campaign, 国家, 消耗, 转化数, ROI1, ROI3, ROI7
  ```
- **关键字段**:
  - 日期: `日期`
  - 维度: `Campaign`, `产品`, `国家`
  - 消耗: `消耗`
  - 转化: `转化数`
  - ROI: `ROI1`, `ROI3`, `ROI7`

### Axon ROI预测数据
- **获取脚本**: `~/.openclaw/workspace/data_analysis/roi_predict/scripts/axon_roi_predict.py`
- **存储文件**: `~/.openclaw/workspace/exports/axon_roi_predict.csv`
- **数据范围**: 45天所有产品的预测数据
- **表头**:
  ```
  产品, 日期, Campaign, 消耗, roi1, roi3, roi7,
  roi14_predict, roi30_predict, roi45_predict, roi60_predict, roi120_predict, roi180_predict
  ```
- **关键字段**:
  - 日期: `日期`
  - 维度: `Campaign`, `产品`
  - 消耗: `消耗`
  - 实际ROI: `roi1`, `roi3`, `roi7`
  - 预测ROI: `roi14_predict` ~ `roi180_predict`

## 默认路径配置

```python
# 内部数据
DEFAULT_DB_CREATIVE_PATH = "~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite"
DEFAULT_DB_ROI_PATH = "~/.openclaw/workspace/data_analysis/roi_predict/data/roi_predict_campaign_distribute_roi1_180_last4m.sqlite"

# Axon数据
DEFAULT_AXON_CACHE_PATH = "~/.openclaw/workspace/exports/axon_monitor_cache.csv"
DEFAULT_AXON_ROI_PATH = "~/.openclaw/workspace/exports/axon_roi_predict.csv"
```

## 数据获取命令

### 更新内部基础数据
```bash
python ~/.openclaw/workspace/data_analysis/act_performance/scripts/activate_performace_fetch.py
```

### 更新内部ROI预测数据
```bash
python ~/.openclaw/workspace/data_analysis/roi_predict/scripts/roi_predict_fetch.py
```

### 更新Axon基础数据
```bash
python ~/.openclaw/workspace/data_analysis/axon/projects/axon-reporting-api/scripts/export_products_fix.py
```

### 更新Axon ROI预测数据
```bash
python ~/.openclaw/workspace/data_analysis/roi_predict/scripts/axon_roi_predict.py
```

## 数据同步策略

### 定时任务（建议）

1. **每日凌晨2点**: 更新所有数据
2. **数据范围**:
   - 内部数据: 近4个月
   - Axon数据: T-45~T-1

### Cron配置示例

```bash
# 每天凌晨2点更新内部基础数据
0 2 * * * python ~/.openclaw/workspace/data_analysis/act_performance/scripts/activate_performace_fetch.py >> /tmp/activate_fetch.log 2>&1

# 每天凌晨2:30更新内部ROI预测数据
30 2 * * * python ~/.openclaw/workspace/data_analysis/roi_predict/scripts/roi_predict_fetch.py >> /tmp/roi_fetch.log 2>&1

# 每天凌晨3点更新Axon基础数据
0 3 * * * python ~/.openclaw/workspace/data_analysis/axon/projects/axon-reporting-api/scripts/export_products_fix.py >> /tmp/axon_fetch.log 2>&1

# 每天凌晨3:30更新Axon ROI预测数据
30 3 * * * python ~/.openclaw/workspace/data_analysis/roi_predict/scripts/axon_roi_predict.py >> /tmp/axon_roi_predict.log 2>&1
```

## 数据质量检查

### 检查项

1. **文件存在性**:
   - 检查所有数据文件是否存在
   - 检查文件是否可读

2. **数据完整性**:
   - 检查CSV/SQLite文件是否包含数据
   - 检查数据日期范围是否正确

3. **字段完整性**:
   - 检查所有必需字段是否存在
   - 检查字段名称是否正确

4. **数据新鲜度**:
   - 检查最新数据日期
   - 检查数据是否及时更新

### 检查命令

```bash
# 检查文件是否存在
ls -lh ~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite
ls -lh ~/.openclaw/workspace/data_analysis/roi_predict/data/roi_predict_campaign_distribute_roi1_180_last4m.sqlite
ls -lh ~/.openclaw/workspace/exports/axon_monitor_cache.csv
ls -lh ~/.openclaw/workspace/exports/axon_roi_predict.csv

# 检查数据内容
head -5 ~/.openclaw/workspace/exports/axon_monitor_cache.csv
head -5 ~/.openclaw/workspace/exports/axon_roi_predict.csv

# 检查SQLite表结构
sqlite3 ~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite ".schema"
```

## 注意事项

1. **路径规范**: 使用`~`表示用户目录，脚本会自动展开
2. **编码格式**: CSV文件使用UTF-8编码
3. **日期格式**: 统一使用YYYY-MM-DD格式
4. **数据刷新**: 确保数据获取脚本正常运行，数据及时更新
5. **权限管理**: 确保脚本有读写相关文件的权限
