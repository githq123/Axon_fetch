# 数据聚合指南

## 概述

本指南说明增长日报Skill中的智能数据聚合功能，用于处理源数据表格式变化和维度差异。

## 功能说明

### 智能列检测

脚本会自动检测CSV/SQLite表中的列类型：

#### 检测维度列

优先级从高到低：
1. **主维度**：campaign（活动）、creative（创意）
2. **次维度**：campaign_id、creative_id
3. **其他维度**：app（应用）、adset（广告组）、ad（广告）

支持的列名变体：
- 英文：campaign, camp, Campaign, CAMP, CAMPAIGN
- 中文：活动、创意
- 混合：campaign_id, 活动ID

#### 检测指标列

自动映射到标准指标名：
- `spend/cost/消耗` → `spend`（求和）
- `conversions/转化/激活` → `conversions`（求和）
- `roi/roas/回报率` → `roi`（求平均）
- `cpa/单转化成本` → `cpa`（特殊计算）

#### 检测日期列

支持多种日期列名：
- `date`, `time`, `dt`, `t`
- `report_date`, `日期`, `时间`

### 维度聚合逻辑

当检测到维度列时，脚本会：

1. **确定主维度**：选择优先级最高的维度
2. **按主维度聚合**：将细粒度数据聚合到主维度
3. **计算指标**：
   - 数值型指标（消耗、转化）：求和
   - 比率型指标（ROI）：求平均
   - 成本型指标（CPA）：总消耗/总转化

### 示例场景

#### 场景1：多创意维度聚合到活动维度

**原始数据（创意粒度）**：
```csv
campaign,creative,date,spend,conversions,roi
CMP-001,CREA-001,2025-01-14,1000,100,1.5
CMP-001,CREA-002,2025-01-14,800,80,1.2
CMP-001,CREA-003,2025-01-14,700,70,1.0
CMP-002,CREA-001,2025-01-14,500,50,0.8
```

**聚合后数据（活动粒度）**：
```json
[
  {
    "campaign": "CMP-001",
    "spend": 2500,
    "conversions": 250,
    "roi": 1.23,
    "cpa": 10.0
  },
  {
    "campaign": "CMP-002",
    "spend": 500,
    "conversions": 50,
    "roi": 0.8,
    "cpa": 10.0
  }
]
```

#### 场景2：多渠道维度聚合

**原始数据（渠道粒度）**：
```csv
campaign,channel,date,spend,conversions,roi
CMP-001,channel_1,2025-01-14,600,60,1.5
CMP-001,channel_2,2025-01-14,400,40,1.2
CMP-001,channel_3,2025-01-14,500,50,1.0
```

**聚合后数据**：
```json
[
  {
    "campaign": "CMP-001",
    "spend": 1500,
    "conversions": 150,
    "roi": 1.23,
    "cpa": 10.0
  }
]
```

#### 场景3：带额外细维度

**原始数据（带细分维度）**：
```csv
campaign,creative,age_group,gender,spend,conversions,roi
CMP-001,CREA-001,18-24,M,300,30,1.5
CMP-001,CREA-001,18-24,F,200,20,1.4
CMP-001,CREA-001,25-34,M,250,25,1.6
CMP-001,CREA-002,18-24,M,300,30,1.2
```

**聚合后数据（创意粒度）**：
```json
[
  {
    "campaign": "CMP-001",
    "spend": 1050,
    "conversions": 105,
    "roi": 1.42,
    "cpa": 10.0
  }
]
```

## 使用方式

### 命令行调用

```bash
# 查询Axon数据（自动聚合）
python scripts/data_query.py --target-date 2025-01-15 --platform axon --output-type monitor-table

# 查看列分析信息（在stderr输出）
python scripts/data_query.py --target-date 2025-01-15 --platform axon --output-type monitor-table 2>analysis.log
cat analysis.log
```

### 输出信息

脚本会在标准错误输出（stderr）中输出聚合信息：

```
正在分析Axon缓存文件列结构...
列分析建议: 存在 8 个其他列，可能是细维度，将尝试聚合
检测到 1 个维度列, 4 个指标列
过滤后行数: 45
聚合后数据量: 3
标准列名: ['campaign', 'spend', 'conversions', 'roi', 'cpa']
```

### 返回数据结构

```json
{
  "exists": true,
  "original_headers": ["campaign", "creative", "age", "gender", "spend", "conversions", "roi"],
  "headers": ["campaign", "spend", "conversions", "roi", "cpa"],
  "rows": [
    {
      "campaign": "CMP-001",
      "spend": 2500.0,
      "conversions": 250,
      "roi": 1.23,
      "cpa": 10.0
    }
  ],
  "count": 1,
  "column_analysis": {
    "total_columns": 7,
    "dimension_columns": [
      {"index": 0, "name": "campaign"},
      {"index": 1, "name": "creative"}
    ],
    "metric_columns": [
      {"index": 4, "name": "spend"},
      {"index": 5, "name": "conversions"},
      {"index": 6, "name": "roi"}
    ],
    "date_column": null,
    "other_columns": [
      {"index": 2, "name": "age"},
      {"index": 3, "name": "gender"}
    ],
    "recommendations": [
      "存在 2 个其他列，可能是细维度，将尝试聚合"
    ]
  },
  "aggregated": true
}
```

## 配置选项

### 自定义维度列

如果自动检测失败，可以修改脚本中的`STANDARD_DIMENSIONS`常量：

```python
STANDARD_DIMENSIONS = [
    # 主维度
    ['campaign', 'camp', '活动'],
    # 添加自定义维度
    ['your_custom_dimension', '自定义维度']
]
```

### 自定义指标列

如果需要添加新的指标映射：

```python
STANDARD_METRICS = {
    # 添加自定义指标
    'custom_metric': ['custom', '自定义指标']
}
```

## 注意事项

### 1. 列名匹配规则

- **精确匹配**：列名完全等于标准名称
- **包含匹配**：标准名称包含在列名中
- **忽略大小写**：不区分大小写
- **忽略分隔符**：忽略下划线、空格、连字符

示例：
- `campaign_id` → 匹配 `campaign`
- `Total_Spend` → 匹配 `spend`
- `激活量` → 匹配 `conversions`

### 2. 聚合优先级

- 主维度优先：campaign > creative > 其他
- 第一个匹配的维度会被使用
- 如果没有检测到维度，返回原始数据

### 3. 数值类型处理

- 自动尝试转换为浮点数
- 转换失败的值会被忽略
- 空值被视为0

### 4. 日期过滤

- Axon缓存数据：T-3到T-1（3天）
- ROI预测数据：T-15到T-1（15天）
- 如果没有日期列，不过滤

## 故障排除

### 问题1：检测不到维度列

**症状**：
```
警告：未检测到维度列，返回原始数据
```

**解决方案**：
1. 检查列名是否在`STANDARD_DIMENSIONS`中
2. 添加自定义维度名称
3. 检查列名拼写

### 问题2：聚合后数据为空

**症状**：
```
聚合后数据量: 0
```

**可能原因**：
1. 日期过滤后没有数据
2. 所有行都无法转换为数值
3. 维度列值为空

**解决方案**：
1. 检查日期格式是否正确
2. 检查原始数据中是否有有效行
3. 查看原始数据内容

### 问题3：指标计算错误

**症状**：
指标数值不正确

**可能原因**：
1. 列映射错误
2. 数值类型转换失败
3. 聚合方式不合适

**解决方案**：
1. 查看`column_analysis`输出，确认列映射是否正确
2. 检查原始数据格式
3. 调整聚合逻辑

## 最佳实践

### 1. 定期检查列分析结果

每次运行脚本时，查看stderr输出的列分析信息，确保检测正确。

### 2. 保留原始列信息

返回数据中包含`original_headers`，可以追溯到原始列名。

### 3. 验证聚合结果

对关键指标进行手动验证，确保聚合逻辑正确。

### 4. 记录列结构变化

如果源数据表结构发生变化，及时更新`STANDARD_DIMENSIONS`和`STANDARD_METRICS`。

## 技术细节

### 列匹配算法

```python
def normalize_column_name(col: str) -> str:
    """标准化列名"""
    # 转小写
    col = col.lower()
    # 移除分隔符
    col = re.sub(r'[_\s\-]', '', col)
    return col

# 匹配逻辑
if normalized_col == normalized_standard or normalized_standard in normalized_col:
    return True
```

### 聚合算法

```python
def aggregate_metrics(metric_values: List[float], metric_type: str) -> float:
    """聚合指标值"""
    if not metric_values:
        return 0.0

    if metric_type in ['roi', 'roas']:
        # 比率型：求平均
        return round(sum(metric_values) / len(metric_values), 4)
    else:
        # 数值型：求和
        return round(sum(metric_values), 2)
```

## 更新日志

- 2025-01-15：初始版本，支持智能列检测和维度聚合
- 2025-01-15：添加列分析功能和诊断信息
