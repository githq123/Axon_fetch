#!/usr/bin/env python3
"""
Axon监控数据分析脚本

功能：
- 读取Axon监控缓存CSV文件
- 按campaign和dt分组聚合数据（T-3、T-2、T-1最近3天）
- 计算指标：激活量、消耗、CPA、首日ROI
- 输出Markdown表格格式（用于飞书文档）

数据来源：~/.openclaw/workspace/exports/axon_monitor_cache.csv
表头：产品, 日期, Campaign, 国家, 消耗, 转化数, ROI1, ROI3, ROI7

作者：Growth Daily Report Skill
日期：2025-03-09
"""

import csv
import argparse
import sys
from pathlib import Path
from datetime import datetime, timedelta
from collections import defaultdict
from typing import Dict, List, Any, Optional, Tuple


class AxonMonitorAnalyzer:
    """Axon监控数据分析器"""

    def __init__(self, cache_path: str, target_date: str):
        """
        初始化分析器

        Args:
            cache_path: Axon缓存CSV文件路径
            target_date: 目标日期（T），格式YYYY-MM-DD
        """
        self.cache_path = Path(cache_path)
        self.target_date_str = target_date
        self.target_date_obj = datetime.strptime(target_date, "%Y-%m-%d")
        self.date_range = [self.target_date_obj - timedelta(days=i) for i in [1, 2, 3]]  # T-1, T-2, T-3

    def load_data(self) -> List[Dict[str, Any]]:
        """
        加载CSV数据

        Returns:
            原始数据列表
        """
        if not self.cache_path.exists():
            print(f"警告：Axon缓存文件不存在: {self.cache_path}", file=sys.stderr)
            return []

        rows = []
        try:
            with open(self.cache_path, 'r', encoding='utf-8-sig') as f:
                reader = csv.reader(f)
                headers = next(reader)

                # 列名映射（支持中英文和不同命名）
                header_lower = {h.lower(): i for i, h in enumerate(headers)}

                # 关键列索引
                campaign_col = None
                date_col = None
                spend_col = None
                conversions_col = None
                roi1_col = None

                # 查找列索引
                for i, h in enumerate(headers):
                    h_lower = h.lower()

                    # Campaign列
                    if 'campaign' in h_lower or 'camp' in h_lower:
                        campaign_col = i

                    # 日期列
                    elif '日期' in h or 'date' in h_lower or 'dt' in h_lower:
                        date_col = i

                    # 消耗列
                    elif '消耗' in h or 'spend' in h_lower or 'cost' in h_lower:
                        spend_col = i

                    # 转化数/激活量列
                    elif '转化' in h or '激活' in h or 'conversion' in h_lower:
                        conversions_col = i

                    # ROI1列
                    elif 'roi1' in h_lower or 'roi_1' in h_lower or '首日roi' in h_lower:
                        roi1_col = i

                print(f"列索引映射: campaign={campaign_col}, date={date_col}, spend={spend_col}, conversions={conversions_col}, roi1={roi1_col}", file=sys.stderr)

                # 读取数据
                for row in reader:
                    try:
                        # 提取关键列数据
                        campaign = row[campaign_col] if campaign_col is not None and campaign_col < len(row) else "Unknown"

                        # 解析日期
                        date_str = row[date_col] if date_col is not None and date_col < len(row) else ""
                        date_str = date_str.split()[0]  # 去除时间部分
                        date_obj = datetime.strptime(date_str, "%Y-%m-%d")

                        # 只保留T-3到T-1的数据（最近3天）
                        if 1 <= (self.target_date_obj - date_obj).days <= 3:
                            # 提取数值
                            spend = float(row[spend_col]) if spend_col is not None and spend_col < len(row) and row[spend_col] else 0.0
                            conversions = float(row[conversions_col]) if conversions_col is not None and conversions_col < len(row) and row[conversions_col] else 0.0
                            roi1 = float(row[roi1_col]) if roi1_col is not None and roi1_col < len(row) and row[roi1_col] else 0.0

                            rows.append({
                                'campaign': campaign,
                                'date': date_obj,
                                'spend': spend,
                                'conversions': conversions,
                                'roi1': roi1
                            })

                    except (ValueError, IndexError) as e:
                        print(f"跳过无效行: {e}", file=sys.stderr)
                        continue

        except Exception as e:
            print(f"读取CSV文件失败: {e}", file=sys.stderr)
            return []

        print(f"加载了 {len(rows)} 条数据（T-3、T-2、T-1）", file=sys.stderr)
        return rows

    def aggregate_data(self, rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        按campaign和dt分组聚合数据

        Args:
            rows: 原始数据

        Returns:
            聚合后的数据
        """
        # 分组聚合：key = (campaign, date)
        groups = defaultdict(lambda: {
            'spend': 0.0,
            'conversions': 0.0,
            'weighted_roi1': 0.0  # 加权ROI1
        })

        for row in rows:
            key = (row['campaign'], row['date'])
            groups[key]['spend'] += row['spend']
            groups[key]['conversions'] += row['conversions']
            # ROI1加权：权重为消耗
            groups[key]['weighted_roi1'] += row['roi1'] * row['spend']

        # 计算聚合指标
        aggregated = []
        for (campaign, date), values in groups.items():
            spend = values['spend']
            conversions = values['conversions']

            # 计算CPA
            cpa = spend / conversions if conversions > 0 else 0.0

            # 计算加权平均ROI1
            roi1 = values['weighted_roi1'] / spend if spend > 0 else 0.0

            aggregated.append({
                'campaign': campaign,
                'date': date,
                'conversions': int(conversions),
                'spend': round(spend, 2),
                'cpa': round(cpa, 2),
                'roi1': round(roi1, 2)
            })

        return aggregated

    def sort_data(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        排序数据：campaign升序、dt倒序

        Args:
            data: 聚合后的数据

        Returns:
            排序后的数据
        """
        return sorted(data, key=lambda x: (x['campaign'], -x['date'].timestamp()))

    def generate_markdown_table(self, data: List[Dict[str, Any]]) -> str:
        """
        生成Markdown表格

        Args:
            data: 排序后的数据

        Returns:
            Markdown表格字符串
        """
        if not data:
            return "| campaign | dt | 激活量 | 消耗 | CPA | 首日ROI |\n|----------|----|--------|------|-----|---------|\n| 无数据 | | | | | |"

        # 表头
        table = "| campaign | dt | 激活量 | 消耗 | CPA | 首日ROI |\n"
        table += "|----------|----|--------|------|-----|---------|\n"

        # 数据行
        for row in data:
            date_str = row['date'].strftime("%Y-%m-%d")
            conversions = row['conversions']
            spend = f"{row['spend']:.2f}"
            cpa = f"{row['cpa']:.2f}"
            roi1 = f"{row['roi1']:.2f}"

            table += f"| {row['campaign']} | {date_str} | {conversions} | {spend} | {cpa} | {roi1} |\n"

        return table

    def analyze(self) -> Dict[str, Any]:
        """
        执行完整分析流程

        Returns:
            分析结果
        """
        # 1. 加载数据
        rows = self.load_data()
        if not rows:
            return {
                'exists': False,
                'data': [],
                'markdown_table': '',
                'summary': {}
            }

        # 2. 聚合数据
        aggregated = self.aggregate_data(rows)

        # 3. 排序数据
        sorted_data = self.sort_data(aggregated)

        # 4. 生成Markdown表格
        markdown_table = self.generate_markdown_table(sorted_data)

        # 5. 计算汇总指标
        summary = {
            'total_spend': sum(row['spend'] for row in sorted_data),
            'total_conversions': sum(row['conversions'] for row in sorted_data),
            'avg_cpa': 0.0,
            'avg_roi1': 0.0
        }

        if summary['total_conversions'] > 0:
            summary['avg_cpa'] = summary['total_spend'] / summary['total_conversions']

        if summary['total_spend'] > 0:
            summary['avg_roi1'] = sum(row['roi1'] * row['spend'] for row in sorted_data) / summary['total_spend']

        summary['total_spend'] = round(summary['total_spend'], 2)
        summary['avg_cpa'] = round(summary['avg_cpa'], 2)
        summary['avg_roi1'] = round(summary['avg_roi1'], 2)

        return {
            'exists': True,
            'data': sorted_data,
            'markdown_table': markdown_table,
            'summary': summary
        }


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='Axon监控数据分析')
    parser.add_argument('--target-date', required=True, help='目标日期（T），格式YYYY-MM-DD')
    parser.add_argument('--cache-path', default='~/.openclaw/workspace/exports/axon_monitor_cache.csv', help='Axon缓存CSV文件路径')
    parser.add_argument('--output-format', default='markdown', choices=['markdown', 'json'], help='输出格式')

    args = parser.parse_args()

    # 展开路径
    cache_path = Path(args.cache_path).expanduser()

    # 创建分析器
    analyzer = AxonMonitorAnalyzer(str(cache_path), args.target_date)

    # 执行分析
    result = analyzer.analyze()

    # 输出结果
    if args.output_format == 'json':
        import json
        # 序列化日期对象
        result['data'] = [
            {
                'campaign': row['campaign'],
                'dt': row['date'].strftime("%Y-%m-%d"),
                'conversions': row['conversions'],
                'spend': row['spend'],
                'cpa': row['cpa'],
                'roi1': row['roi1']
            }
            for row in result['data']
        ]
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        # 输出Markdown表格
        print(result['markdown_table'])


if __name__ == '__main__':
    main()
