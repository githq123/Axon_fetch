#!/usr/bin/env python3
"""
增长日报数据查询脚本

功能：
- 从内部SQLite数据库和Axon CSV文件查询数据
- 计算核心指标（消耗、转化、ROI、CPA、ROAS等）
- 支持多平台数据聚合和对比
- 生成对比数据（昨日、7日均、30日均）
- 输出JSON格式数据供智能体分析

数据源说明：
- 内部基础数据：~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite
- 内部ROI预测：~/.openclaw/workspace/data_analysis/roi_predict/data/roi_predict_campaign_distribute_roi1_180_last4m.sqlite
- Axon基础数据：~/.openclaw/workspace/exports/axon_monitor_cache.csv
- Axon ROI预测：~/.openclaw/workspace/exports/axon_roi_predict.csv

作者：Growth Daily Report Skill
日期：2025-01-15
更新：2025-01-15 (支持现有数据源)
"""

import sqlite3
import csv
import json
import argparse
import sys
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple, Set
from collections import defaultdict


class DataAggregator:
    """数据聚合器 - 处理维度聚合和列映射"""

    # 标准维度列（按优先级排序）
    STANDARD_DIMENSIONS = [
        # 主维度（最高优先级）
        ['campaign', 'camp', '活动', 'Campaign', 'CAMP', 'CAMPAIGN'],
        ['creative', 'crea', '创意', 'Creative', 'CREA', 'CREATIVE'],

        # 次维度
        ['campaign_id', 'camp_id', '活动ID', 'Campaign_ID', 'CAMP_ID'],
        ['creative_id', 'crea_id', '创意ID', 'Creative_ID', 'CREA_ID'],

        # 其他可能维度
        ['app', '应用', 'App', 'APP'],
        ['adset', '广告组', 'Adset', 'ADSET'],
        ['ad', '广告', 'Ad', 'AD']
    ]

    # 标准指标列（映射到标准名称）
    STANDARD_METRICS = {
        # 消耗类
        'spend': ['spend', 'cost', '消耗', '花费', 'Spend', 'Cost', 'SPEND', 'COST', '花费'],
        'cost': ['spend', 'cost', '消耗', '花费', 'Spend', 'Cost', 'SPEND', 'COST', '花费'],

        # 转化类
        'conversions': ['conversion', 'conversions', '转化', '激活', 'Conversion', 'Conversions', 'CONVERSION', 'CONVERSIONS', '激活量'],
        'activate': ['conversion', 'conversions', '转化', '激活', 'Conversion', 'Conversions', 'CONVERSION', 'CONVERSIONS', '激活量'],

        # ROI类
        'roi': ['roi', 'roas', 'ROI', 'ROAS', '回报率', '投资回报率'],
        'roas': ['roi', 'roas', 'ROI', 'ROAS', '回报率', '投资回报率'],

        # CPA类
        'cpa': ['cpa', 'CPA', '单转化成本', '单激活成本'],

        # 日期类
        'date': ['date', 'time', 'dt', 't', 'report_date', '日期', '时间', 'Date', 'TIME', 'DT', 'T', 'REPORT_DATE'],
    }

    @staticmethod
    def detect_dimension_columns(columns: List[str]) -> Dict[str, int]:
        """
        检测维度列

        Args:
            columns: 原始列名列表

        Returns:
            维度列名到索引的映射，按优先级排序
        """
        dimension_cols = {}

        for possible_names in DataAggregator.STANDARD_DIMENSIONS:
            for i, col in enumerate(columns):
                col_lower = col.lower()
                col_clean = re.sub(r'[_\s\-]', '', col_lower)

                for possible_name in possible_names:
                    possible_name_lower = possible_name.lower()
                    possible_name_clean = re.sub(r'[_\s\-]', '', possible_name_lower)

                    # 精确匹配或包含匹配
                    if col_clean == possible_name_clean or possible_name_clean in col_clean:
                        # 只记录第一个匹配的（最高优先级）
                        if possible_name.lower() not in dimension_cols:
                            dimension_cols[possible_name.lower()] = i
                        break

        return dimension_cols

    @staticmethod
    def detect_metric_columns(columns: List[str]) -> Dict[str, int]:
        """
        检测指标列

        Args:
            columns: 原始列名列表

        Returns:
            指标列名到索引的映射
        """
        metric_cols = {}

        for standard_name, possible_names in DataAggregator.STANDARD_METRICS.items():
            for i, col in enumerate(columns):
                col_lower = col.lower()
                col_clean = re.sub(r'[_\s\-]', '', col_lower)

                for possible_name in possible_names:
                    possible_name_lower = possible_name.lower()
                    possible_name_clean = re.sub(r'[_\s\-]', '', possible_name_lower)

                    if col_clean == possible_name_clean or possible_name_clean in col_clean:
                        metric_cols[standard_name] = i
                        break

                if standard_name in metric_cols:
                    break

        return metric_cols

    @staticmethod
    def detect_additional_dimensions(columns: List[str], known_cols: Set[int]) -> List[int]:
        """
        检测额外的维度列（当标准维度检测不到时）

        Args:
            columns: 原始列名列表
            known_cols: 已知的列索引集合（日期、指标列）

        Returns:
            额外的维度列索引列表
        """
        additional_dims = []

        for i, col in enumerate(columns):
            if i in known_cols:
                continue

            col_lower = col.lower()

            # 跳过明显的ID列和名称列（除非是主维度）
            skip_patterns = ['id', 'name', 'name_en', 'name_cn', '描述', 'description']
            if any(pattern in col_lower for pattern in skip_patterns):
                continue

            # 跳过数值列
            if any(keyword in col_lower for keyword in ['spend', 'cost', 'roi', 'cpa', 'conversion', 'activate']):
                continue

            # 其他字符串列可能是维度
            additional_dims.append(i)

        return additional_dims

    @staticmethod
    def aggregate_rows(
        rows: List[List[Any]],
        columns: List[str],
        dimension_cols: Dict[str, int],
        metric_cols: Dict[str, int],
        date_col: Optional[int] = None,
        target_date: Optional[str] = None
    ) -> Tuple[List[Dict[str, Any]], List[str]]:
        """
        聚合数据行到标准维度

        Args:
            rows: 原始数据行
            columns: 原始列名
            dimension_cols: 检测到的维度列
            metric_cols: 检测到的指标列
            date_col: 日期列索引
            target_date: 目标日期

        Returns:
            (聚合后的数据列表, 标准列名列表)
        """
        # 确定主维度（优先级最高的维度）
        primary_dimension = None
        primary_dim_idx = None

        for dim_name in ['campaign', 'creative', 'campaign_id', 'creative_id']:
            if dim_name in dimension_cols:
                primary_dimension = dim_name
                primary_dim_idx = dimension_cols[dim_name]
                break

        if primary_dimension is None and dimension_cols:
            # 如果没有标准维度，使用第一个检测到的维度
            primary_dimension = list(dimension_cols.keys())[0]
            primary_dim_idx = dimension_cols[primary_dimension]

        # 如果没有维度列，返回原始数据
        if primary_dimension is None:
            print("警告：未检测到维度列，返回原始数据", file=sys.stderr)
            aggregated = []
            for row in rows:
                item = {}
                for i, col in enumerate(columns):
                    item[col] = row[i] if i < len(row) else None
                aggregated.append(item)
            return aggregated, columns

        # 聚合数据
        aggregated_data = defaultdict(lambda: defaultdict(list))

        for row in rows:
            # 获取维度值
            dim_value = row[primary_dim_idx] if primary_dim_idx < len(row) else None

            # 过滤日期
            if date_col is not None and target_date:
                if date_col < len(row):
                    row_date = str(row[date_col])
                    if row_date != target_date:
                        continue

            # 收集指标值
            for metric_name, metric_idx in metric_cols.items():
                if metric_idx < len(row):
                    value = row[metric_idx]
                    try:
                        num_value = float(value) if value is not None else 0.0
                        aggregated_data[dim_value][metric_name].append(num_value)
                    except (ValueError, TypeError):
                        pass

        # 计算聚合后的指标
        result = []

        for dim_value, metrics_dict in aggregated_data.items():
            item = {
                primary_dimension: dim_value
            }

            # 求和或求平均
            for metric_name, values in metrics_dict.items():
                if metric_name in ['roi', 'roas']:
                    # ROI类指标求平均
                    if values:
                        item[metric_name] = round(sum(values) / len(values), 4)
                elif metric_name == 'cpa':
                    # CPA需要特殊计算：总消耗 / 总转化
                    if 'spend' in metrics_dict and 'conversions' in metrics_dict:
                        total_spend = sum(metrics_dict['spend'])
                        total_conversions = sum(metrics_dict['conversions'])
                        item['cpa'] = round(total_spend / total_conversions, 2) if total_conversions > 0 else 0
                    else:
                        item['cpa'] = round(sum(values) / len(values), 2) if values else 0
                else:
                    # 其他指标求和
                    item[metric_name] = round(sum(values), 2)

            result.append(item)

        # 生成标准列名
        standard_columns = [primary_dimension] + list(metric_cols.keys())

        return result, standard_columns

    @staticmethod
    def analyze_columns(columns: List[str]) -> Dict[str, Any]:
        """
        分析列结构，提供诊断信息

        Args:
            columns: 原始列名列表

        Returns:
            分析结果字典
        """
        analysis = {
            "total_columns": len(columns),
            "dimension_columns": [],
            "metric_columns": [],
            "date_column": None,
            "other_columns": [],
            "recommendations": []
        }

        # 检测列类型
        dimension_cols = DataAggregator.detect_dimension_columns(columns)
        metric_cols = DataAggregator.detect_metric_columns(columns)
        date_cols = [i for i, col in enumerate(columns) if DataAggregator.STANDARD_METRICS['date'][0].lower() in col.lower()]

        known_cols = set(dimension_cols.values()) | set(metric_cols.values()) | set(date_cols)

        for i, col in enumerate(columns):
            col_lower = col.lower()

            if i in dimension_cols.values():
                analysis["dimension_columns"].append({"index": i, "name": col})
            elif i in metric_cols.values():
                analysis["metric_columns"].append({"index": i, "name": col})
            elif i in date_cols:
                analysis["date_column"] = {"index": i, "name": col}
            else:
                analysis["other_columns"].append({"index": i, "name": col})

        # 生成建议
        if len(analysis["dimension_columns"]) == 0:
            analysis["recommendations"].append("未检测到维度列，可能需要手动指定")

        if len(analysis["metric_columns"]) == 0:
            analysis["recommendations"].append("未检测到指标列，请检查列名")

        if len(analysis["other_columns"]) > 5:
            analysis["recommendations"].append(f"存在 {len(analysis['other_columns'])} 个其他列，可能是细维度，将尝试聚合")

        return analysis


class InternalDataQuery:
    """内部数据查询器（SQLite）"""

    def __init__(
        self,
        db_path_creative: str,
        db_path_roi: str,
        target_date: str
    ):
        """
        初始化查询器

        Args:
            db_path_creative: 投放基础数据数据库路径
            db_path_roi: ROI预测数据数据库路径
            target_date: 目标日期 (YYYY-MM-DD)
        """
        self.db_path_creative = db_path_creative
        self.db_path_roi = db_path_roi
        self.target_date = target_date
        self.target_date_obj = datetime.strptime(target_date, "%Y-%m-%d")

    def query_creative_data(self) -> Dict[str, Any]:
        """
        查询投放基础数据

        Returns:
            包含投放数据的字典
        """
        if not Path(self.db_path_creative).exists():
            print(f"警告：投放数据库不存在: {self.db_path_creative}", file=sys.stderr)
            return {"exists": False, "data": {}}

        try:
            conn = sqlite3.connect(self.db_path_creative)
            cursor = conn.cursor()

            # 查询目标日期的数据
            date_str = self.target_date

            # 尝试查询表结构，假设存在常见的投放表
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = [row[0] for row in cursor.fetchall()]

            if not tables:
                conn.close()
                return {"exists": True, "tables": [], "data": {}}

            # 尝试查询创意/活动粒度的数据
            # 这里假设表结构，实际需要根据真实表结构调整
            data = {}

            # 尝试多个可能的表名
            possible_tables = ['creative_performance', 'campaign_performance',
                              'activate_performance', 'performance_data']

            for table in possible_tables:
                if table in tables:
                    try:
                        # 查询表结构
                        cursor.execute(f"PRAGMA table_info({table})")
                        columns = [col[1] for col in cursor.fetchall()]

                        # 尝试查询数据
                        query = f"SELECT * FROM {table}"
                        if 'date' in columns:
                            query += f" WHERE date = '{date_str}'"
                        elif 'report_date' in columns:
                            query += f" WHERE report_date = '{date_str}'"

                        cursor.execute(query)
                        rows = cursor.fetchall()
                        data[table] = {
                            "columns": columns,
                            "rows": [list(row) for row in rows],
                            "count": len(rows)
                        }
                    except Exception as e:
                        print(f"查询表 {table} 时出错: {str(e)}", file=sys.stderr)
                        continue

            conn.close()

            return {
                "exists": True,
                "tables": tables,
                "data": data
            }

        except Exception as e:
            print(f"查询投放数据时出错: {str(e)}", file=sys.stderr)
            return {"exists": False, "error": str(e), "data": {}}

    def query_roi_data(self) -> Dict[str, Any]:
        """
        查询ROI预测数据

        Returns:
            包含ROI预测数据的字典
        """
        if not Path(self.db_path_roi).exists():
            print(f"警告：ROI数据库不存在: {self.db_path_roi}", file=sys.stderr)
            return {"exists": False, "data": {}}

        try:
            conn = sqlite3.connect(self.db_path_roi)
            cursor = conn.cursor()

            # 查询表结构
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = [row[0] for row in cursor.fetchall()]

            if not tables:
                conn.close()
                return {"exists": True, "tables": [], "data": {}}

            data = {}

            # 尝试查询ROI预测数据
            possible_tables = ['roi_predict', 'roi_distribution',
                              'campaign_roi', 'roi_campaign']

            date_str = self.target_date

            for table in possible_tables:
                if table in tables:
                    try:
                        cursor.execute(f"PRAGMA table_info({table})")
                        columns = [col[1] for col in cursor.fetchall()]

                        query = f"SELECT * FROM {table}"
                        if 'date' in columns:
                            query += f" WHERE date = '{date_str}'"
                        elif 'report_date' in columns:
                            query += f" WHERE report_date = '{date_str}'"

                        cursor.execute(query)
                        rows = cursor.fetchall()
                        data[table] = {
                            "columns": columns,
                            "rows": [list(row) for row in rows],
                            "count": len(rows)
                        }
                    except Exception as e:
                        print(f"查询表 {table} 时出错: {str(e)}", file=sys.stderr)
                        continue

            conn.close()

            return {
                "exists": True,
                "tables": tables,
                "data": data
            }

        except Exception as e:
            print(f"查询ROI数据时出错: {str(e)}", file=sys.stderr)
            return {"exists": False, "error": str(e), "data": {}}

    def calculate_metrics(self) -> Dict[str, Any]:
        """
        计算核心指标

        Returns:
            包含所有计算指标的字典
        """
        creative_data = self.query_creative_data()
        roi_data = self.query_roi_data()

        # 基础指标（占位符，实际需要根据数据结构调整）
        metrics = {
            "target_date": self.target_date,
            "creative_data": creative_data,
            "roi_data": roi_data,
            "summary": {
                "total_spend": 0.0,
                "total_conversions": 0,
                "roi": 0.0,
                "cpa": 0.0
            },
            "comparison": {
                "yesterday": {},
                "last_7_days_avg": {},
                "last_30_days_avg": {}
            }
        }

        # 尝试从查询结果中提取指标
        if creative_data.get("exists") and creative_data.get("data"):
            # 这里需要根据实际的表结构来提取指标
            # 以下为示例代码，需要根据实际情况调整
            for table_name, table_data in creative_data["data"].items():
                columns = table_data.get("columns", [])
                rows = table_data.get("rows", [])

                # 查找关键列
                spend_col = None
                conversion_col = None
                roi_col = None

                for i, col in enumerate(columns):
                    col_lower = col.lower()
                    if 'spend' in col_lower or 'cost' in col_lower or '消耗' in col_lower:
                        spend_col = i
                    elif 'conversion' in col_lower or '转化' in col_lower:
                        conversion_col = i
                    elif 'roi' in col_lower:
                        roi_col = i

                # 汇总数据
                total_spend = 0.0
                total_conversions = 0

                for row in rows:
                    if spend_col is not None and isinstance(row[spend_col], (int, float)):
                        total_spend += float(row[spend_col])
                    if conversion_col is not None and isinstance(row[conversion_col], (int, float)):
                        total_conversions += float(row[conversion_col])

                # 计算CPA
                cpa = total_spend / total_conversions if total_conversions > 0 else 0

                metrics["summary"]["total_spend"] = round(total_spend, 2)
                metrics["summary"]["total_conversions"] = int(total_conversions)
                metrics["summary"]["cpa"] = round(cpa, 2)

                if roi_col is not None:
                    # 取平均ROI
                    roi_values = [float(row[roi_col]) for row in rows
                                if roi_col is not None and isinstance(row[roi_col], (int, float))
                                and row[roi_col] is not None]
                    avg_roi = sum(roi_values) / len(roi_values) if roi_values else 0
                    metrics["summary"]["roi"] = round(avg_roi, 2)

        return metrics

    def get_top_performers(self, top_n: int = 10) -> List[Dict[str, Any]]:
        """
        获取表现最好的创意/活动

        Args:
            top_n: 返回前N个

        Returns:
            Top表现列表
        """
        creative_data = self.query_creative_data()
        top_performers = []

        if not creative_data.get("exists") or not creative_data.get("data"):
            return top_performers

        # 这里需要根据实际的表结构来提取Top表现
        # 以下为示例代码
        for table_name, table_data in creative_data["data"].items():
            columns = table_data.get("columns", [])
            rows = table_data.get("rows", [])

            if len(rows) == 0:
                continue

            # 查找ROI或转化率列进行排序
            roi_col = None
            name_col = None
            spend_col = None

            for i, col in enumerate(columns):
                col_lower = col.lower()
                if 'roi' in col_lower:
                    roi_col = i
                elif 'name' in col_lower or 'id' in col_lower or '创意' in col_lower:
                    name_col = i
                elif 'spend' in col_lower or 'cost' in col_lower or '消耗' in col_lower:
                    spend_col = i

            if roi_col is not None:
                # 按ROI排序
                sorted_rows = sorted(
                    [r for r in rows if isinstance(r[roi_col], (int, float)) and r[roi_col] is not None],
                    key=lambda x: float(x[roi_col]),
                    reverse=True
                )

                for row in sorted_rows[:top_n]:
                    item = {
                        "roi": float(row[roi_col]),
                        "name": str(row[name_col]) if name_col is not None else "Unknown"
                    }
                    if spend_col is not None and isinstance(row[spend_col], (int, float)):
                        item["spend"] = float(row[spend_col])
                    top_performers.append(item)

        return top_performers[:top_n]


class AxonDataQuery:
    """Axon平台数据查询器（CSV）"""

    def __init__(
        self,
        cache_path: str,
        roi_predict_path: Optional[str],
        target_date: str
    ):
        """
        初始化Axon查询器

        Args:
            cache_path: Axon缓存CSV路径
            roi_predict_path: Axon ROI预测CSV路径（可选）
            target_date: 目标日期 (YYYY-MM-DD)
        """
        self.cache_path = cache_path
        self.roi_predict_path = roi_predict_path
        self.target_date = target_date
        self.target_date_obj = datetime.strptime(target_date, "%Y-%m-%d")

    def query_cache_data(self) -> Dict[str, Any]:
        """
        查询Axon缓存数据（支持智能维度聚合）

        Returns:
            包含缓存数据的字典
        """
        if not Path(self.cache_path).exists():
            print(f"警告：Axon缓存文件不存在: {self.cache_path}", file=sys.stderr)
            return {"exists": False, "data": {}}

        try:
            with open(self.cache_path, 'r', encoding='utf-8') as f:
                reader = csv.reader(f)
                headers = next(reader)

                # 智能检测列类型
                print(f"正在分析Axon缓存文件列结构...", file=sys.stderr)
                column_analysis = DataAggregator.analyze_columns(headers)

                if column_analysis["recommendations"]:
                    print(f"列分析建议: {'; '.join(column_analysis['recommendations'])}", file=sys.stderr)

                # 检测维度和指标列
                dimension_cols = DataAggregator.detect_dimension_columns(headers)
                metric_cols = DataAggregator.detect_metric_columns(headers)

                # 检测日期列
                date_col_idx = None
                for i, col in enumerate(headers):
                    col_lower = col.lower()
                    if DataAggregator.STANDARD_METRICS['date'][0].lower() in col_lower or 't' == col_lower:
                        date_col_idx = i
                        break

                # 读取所有行
                all_rows = list(reader)

                # 过滤目标日期范围的数据（T-3到T-1）
                filtered_rows = []
                target_date_obj = self.target_date_obj

                for row in all_rows:
                    if len(row) <= max([date_col_idx] + list(dimension_cols.values()) + list(metric_cols.values())):
                        continue

                    # 过滤日期
                    if date_col_idx is not None:
                        try:
                            row_date_str = str(row[date_col_idx])
                            row_date_obj = datetime.strptime(row_date_str, "%Y-%m-%d")

                            # 只保留T-3到T-1的数据
                            date_diff = (target_date_obj - row_date_obj).days
                            if 1 <= date_diff <= 3:
                                filtered_rows.append(row)
                        except (ValueError, TypeError):
                            continue
                    else:
                        # 如果没有日期列，保留所有行
                        filtered_rows.append(row)

                # 聚合数据
                print(f"检测到 {len(dimension_cols)} 个维度列, {len(metric_cols)} 个指标列", file=sys.stderr)
                print(f"过滤后行数: {len(filtered_rows)}", file=sys.stderr)

                if dimension_cols:
                    aggregated_rows, standard_columns = DataAggregator.aggregate_rows(
                        rows=filtered_rows,
                        columns=headers,
                        dimension_cols=dimension_cols,
                        metric_cols=metric_cols,
                        date_col=date_col_idx,
                        target_date=None  # 已经在过滤阶段处理日期
                    )

                    print(f"聚合后数据量: {len(aggregated_rows)}", file=sys.stderr)
                    print(f"标准列名: {standard_columns}", file=sys.stderr)

                    return {
                        "exists": True,
                        "original_headers": headers,
                        "headers": standard_columns,
                        "rows": aggregated_rows,
                        "count": len(aggregated_rows),
                        "column_analysis": column_analysis,
                        "aggregated": True
                    }
                else:
                    # 如果没有维度列，返回原始数据
                    return {
                        "exists": True,
                        "original_headers": headers,
                        "headers": headers,
                        "rows": filtered_rows,
                        "count": len(filtered_rows),
                        "column_analysis": column_analysis,
                        "aggregated": False
                    }

        except Exception as e:
            print(f"查询Axon缓存数据时出错: {str(e)}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            return {"exists": False, "error": str(e), "data": {}}

    def query_roi_predict_data(self) -> Dict[str, Any]:
        """
        查询Axon ROI预测数据（支持智能维度聚合）

        Returns:
            包含ROI预测数据的字典
        """
        if not self.roi_predict_path or not Path(self.roi_predict_path).exists():
            print(f"警告：Axon ROI预测文件不存在或未指定: {self.roi_predict_path}", file=sys.stderr)
            return {"exists": False, "data": {}}

        try:
            with open(self.roi_predict_path, 'r', encoding='utf-8') as f:
                reader = csv.reader(f)
                headers = next(reader)

                # 智能检测列类型
                print(f"正在分析Axon ROI预测文件列结构...", file=sys.stderr)
                column_analysis = DataAggregator.analyze_columns(headers)

                # 检测维度和指标列
                dimension_cols = DataAggregator.detect_dimension_columns(headers)
                metric_cols = DataAggregator.detect_metric_columns(headers)

                # 检测日期列
                date_col_idx = None
                for i, col in enumerate(headers):
                    col_lower = col.lower()
                    if DataAggregator.STANDARD_METRICS['date'][0].lower() in col_lower or 't' == col_lower:
                        date_col_idx = i
                        break

                # 读取所有行
                all_rows = list(reader)

                # 过滤目标日期范围的数据（T-15到T-1）
                filtered_rows = []
                target_date_obj = self.target_date_obj

                for row in all_rows:
                    if len(row) <= max([date_col_idx] + list(dimension_cols.values()) + list(metric_cols.values())):
                        continue

                    # 过滤日期
                    if date_col_idx is not None:
                        try:
                            row_date_str = str(row[date_col_idx])
                            row_date_obj = datetime.strptime(row_date_str, "%Y-%m-%d")

                            # 只保留T-15到T-1的数据
                            date_diff = (target_date_obj - row_date_obj).days
                            if 1 <= date_diff <= 15:
                                filtered_rows.append(row)
                        except (ValueError, TypeError):
                            continue
                    else:
                        # 如果没有日期列，保留所有行
                        filtered_rows.append(row)

                # 聚合数据
                if dimension_cols:
                    aggregated_rows, standard_columns = DataAggregator.aggregate_rows(
                        rows=filtered_rows,
                        columns=headers,
                        dimension_cols=dimension_cols,
                        metric_cols=metric_cols,
                        date_col=date_col_idx,
                        target_date=None
                    )

                    return {
                        "exists": True,
                        "original_headers": headers,
                        "headers": standard_columns,
                        "rows": aggregated_rows,
                        "count": len(aggregated_rows),
                        "column_analysis": column_analysis,
                        "aggregated": True
                    }
                else:
                    # 如果没有维度列，返回原始数据
                    return {
                        "exists": True,
                        "original_headers": headers,
                        "headers": headers,
                        "rows": filtered_rows,
                        "count": len(filtered_rows),
                        "column_analysis": column_analysis,
                        "aggregated": False
                    }

        except Exception as e:
            print(f"查询Axon ROI预测数据时出错: {str(e)}", file=sys.stderr)
            import traceback
            traceback.print_exc()
            return {"exists": False, "error": str(e), "data": {}}

    def calculate_metrics(self) -> Dict[str, Any]:
        """
        计算Axon核心指标

        Returns:
            包含所有计算指标的字典
        """
        cache_data = self.query_cache_data()
        roi_predict_data = self.query_roi_predict_data()

        metrics = {
            "target_date": self.target_date,
            "cache_data": cache_data,
            "roi_predict_data": roi_predict_data,
            "summary": {
                "total_spend": 0.0,
                "total_conversions": 0,
                "roas": 0.0,
                "cpa": 0.0
            }
        }

        # 从缓存数据提取指标
        if cache_data.get("exists") and cache_data.get("rows"):
            headers = cache_data.get("headers", [])
            headers_lower = [h.lower() for h in headers]
            rows = cache_data.get("rows", [])

            # 查找关键列
            spend_col = None
            roi1_col = None
            roi3_col = None
            roi7_col = None
            campaign_col = None

            for i, h in enumerate(headers_lower):
                if '消耗' in h or 'spend' in h or 'cost' in h:
                    spend_col = i
                elif 'roi1' in h:
                    roi1_col = i
                elif 'roi3' in h:
                    roi3_col = i
                elif 'roi7' in h:
                    roi7_col = i
                elif 'campaign' in h or '活动' in h:
                    campaign_col = i

            # 汇总数据
            total_spend = 0.0
            roi1_values = []

            for row in rows:
                if spend_col is not None and spend_col < len(row):
                    try:
                        total_spend += float(row[spend_col])
                    except (ValueError, TypeError):
                        pass

                if roi1_col is not None and roi1_col < len(row):
                    try:
                        roi1_values.append(float(row[roi1_col]))
                    except (ValueError, TypeError):
                        pass

            # 计算平均值
            metrics["summary"]["total_spend"] = round(total_spend, 2)
            if roi1_values:
                metrics["summary"]["roas"] = round(sum(roi1_values) / len(roi1_values), 2)

            # 从ROI预测数据提取多周期预测
            if roi_predict_data.get("exists") and roi_predict_data.get("rows"):
                roi_headers = roi_predict_data.get("headers", [])
                roi_headers_lower = [h.lower() for h in roi_headers]
                roi_rows = roi_predict_data.get("rows", [])

                # 查找预测列
                predict_cols = {}
                for i, h in enumerate(roi_headers_lower):
                    if 'predict' in h:
                        predict_cols[h] = i

                # 汇总预测值
                predictions = {}
                for pred_name, col_idx in predict_cols.items():
                    values = []
                    for row in roi_rows:
                        if col_idx < len(row):
                            try:
                                values.append(float(row[col_idx]))
                            except (ValueError, TypeError):
                                pass
                    if values:
                        predictions[pred_name] = round(sum(values) / len(values), 2)

                metrics["summary"]["predictions"] = predictions

        return metrics

    def get_top_performers(self, top_n: int = 10) -> List[Dict[str, Any]]:
        """
        获取Axon表现最好的活动

        Args:
            top_n: 返回前N个

        Returns:
            Top表现列表
        """
        cache_data = self.query_cache_data()
        top_performers = []

        if not cache_data.get("exists") or not cache_data.get("rows"):
            return top_performers

        headers = cache_data.get("headers", [])
        headers_lower = [h.lower() for h in headers]
        rows = cache_data.get("rows", [])

        if len(rows) == 0:
            return top_performers

        # 查找关键列
        roi1_col = None
        campaign_col = None
        spend_col = None

        for i, h in enumerate(headers_lower):
            if 'roi1' in h:
                roi1_col = i
            elif 'campaign' in h or '活动' in h:
                campaign_col = i
            elif '消耗' in h or 'spend' in h or 'cost' in h:
                spend_col = i

        if roi1_col is not None:
            # 按ROAS排序
            sorted_rows = sorted(
                [r for r in rows if roi1_col < len(r) and isinstance(r[roi1_col], (int, float))],
                key=lambda x: float(x[roi1_col]),
                reverse=True
            )

            for row in sorted_rows[:top_n]:
                item = {
                    "roas": float(row[roi1_col])
                }
                if campaign_col is not None and campaign_col < len(row):
                    item["campaign"] = str(row[campaign_col])
                if spend_col is not None and spend_col < len(row):
                    try:
                        item["spend"] = float(row[spend_col])
                    except (ValueError, TypeError):
                        pass
                top_performers.append(item)

        return top_performers[:top_n]

    def get_monitor_table(self, days: int = 3) -> Dict[str, Any]:
        """
        获取Axon基础数据监控表格

        Args:
            days: 查询天数（默认3天：T-3、T-2、T-1）

        Returns:
            包含监控表格数据的字典，按camp升序、dt倒序排列
            显示字段：campaign, dt, 激活量, 消耗, CPA, 首日ROI
        """
        cache_data = self.query_cache_data()

        if not cache_data.get("exists") or not cache_data.get("rows"):
            return {
                "exists": False,
                "data": [],
                "headers": []
            }

        headers = cache_data.get("headers", [])
        headers_lower = [h.lower() for h in headers]
        rows = cache_data.get("rows", [])

        # 查找关键列
        campaign_col = None
        dt_col = None
        activation_col = None
        spend_col = None
        cpa_col = None
        roi1_col = None

        for i, h in enumerate(headers_lower):
            if 'campaign' in h or '活动' in h:
                campaign_col = i
            elif 'dt' in h or 'date' in h or 't' in h:
                dt_col = i
            elif '激活量' in h or 'activation' in h:
                activation_col = i
            elif '消耗' in h or 'spend' in h or 'cost' in h:
                spend_col = i
            elif 'cpa' in h:
                cpa_col = i
            elif 'roi1' in h or '首日roi' in h:
                roi1_col = i

        # 计算日期范围：T-days ~ T-1
        target_date_minus_days = set()
        for i in range(1, days + 1):
            target_date_minus_days.add(self.target_date_obj - timedelta(days=i))

        # 构建表格数据
        table_data = []

        for row in rows:
            # 确保数据完整
            if len(row) <= max(campaign_col or 0, dt_col or 0, spend_col or 0):
                continue

            # 提取日期
            row_date = None
            if dt_col is not None and dt_col < len(row):
                try:
                    date_str = str(row[dt_col]).split()[0]
                    row_date = datetime.strptime(date_str, "%Y-%m-%d")
                except (ValueError, IndexError):
                    continue

            # 只保留最近days天的数据（T-days ~ T-1）
            if row_date and row_date in target_date_minus_days:
                item = {}

                # 提取各字段
                if campaign_col is not None and campaign_col < len(row):
                    item["campaign"] = str(row[campaign_col])

                if dt_col is not None and dt_col < len(row):
                    item["dt"] = str(row[dt_col])

                if activation_col is not None and activation_col < len(row):
                    try:
                        item["激活量"] = int(row[activation_col])
                    except (ValueError, TypeError):
                        item["激活量"] = 0

                if spend_col is not None and spend_col < len(row):
                    try:
                        item["消耗"] = float(row[spend_col])
                    except (ValueError, TypeError):
                        item["消耗"] = 0.0

                # 计算CPA（如果没有直接提供）
                if cpa_col is not None and cpa_col < len(row):
                    try:
                        item["CPA"] = float(row[cpa_col])
                    except (ValueError, TypeError):
                        # 如果有消耗和激活量，计算CPA
                        if item.get("消耗", 0) > 0 and item.get("激活量", 0) > 0:
                            item["CPA"] = round(item["消耗"] / item["激活量"], 2)
                        else:
                            item["CPA"] = 0.0
                else:
                    # 如果没有CPA列，根据消耗和激活量计算
                    if item.get("消耗", 0) > 0 and item.get("激活量", 0) > 0:
                        item["CPA"] = round(item["消耗"] / item["激活量"], 2)
                    else:
                        item["CPA"] = 0.0

                if roi1_col is not None and roi1_col < len(row):
                    try:
                        item["首日ROI"] = float(row[roi1_col])
                    except (ValueError, TypeError):
                        item["首日ROI"] = 0.0

                table_data.append(item)

        # 排序：camp升序、dt倒序
        # dt需要转换为日期格式进行比较
        def sort_key(item):
            campaign = item.get("campaign", "")
            dt_str = item.get("dt", "")

            # 尝试解析日期
            try:
                # 支持多种日期格式
                if '-' in dt_str:
                    dt_obj = datetime.strptime(dt_str.split()[0], "%Y-%m-%d")
                elif '/' in dt_str:
                    dt_obj = datetime.strptime(dt_str.split()[0], "%Y/%m/%d")
                else:
                    dt_obj = datetime.strptime(dt_str.split()[0], "%Y%m%d")
            except (ValueError, IndexError):
                dt_obj = datetime.min

            return (campaign, -dt_obj.timestamp())  # dt倒序用负时间戳

        table_data.sort(key=sort_key)

        # 构建表头
        table_headers = ["campaign", "dt", "激活量", "消耗", "CPA", "首日ROI"]

        return {
            "exists": True,
            "headers": table_headers,
            "data": table_data,
            "count": len(table_data),
            "date_range": {
                "start": (self.target_date_obj - timedelta(days=days)).strftime("%Y-%m-%d"),
                "end": (self.target_date_obj - timedelta(days=1)).strftime("%Y-%m-%d"),
                "days": days
            }
        }


def get_platform_comparison(
    db_path_creative: str,
    db_path_roi: str,
    axon_cache_path: str,
    axon_roi_predict_path: str,
    target_date: str,
    comparison_type: str = "7day"
) -> Dict[str, Any]:
    """
    获取内部平台与Axon平台的对比数据

    Args:
        db_path_creative: 内部投放数据库路径
        db_path_roi: 内部ROI数据库路径
        axon_cache_path: Axon缓存CSV路径
        axon_roi_predict_path: Axon ROI预测CSV路径
        target_date: 目标日期 (YYYY-MM-DD)
        comparison_type: 对比类型（daily/7day）
            - daily: 单日对比（T-1，用于看GAP）
            - 7day: 滚动7日对比（T-15~T-9）

    Returns:
        包含平台对比数据的字典
    """
    target_date_obj = datetime.strptime(target_date, "%Y-%m-%d")

    # 根据对比类型计算日期范围
    if comparison_type == "daily":
        # 单日对比：T-1
        start_date = target_date_obj - timedelta(days=1)
        end_date = start_date
    else:
        # 滚动7日对比：T-15~T-9
        start_date = target_date_obj - timedelta(days=15)
        end_date = target_date_obj - timedelta(days=9)

    comparison_data = []

    # 1. 查询内部平台数据
    internal_query = InternalDataQuery(db_path_creative, db_path_roi, target_date)
    internal_creative = internal_query.query_creative_data()

    # 汇总内部平台数据（按campaign聚合）
    internal_campaigns = {}
    if internal_creative.get("exists") and internal_creative.get("data"):
        for table_name, table_data in internal_creative["data"].items():
            columns = table_data.get("columns", [])
            rows = table_data.get("rows", [])

            # 查找关键列
            campaign_col = None
            spend_col = None
            activation_col = None
            roi_col = None
            date_col = None

            for i, col in enumerate(columns):
                col_lower = col.lower()
                if 'campaign' in col_lower or '活动' in col_lower:
                    campaign_col = i
                elif 'spend' in col_lower or 'cost' in col_lower or '消耗' in col_lower:
                    spend_col = i
                elif 'activation' in col_lower or '激活' in col_lower:
                    activation_col = i
                elif 'roi' in col_lower and 'roi1' not in col_lower:
                    roi_col = i
                elif 'date' in col_lower or 'dt' in col_lower or 't' in col_lower:
                    date_col = i

            # 聚合数据
            for row in rows:
                if len(row) <= max(campaign_col or 0, spend_col or 0, date_col or 0):
                    continue

                # 提取日期
                row_date = None
                if date_col is not None:
                    try:
                        date_str = str(row[date_col]).split()[0]
                        row_date = datetime.strptime(date_str, "%Y-%m-%d")
                    except (ValueError, IndexError):
                        continue

                # 只保留T-15~T-9的数据
                if row_date and start_date <= row_date <= end_date:
                    campaign_id = str(row[campaign_col]) if campaign_col is not None else "Unknown"

                    if campaign_id not in internal_campaigns:
                        internal_campaigns[campaign_id] = {
                            "campaign": campaign_id,
                            "platform": "内部",
                            "消耗": 0.0,
                            "激活量": 0,
                            "1日ROI": 0.0,
                            "3日ROI": 0.0,
                            "7日ROI": 0.0,
                            "14日预测ROI": None,
                            "30日预测ROI": None,
                            "45日预测ROI": None,
                            "60日预测ROI": None,
                            "120日预测ROI": None,
                            "180日预测ROI": None
                        }

                    # 累加数据
                    if spend_col is not None and isinstance(row[spend_col], (int, float)):
                        internal_campaigns[campaign_id]["消耗"] += float(row[spend_col])

                    if activation_col is not None and isinstance(row[activation_col], (int, float)):
                        internal_campaigns[campaign_id]["激活量"] += int(row[activation_col])

                    # ROI取平均值（简化处理）
                    if roi_col is not None and isinstance(row[roi_col], (int, float)):
                        internal_campaigns[campaign_id]["1日ROI"] = float(row[roi_col])

    # 计算内部平台的CPA
    for campaign_id, data in internal_campaigns.items():
        if data["激活量"] > 0:
            data["CPA"] = round(data["消耗"] / data["激活量"], 2)
        else:
            data["CPA"] = 0.0

    # 2. 查询Axon平台数据
    axon_query = AxonDataQuery(axon_cache_path, axon_roi_predict_path, target_date)
    axon_cache = axon_query.query_cache_data()
    axon_roi_predict = axon_query.query_roi_predict_data()

    # 汇总Axon平台数据
    axon_campaigns = {}

    # 处理缓存数据
    if axon_cache.get("exists") and axon_cache.get("rows"):
        headers = axon_cache.get("headers", [])
        headers_lower = [h.lower() for h in headers]
        rows = axon_cache.get("rows", [])

        campaign_col = None
        dt_col = None
        spend_col = None
        activation_col = None
        roi1_col = None
        roi3_col = None
        roi7_col = None

        for i, h in enumerate(headers_lower):
            if 'campaign' in h or '活动' in h:
                campaign_col = i
            elif 'dt' in h or 'date' in h or 't' in h:
                dt_col = i
            elif '消耗' in h or 'spend' in h or 'cost' in h:
                spend_col = i
            elif '激活量' in h or 'activation' in h:
                activation_col = i
            elif 'roi1' in h or '首日roi' in h:
                roi1_col = i
            elif 'roi3' in h:
                roi3_col = i
            elif 'roi7' in h:
                roi7_col = i

        for row in rows:
            if len(row) <= max(campaign_col or 0, dt_col or 0):
                continue

            # 提取日期
            row_date = None
            if dt_col is not None:
                try:
                    date_str = str(row[dt_col]).split()[0]
                    row_date = datetime.strptime(date_str, "%Y-%m-%d")
                except (ValueError, IndexError):
                    continue

            # 只保留T-15~T-9的数据
            if row_date and start_date <= row_date <= end_date:
                campaign_id = str(row[campaign_col]) if campaign_col is not None else "Unknown"

                if campaign_id not in axon_campaigns:
                    axon_campaigns[campaign_id] = {
                        "campaign": campaign_id,
                        "platform": "Axon",
                        "消耗": 0.0,
                        "激活量": 0,
                        "CPA": 0.0,
                        "1日ROI": 0.0,
                        "3日ROI": 0.0,
                        "7日ROI": 0.0,
                        "14日预测ROI": None,
                        "30日预测ROI": None,
                        "45日预测ROI": None,
                        "60日预测ROI": None,
                        "120日预测ROI": None,
                        "180日预测ROI": None
                    }

                # 累加数据
                if spend_col is not None and spend_col < len(row) and isinstance(row[spend_col], (int, float)):
                    axon_campaigns[campaign_id]["消耗"] += float(row[spend_col])

                if activation_col is not None and activation_col < len(row) and isinstance(row[activation_col], (int, float)):
                    axon_campaigns[campaign_id]["激活量"] += int(row[activation_col])

                if roi1_col is not None and roi1_col < len(row) and isinstance(row[roi1_col], (int, float)):
                    axon_campaigns[campaign_id]["1日ROI"] = float(row[roi1_col])

                if roi3_col is not None and roi3_col < len(row) and isinstance(row[roi3_col], (int, float)):
                    axon_campaigns[campaign_id]["3日ROI"] = float(row[roi3_col])

                if roi7_col is not None and roi7_col < len(row) and isinstance(row[roi7_col], (int, float)):
                    axon_campaigns[campaign_id]["7日ROI"] = float(row[roi7_col])

    # 计算Axon平台的CPA
    for campaign_id, data in axon_campaigns.items():
        if data["激活量"] > 0:
            data["CPA"] = round(data["消耗"] / data["激活量"], 2)
        else:
            data["CPA"] = 0.0

    # 处理Axon ROI预测数据（使用T-9的数据）
    if axon_roi_predict.get("exists") and axon_roi_predict.get("rows"):
        headers = axon_roi_predict.get("headers", [])
        headers_lower = [h.lower() for h in headers]
        rows = axon_roi_predict.get("rows", [])

        campaign_col = None
        dt_col = None

        # 查找预测列
        predict_cols = {}
        for i, h in enumerate(headers_lower):
            if 'campaign' in h or '活动' in h:
                campaign_col = i
            elif 'dt' in h or 'date' in h or 't' in h:
                dt_col = i
            elif 'predict' in h:
                predict_cols[h] = i

        for row in rows:
            if len(row) <= max(campaign_col or 0, dt_col or 0):
                continue

            # 提取日期
            row_date = None
            if dt_col is not None:
                try:
                    date_str = str(row[dt_col]).split()[0]
                    row_date = datetime.strptime(date_str, "%Y-%m-%d")
                except (ValueError, IndexError):
                    continue

            # 使用T-9的数据
            if row_date and row_date == end_date:
                campaign_id = str(row[campaign_col]) if campaign_col is not None else "Unknown"

                if campaign_id in axon_campaigns:
                    # 提取预测值
                    for pred_name, col_idx in predict_cols.items():
                        if col_idx < len(row) and isinstance(row[col_idx], (int, float)):
                            # 映射预测列名到显示字段
                            field_name = pred_name.replace('_predict', '').upper() + "预测ROI"
                            if field_name in axon_campaigns[campaign_id]:
                                axon_campaigns[campaign_id][field_name] = float(row[col_idx])

    # 3. 合并两个平台的数据
    all_campaigns = set(internal_campaigns.keys()) | set(axon_campaigns.keys())

    for campaign_id in sorted(all_campaigns):
        # 添加内部平台数据
        if campaign_id in internal_campaigns:
            comparison_data.append(internal_campaigns[campaign_id])

        # 添加Axon平台数据
        if campaign_id in axon_campaigns:
            comparison_data.append(axon_campaigns[campaign_id])

    # 4. 根据对比类型调整排序和字段
    if comparison_type == "daily":
        # 单日对比：campaign升序、平台升序
        comparison_data.sort(key=lambda x: (x["campaign"], x["platform"]))
        # 简化表头：仅显示基本字段
        table_headers = ["campaign", "平台", "消耗", "激活量", "CPA", "1日ROI"]
        # 简化数据：移除不需要的字段
        for item in comparison_data:
            item.pop("3日ROI", None)
            item.pop("7日ROI", None)
            item.pop("14日预测ROI", None)
            item.pop("30日预测ROI", None)
            item.pop("45日预测ROI", None)
            item.pop("60日预测ROI", None)
            item.pop("120日预测ROI", None)
            item.pop("180日预测ROI", None)
    else:
        # 滚动7日对比：campaign升序、平台升序
        comparison_data.sort(key=lambda x: (x["campaign"], x["platform"]))
        # 完整表头
        table_headers = [
            "campaign", "平台", "消耗", "激活量", "CPA",
            "1日ROI", "3日ROI", "7日ROI",
            "14日预测ROI", "30日预测ROI", "45日预测ROI",
            "60日预测ROI", "120日预测ROI", "180日预测ROI"
        ]

    return {
        "exists": True,
        "target_date": target_date,
        "comparison_type": comparison_type,
        "comparison_period": {
            "start": start_date.strftime("%Y-%m-%d"),
            "end": end_date.strftime("%Y-%m-%d"),
            "days": (end_date - start_date).days + 1
        },
        "headers": table_headers,
        "data": comparison_data,
        "count": len(comparison_data)
    }


def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description="查询增长日报数据（支持内部数据和Axon平台）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s --target-date 2025-01-15
  %(prog)s --target-date 2025-01-15 --platform internal
  %(prog)s --target-date 2025-01-15 --platform axon
  %(prog)s --target-date 2025-01-15 --platform all
        """
    )

    parser.add_argument(
        "--target-date",
        required=True,
        help="目标日期 (YYYY-MM-DD)"
    )

    parser.add_argument(
        "--platform",
        choices=["internal", "axon", "all"],
        default="all",
        help="查询平台 (internal/axon/all，默认all)"
    )

    # 内部数据路径
    parser.add_argument(
        "--db-path-creative",
        default="~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite",
        help="内部投放基础数据数据库路径"
    )

    parser.add_argument(
        "--db-path-roi",
        default="~/.openclaw/workspace/data_analysis/roi_predict/data/roi_predict_campaign_distribute_roi1_180_last4m.sqlite",
        help="内部ROI预测数据数据库路径"
    )

    # Axon数据路径
    parser.add_argument(
        "--axon-cache-path",
        default="~/.openclaw/workspace/exports/axon_monitor_cache.csv",
        help="Axon缓存CSV路径"
    )

    parser.add_argument(
        "--axon-roi-path",
        default="~/.openclaw/workspace/exports/axon_roi_predict.csv",
        help="Axon ROI预测CSV路径"
    )

    parser.add_argument(
        "--output-type",
        choices=["metrics", "monitor-table", "platform-comparison", "daily-comparison", "all"],
        default="metrics",
        help="输出类型 (metrics/monitor-table/platform-comparison/daily-comparison/all)"
    )

    args = parser.parse_args()

    # 展开路径中的 ~
    db_path_creative = Path(args.db_path_creative).expanduser()
    db_path_roi = Path(args.db_path_roi).expanduser()
    axon_cache_path = Path(args.axon_cache_path).expanduser()
    axon_roi_path = Path(args.axon_roi_path).expanduser() if args.axon_roi_path else None

    # 验证日期格式
    try:
        datetime.strptime(args.target_date, "%Y-%m-%d")
    except ValueError:
        print(f"错误：日期格式不正确，应为 YYYY-MM-DD，当前为 {args.target_date}", file=sys.stderr)
        sys.exit(1)

    # 构建结果
    result = {
        "target_date": args.target_date,
        "platform": args.platform
    }

    # 查询内部数据
    if args.platform in ["internal", "all"]:
        internal_query = InternalDataQuery(
            str(db_path_creative),
            str(db_path_roi),
            args.target_date
        )
        internal_metrics = internal_query.calculate_metrics()
        internal_top = internal_query.get_top_performers(top_n=10)

        result["internal"] = {
            "metrics": internal_metrics,
            "top_performers": internal_top
        }

    # 查询Axon数据
    if args.platform in ["axon", "all"]:
        axon_query = AxonDataQuery(
            str(axon_cache_path),
            str(axon_roi_path) if axon_roi_path else None,
            args.target_date
        )

        # 根据输出类型决定查询内容
        if args.output_type in ["metrics", "all"]:
            axon_metrics = axon_query.calculate_metrics()
            axon_top = axon_query.get_top_performers(top_n=10)

            result["axon"] = {
                "metrics": axon_metrics,
                "top_performers": axon_top
            }

        if args.output_type in ["monitor-table", "all"]:
            monitor_table = axon_query.get_monitor_table()
            result["axon_monitor_table"] = monitor_table

    # 如果只输出监控表格，简化结果
    if args.output_type == "monitor-table":
        monitor_table = result.get("axon_monitor_table", {})
        print(json.dumps(monitor_table, ensure_ascii=False, indent=2))
        return

    # 如果输出平台对比，执行平台对比查询
    if args.output_type == "platform-comparison":
        platform_comparison = get_platform_comparison(
            str(db_path_creative),
            str(db_path_roi),
            str(axon_cache_path),
            str(axon_roi_path) if axon_roi_path else "",
            args.target_date,
            comparison_type="7day"
        )
        print(json.dumps(platform_comparison, ensure_ascii=False, indent=2))
        return

    # 如果输出单日对比，执行单日对比查询
    if args.output_type == "daily-comparison":
        daily_comparison = get_platform_comparison(
            str(db_path_creative),
            str(db_path_roi),
            str(axon_cache_path),
            str(axon_roi_path) if axon_roi_path else "",
            args.target_date,
            comparison_type="daily"
        )
        print(json.dumps(daily_comparison, ensure_ascii=False, indent=2))
        return

    # 输出JSON
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
