---
name: axon-reporting
description: 查询指定包名 T-45 到 T-1 的 AppLovin Axon 广告投放数据；当用户需要获取特定应用的投放数据、分析 ROAS 性能或导出 CSV 报告时使用。
dependency:
  python:
    - requests>=2.31.0
    - pyyaml>=6.0
  system:
    - mkdir -p ~/.openclaw/workspace/exports
---

# Axon Reporting API Skill

## Description
AppLovin Axon 广告投放数据查询工具。支持固化查询指定包名 T-15 到 T-1 的数据，自动汇总统计并导出为 CSV 格式。

## When to Use
- 需要查询特定应用的 AppLovin Axon 广告投放数据时
- 需要分析应用 ROAS 性能和投放效果时
- 需要导出广告投放 CSV 报告时
- 需要监控指定包名的投放表现时

## Prerequisites
1. AppLovin Axon Reporting API 密钥
2. Python requests 库（已预装）

## API Configuration

### 配置方式

Axon Reporting Client 支持两种方式配置 API 密钥：

#### 1. 配置文件（推荐）

创建配置文件 `~/.openclaw/workspace/config/axon.yml`：

```yaml
api_key: "your_api_key_here"
```

#### 2. 环境变量

```bash
export COZE_AXON_API_7615249631357927458="your_api_key_here"
```

**优先级**：环境变量 > 配置文件

## Usage

### 固化查询

查询指定包名 T-45 到 T-1 的数据：

```bash
python ~/.openclaw/workspace/scripts/query_fixed_apps.py
```

#### 主调用脚本

```
~/.openclaw/workspace/scripts/query_fixed_apps.py
```

#### 查询包名

脚本会查询以下 9 个包名的数据：

1. `ios.pretty.boutique.merge.game`
2. `ios.his.grip.match.game`
3. `com.serenasecret.mergegame`
4. `com.serena.mergemakeover.ios`
5. `com.project.labuub.merge.game`
6. `com.mansion.affairs.merge.game`
7. `com.his.grip.match.game`
8. `com.gbd.amy.secret.game`
9. `com.amy.secret.game`

#### 查询特性

- **时间范围**：T-45 到 T-1（45天）
- **数据口径**：Cohort（按用户获取日期分组）
- **查询方式**：逐个包名查询，确保数据完整性
- **自动统计**：总记录数、总消耗、各包名详情
- **自动导出**：保存为 CSV 文件

#### 输出格式

CSV 文件包含以下列：

| 列名 | 说明 | 数据来源 |
|------|------|----------|
| 日期 | 用户获取日期 | day |
| campaign | Campaign 名称 | campaign |
| 包名 | 应用包名 | app |
| 国家 | 国家代码 | country |
| 消耗 | 消耗成本 | cost |
| 激活量 | 转化数（激活量） | conversions |
| CPA | CPA（每次转化成本） | cost / conversions |
| ROI1 | D1 ROI（小数格式） | roas_1d（格式化） |
| ROI3 | D3 ROI（小数格式） | roas_3d（格式化） |
| ROI7 | D7 ROI（小数格式） | roas_7d（格式化） |

#### 数据处理规则

- **ROI 格式转换**：百分比转小数（50% → 0.5）
  - 如果 ROI > 10，自动除以 100 转换为小数
  - 否则保持原值
- **CPA 自动计算**：CPA = Cost / Conversions（Conversions = 0 时 CPA = 0）
- **激活量**：使用 conversions 字段，转换为整数

#### CSV 存储地址

```
~/.openclaw/workspace/exports/axon_monitor_cache.csv
```

#### 输出文件

- **保存路径**：`~/.openclaw/workspace/exports/axon_monitor_cache.csv`
- **文件格式**：CSV（UTF-8 编码）
- **列分隔符**：逗号

## Output Example

### 查询输出

```
======================================================================
📊 固化查询：指定包名 T-45 到 T-1 的数据
======================================================================

📅 查询时间范围: 2026-01-23 到 2026-03-09（45天）
📦 包名数量: 9 个
📊 查询口径: Cohort（按用户获取日期分组）
🔍 查询方式: 逐个包名查询
======================================================================

[1/9] 查询包名: ios.pretty.boutique.merge.game
----------------------------------------------------------------------
✅ 查询成功，共 15 条记录
💰 15日总消耗: $5,234.50

[2/9] 查询包名: ios.his.grip.match.game
----------------------------------------------------------------------
✅ 查询成功，共 12 条记录
💰 15日总消耗: $3,100.25

...

======================================================================
📊 查询汇总
======================================================================

📈 总体统计:
   总记录数: 120 条
   总消耗: $45,678.90
   有数据的包名数: 7/9

📦 各包名详情:
   ✅ ios.pretty.boutique.merge.game
      记录数: 15 | 消耗: $5,234.50
   ✅ ios.his.grip.match.game
      记录数: 12 | 消耗: $3,100.25
   ...

======================================================================
💾 保存数据
======================================================================

✅ 数据已保存到: ~/.openclaw/workspace/exports/axon_monitor_cache.csv
   共 120 条记录
   总消耗: $45,678.90
```

### CSV 文件示例

```csv
日期,campaign,包名,国家,消耗,激活量,CPA,ROI1,ROI3,ROI7
2026-02-22,InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260215,ios.his.grip.match.game,US,1000.5,100,10.01,0.15,0.35,0.66
2026-02-22,PrettyBoutique_AL_IOS_D7Ad_ROAS_20260220,ios.pretty.boutique.merge.game,GB,850.25,85,10.0,0.2,0.45,0.81
```

## Error Handling

### 常见问题

| 问题 | 可能原因 | 解决方案 |
|------|----------|----------|
| 查询结果为空 | 时间范围内无新用户获取 | 使用 Cohort 口径需要新用户获取数据 |
| API 认证失败 | API 密钥错误 | 检查配置文件中的 API 密钥 |
| 权限不足 | API Key 权限范围受限 | 确认 API Key 权限范围 |
| 某些包名无数据 | 该包名无新用户获取 | 正常情况，脚本会继续查询其他包名 |

### 状态码说明

| 状态码 | 说明 |
|--------|------|
| 200 | 请求成功 |
| 401 | 认证失败（API Key 错误） |
| 403 | 权限不足 |
| 429 | 请求频率过高 |
| 500+ | 服务器错误 |

## Technical Details

### 数据口径

- **Cohort 数据**：按用户获取日期分组（当前使用）
- **Realtime 数据**：按活动发生日期分组（不使用）

Cohort 数据适用于分析用户生命周期价值（LTV）和长期 ROI 表现。

### 查询参数

- **时间范围**：T-45 到 T-1（自动计算）
- **包名**：固定列表（9 个包名）
- **数据格式**：JSON
- **报告类型**：advertiser
- **数据口径**：Cohort（use_cohort=True）

### 数据列

查询时获取所有可用指标，保存时只输出 10 列（日期, campaign, 包名, 国家, 消耗, 激活量, CPA, ROI1, ROI3, ROI7）。

## Integration

### 与其他系统集成

生成的 CSV 文件可以被以下工具使用：
- Excel/Google Sheets
- 数据分析工具（Python pandas、R）
- BI 工具（Tableau、Power BI）
- 数据库导入工具

### 自动化

可以将脚本集成到定时任务中，实现定期数据查询：

```bash
# 每天早上 8 点执行
0 8 * * * /usr/bin/python3 ~/.openclaw/workspace/scripts/query_fixed_apps.py
```

## Notes

- 脚本使用标准 requests 库，无依赖冲突
- 自动创建导出目录（如不存在）
- CSV 文件使用 UTF-8 编码
- 支持中文字符和特殊字符
- 自动处理异常和错误
- ROI 值自动转换为小数格式（50% → 0.5）
