#!/usr/bin/env python3
"""
固化查询：查询指定包名 T-15 到 T-1 的数据

包名列表：
- ios.pretty.boutique.merge.game
- ios.his.grip.match.game
- com.serenasecret.mergegame
- com.serena.mergemakeover.ios
- com.project.labuub.merge.game
- com.mansion.affairs.merge.game
- com.his.grip.match.game
- com.gbd.amy.secret.game
- com.amy.secret.game
"""

import os
import sys
import csv
from datetime import datetime, timedelta

# 添加 scripts 目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 使用独立版本的客户端
try:
    from axon_reporting_standalone import AxonReportingClient
except ImportError as e:
    print(f"❌ 导入失败: {e}")
    sys.exit(1)

# 固化的包名列表
APP_PACKAGES = [
    "ios.pretty.boutique.merge.game",
    "ios.his.grip.match.game",
    "com.serenasecret.mergegame",
    "com.serena.mergemakeover.ios",
    "com.project.labuub.merge.game",
    "com.mansion.affairs.merge.game",
    "com.his.grip.match.game",
    "com.gbd.amy.secret.game",
    "com.amy.secret.game"
]

def query_fixed_apps():
    """
    固化查询指定包名 T-45 到 T-1 的数据
    """
    # 初始化客户端
    client = AxonReportingClient()
    
    # 计算时间范围（T-45 到 T-1）
    end_date = datetime.now()
    start_date = end_date - timedelta(days=45)
    
    start_str = start_date.strftime("%Y-%m-%d")
    end_str = end_date.strftime("%Y-%m-%d")
    
    print("=" * 70)
    print("📊 固化查询：指定包名 T-45 到 T-1 的数据")
    print("=" * 70)
    print(f"\n📅 查询时间范围: {start_str} 到 {end_str}（45天）")
    print(f"📦 包名数量: {len(APP_PACKAGES)} 个")
    print(f"📋 包名列表:")
    for i, app in enumerate(APP_PACKAGES, 1):
        print(f"   {i}. {app}")
    print(f"\n📊 查询口径: Cohort（按用户获取日期分组）")
    print(f"🔍 查询方式: 逐个包名查询")
    print("\n" + "=" * 70)
    
    # 存储所有查询结果
    all_data = []
    app_results = {}
    
    # 逐个包名查询
    for i, app_package in enumerate(APP_PACKAGES, 1):
        print(f"\n[{i}/{len(APP_PACKAGES)}] 查询包名: {app_package}")
        print("-" * 70)
        
        try:
            # 查询该包名的数据（使用 Cohort 口径）
            result = client.query(
                start=start_str,
                end=end_str,
                app=app_package,
                use_cohort=True  # 使用 Cohort 口径
            )
            
            if "data" in result and result["data"]:
                records = result["data"]
                print(f"✅ 查询成功，共 {len(records)} 条记录")
                
                # 计算该包名的总消耗
                total_cost = sum(float(row.get('cost', 0)) for row in records)
                print(f"💰 45日总消耗: ${total_cost:,.2f}")
                
                # 添加到总结果
                all_data.extend(records)
                app_results[app_package] = {
                    "count": len(records),
                    "total_cost": total_cost,
                    "records": records
                }
            else:
                print(f"⚠️  无数据")
                app_results[app_package] = {
                    "count": 0,
                    "total_cost": 0,
                    "records": []
                }
        
        except Exception as e:
            print(f"❌ 查询失败: {e}")
            app_results[app_package] = {
                "count": 0,
                "total_cost": 0,
                "error": str(e)
            }
    
    # 汇总结果
    print("\n" + "=" * 70)
    print("📊 查询汇总")
    print("=" * 70)
    
    total_records = len(all_data)
    total_cost = sum(float(row.get('cost', 0)) for row in all_data)
    
    print(f"\n📈 总体统计:")
    print(f"   总记录数: {total_records} 条")
    print(f"   总消耗: ${total_cost:,.2f}")
    print(f"   有数据的包名数: {len([k for k, v in app_results.items() if v.get('count', 0) > 0])}/{len(APP_PACKAGES)}")
    
    print(f"\n📦 各包名详情:")
    for app_package, result in app_results.items():
        count = result.get('count', 0)
        cost = result.get('total_cost', 0)
        status = "✅" if count > 0 else "⚠️"
        print(f"   {status} {app_package}")
        print(f"      记录数: {count} | 消耗: ${cost:,.2f}")
        if 'error' in result:
            print(f"      错误: {result['error']}")
    
    # 保存到 CSV
    if all_data:
        print("\n" + "=" * 70)
        print("💾 保存数据")
        print("=" * 70)
        
        filepath = save_to_csv(all_data, start_str, end_str)
        print(f"\n✅ 数据已保存到: {filepath}")
        print(f"   共 {len(all_data)} 条记录")
        print(f"   总消耗: ${total_cost:,.2f}")
        
        # 显示数据预览（前10条）
        print(f"\n📋 数据预览（前10条）:")
        for i, row in enumerate(all_data[:10], 1):
            day = row.get('day', 'N/A')
            campaign = row.get('campaign', 'N/A')
            app = row.get('app', 'N/A')
            country = row.get('country', 'N/A')
            cost = row.get('cost', 0)
            conversions = row.get('conversions', 0)
            cpa = calculate_cpa(cost, conversions)
            roi1 = format_roas(row.get('roas_1d', 0))
            roi3 = format_roas(row.get('roas_3d', 0))
            roi7 = format_roas(row.get('roas_7d', 0))
            print(f"   {i}. {day} | {campaign[:40]} | {app[:30]} | {country} | Cost: ${cost} | 激活: {conversions} | CPA: ${cpa} | ROI1: {roi1} | ROI3: {roi3} | ROI7: {roi7}")
        
        if len(all_data) > 10:
            print(f"   ... 还有 {len(all_data) - 10} 条记录")
    else:
        print("\n" + "=" * 70)
        print("⚠️  没有查询到任何数据")
        print("=" * 70)
        print("\n可能原因:")
        print("   1. 指定时间范围内无投放数据")
        print("   2. API Key 权限不足")
        print("   3. 包名配置错误")
        print("\n建议:")
        print("   1. 检查 API Key 配置")
        print("   2. 确认包名是否正确")
        print("   3. 确认是否有新用户获取（Cohort 口径需要新用户）")
    
    print("\n" + "=" * 70)
    print("✅ 查询完成")
    print("=" * 70)
    
    return all_data

def save_to_csv(data, start_date, end_date):
    """
    保存数据到 CSV 文件
    
    Args:
        data: 查询数据
        start_date: 开始日期
        end_date: 结束日期
    
    Returns:
        CSV 文件路径
    """
    # 定义输出列
    output_columns = [
        "日期",
        "campaign",
        "包名",
        "国家",
        "消耗",
        "激活量",
        "CPA",
        "ROI1",
        "ROI3",
        "ROI7"
    ]
    
    # 确定保存路径
    export_dir = os.path.expanduser("~/.openclaw/workspace/exports")
    os.makedirs(export_dir, exist_ok=True)
    
    filepath = os.path.join(export_dir, "axon_monitor_cache.csv")
    
    # 转换数据格式
    formatted_data = []
    for row in data:
        cost = float(row.get("cost", 0))
        conversions = float(row.get("conversions", 0))
        
        formatted_row = {
            "日期": row.get("day", ""),
            "campaign": row.get("campaign", ""),
            "包名": row.get("app", ""),
            "国家": row.get("country", ""),
            "消耗": cost,
            "激活量": int(conversions) if conversions > 0 else 0,
            "CPA": calculate_cpa(cost, conversions),
            "ROI1": format_roas(row.get("roas_1d", 0)),
            "ROI3": format_roas(row.get("roas_3d", 0)),
            "ROI7": format_roas(row.get("roas_7d", 0))
        }
        formatted_data.append(formatted_row)
    
    # 写入 CSV
    try:
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=output_columns)
            writer.writeheader()
            writer.writerows(formatted_data)
        
        return filepath
    except Exception as e:
        print(f"❌ 保存文件失败: {e}")
        return None

def calculate_cpa(cost: float, conversions: float) -> float:
    """
    计算 CPA
    
    Args:
        cost: 消耗
        conversions: 转化数
    
    Returns:
        CPA 值
    """
    try:
        if conversions and conversions > 0:
            return round(cost / conversions, 2)
        return 0.0
    except:
        return 0.0

def format_roas(roas_value) -> float:
    """
    格式化 ROAS 值（百分比转小数）
    
    Args:
        roas_value: ROAS 值
    
    Returns:
        格式化后的 ROAS 值（小数形式）
    """
    try:
        roas = float(roas_value)
        # 如果 ROAS > 10，可能是百分比格式，需要除以 100
        if roas > 10:
            return round(roas / 100, 2)
        return round(roas, 2)
    except:
        return 0.0

if __name__ == "__main__":
    query_fixed_apps()
