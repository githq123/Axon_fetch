#!/usr/bin/env python3
"""
独立的 Axon Reporting API 客户端（无外部依赖冲突版本）

使用标准 requests 库，避免与 coze_workload_identity 冲突
"""

import os
import json
import csv
import re
import yaml
import requests  # 使用标准 requests 库
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Union, Any
from dataclasses import dataclass
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# API配置
API_BASE_URL = "https://r.applovin.com/report"
skill_id = "7615249631357927458"

# 从环境变量或配置文件获取API密钥
def _load_api_key() -> Optional[str]:
    """
    加载API密钥
    
    优先级：
    1. 环境变量 COZE_AXON_API_7615249631357927458
    2. 配置文件 ~/.openclaw/workspace/config/axon.yml 中的 api_key
    3. 环境变量 AXON_API_KEY（兼容）
    """
    # 1. 优先尝试环境变量
    api_key = os.getenv("COZE_AXON_API_7615249631357927458")
    if api_key:
        logger.info("从环境变量 COZE_AXON_API_7615249631357927458 加载 API 密钥")
        return api_key
    
    # 2. 尝试从配置文件读取
    config_path = os.path.expanduser("~/.openclaw/workspace/config/axon.yml")
    try:
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
                if config and isinstance(config, dict):
                    api_key = config.get('api_key')
                    if api_key:
                        logger.info(f"从配置文件 {config_path} 加载 API 密钥")
                        return api_key
    except Exception as e:
        logger.warning(f"读取配置文件失败: {e}")
    
    # 3. 兼容旧环境变量名
    api_key = os.getenv("AXON_API_KEY")
    if api_key:
        logger.info("从环境变量 AXON_API_KEY 加载 API 密钥")
        return api_key
    
    logger.warning("未找到 API 密钥配置")
    return None

API_KEY = _load_api_key()

# 常用指标列
COMMON_METRICS = {
    "basic": ["day", "campaign", "impressions", "clicks", "conversions", "cost"],
    "roas_d0": ["roas_0d", "iap_roas_0d", "iap_rev_0d", "total_rev_0d"],
    "roas_d1": ["roas_1d", "iap_roas_1d", "iap_rev_1d", "total_rev_1d"],
    "roas_d3": ["roas_3d", "iap_roas_3d", "iap_rev_3d", "total_rev_3d"],
    "roas_d7": ["roas_7d", "iap_roas_7d", "iap_rev_7d", "total_rev_7d"],
    "roas_d28": ["roas_28d", "iap_roas_28d", "iap_rev_28d", "total_rev_28d"],
    "revenue": ["iap_rev_0d", "iap_rev_7d", "total_rev_0d", "total_rev_7d"],
    "retention": ["ret_7d", "ret_28d"],
    "advanced": ["installs", "spend", "cpi", "cpc", "ctr"]
}

# 完整指标列表（用于获取所有列）
ALL_METRICS = (
    ["day", "campaign", "platform", "country", "app", "network", "device"] +
    ["impressions", "clicks", "conversions", "cost"] +
    ["installs", "spend", "cpi", "cpc", "ctr"] +
    ["roas_0d", "roas_1d", "roas_3d", "roas_7d", "roas_28d"] +
    ["iap_roas_0d", "iap_roas_1d", "iap_roas_3d", "iap_roas_7d", "iap_roas_28d"] +
    ["iap_rev_0d", "iap_rev_1d", "iap_rev_3d", "iap_rev_7d", "iap_rev_28d"] +
    ["total_rev_0d", "total_rev_1d", "total_rev_3d", "total_rev_7d", "total_rev_28d"] +
    ["ret_7d", "ret_28d"]
)

@dataclass
class CampaignInfo:
    """Campaign 信息解析"""
    name: str
    app: str
    platform: str
    network: str
    target: str
    optimization: str
    date: str
    full_name: str
    
    @classmethod
    def from_name(cls, campaign_name: str) -> 'CampaignInfo':
        """从Campaign名称解析信息"""
        parts = campaign_name.split('_')
        if len(parts) >= 6:
            return cls(
                name=campaign_name,
                app=parts[0],
                platform=parts[1],
                network=parts[2],
                target=parts[3],
                optimization=parts[4],
                date=parts[5],
                full_name=campaign_name
            )
        return cls(
            name=campaign_name,
            app="unknown",
            platform="unknown",
            network="unknown",
            target="unknown",
            optimization="unknown",
            date="unknown",
            full_name=campaign_name
        )

class AxonAPIError(Exception):
    """Axon API错误异常"""
    pass

class AxonReportingClient:
    """AppLovin Axon Reporting API客户端（独立版本）"""
    
    def __init__(self, api_key: str = None, base_url: str = None):
        """
        初始化客户端
        
        Args:
            api_key: Axon Reporting API密钥
            base_url: API基础URL
        """
        self.api_key = api_key or API_KEY
        self.base_url = base_url or API_BASE_URL
        
        if not self.api_key:
            logger.warning("API密钥未设置，请检查配置文件或环境变量")
        
        # 使用标准 requests.Session
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "OpenClaw-Axon-Reporting-Client/1.0.0"
        })
    
    def _make_request(self, params: Dict) -> Dict:
        """
        发送API请求
        
        Args:
            params: 请求参数
            
        Returns:
            API响应数据
            
        Raises:
            AxonAPIError: API请求失败
        """
        try:
            response = self.session.get(self.base_url, params=params, timeout=30)
            response.raise_for_status()
            
            # 解析响应
            if params.get("format", "json") == "json":
                return response.json()
            else:
                return {"data": response.text, "format": "csv"}
                
        except requests.exceptions.RequestException as e:
            logger.error(f"API请求失败: {e}")
            raise AxonAPIError(f"API请求失败: {e}")
        except json.JSONDecodeError as e:
            logger.error(f"JSON解析失败: {e}")
            raise AxonAPIError(f"JSON解析失败: {e}")
    
    def query_campaign(self,
                      campaign_name: str,
                      start_date: str,
                      end_date: str = "now",
                      metrics: List[str] = None,
                      report_type: str = "advertiser",
                      format: str = "json",
                      use_cohort: bool = True) -> Dict:
        """
        查询单个Campaign数据

        Args:
            campaign_name: Campaign名称
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD 或 "now")
            metrics: 查询指标列表，None则使用D0 Total ROAS指标
            report_type: 报告类型 (advertiser/publisher)
            format: 返回格式 (json/csv)
            use_cohort: 使用cohort数据 (默认True)。False为realtime。

        Returns:
            查询结果
        """
        if not self.api_key:
            raise AxonAPIError("API密钥未设置")

        # 设置默认指标 - D0 Total ROAS
        if metrics is None:
            metrics = COMMON_METRICS["basic"] + ["roas_0d"]

        params = {
            "api_key": self.api_key,
            "start": start_date,
            "end": end_date,
            "columns": ",".join(metrics),
            "format": format,
            "report_type": report_type,
            "filter_campaign": campaign_name
        }

        # Add day_column for cohort data (default behavior)
        if use_cohort:
            params["day_column"] = "day"

        data_type = "cohort" if use_cohort else "realtime"
        logger.info(f"查询Campaign: {campaign_name}, 时间范围: {start_date} 到 {end_date} ({data_type})")
        return self._make_request(params)
    
    def query(self, **kwargs) -> Dict:
        """
        完全灵活的查询方法，所有参数都可选
        
        参数说明：
        - 时间参数（可选）：
          * start: 开始日期（YYYY-MM-DD格式），默认7天前
          * end: 结束日期（YYYY-MM-DD或"now"），默认"now"
        
        - 维度筛选（可选）：
          * campaign: Campaign名称
          * app: 应用名称
          * country: 国家代码（支持单个值如"US"或列表如["US", "GB"]）
          * platform: 平台（如iOS、Android）
          * network: 广告网络
          * device: 设备类型
        
        - 基础模糊查询（可选）：
          * campaign_like: Campaign名称包含匹配（不区分大小写）
          * app_like: 应用名称包含匹配
          * country_like: 国家代码包含匹配
          * platform_like: 平台名称包含匹配
          * network_like: 网络名称包含匹配
          * device_like: 设备类型包含匹配
        
        - 高级模糊查询（可选）：
          * campaign_fuzzy: Campaign名称高级模糊查询
          * product_fuzzy: 产品名称高级模糊查询
          * app_fuzzy: 应用名称高级模糊查询
          * country_fuzzy: 国家代码高级模糊查询
          * platform_fuzzy: 平台名称高级模糊查询
          * network_fuzzy: 网络名称高级模糊查询
          * device_fuzzy: 设备类型高级模糊查询
          * fuzzy_mode: 匹配模式（auto/contains/regex/wildcard/exact）
          * case_sensitive: 是否区分大小写（默认False）
        
        - 数值条件筛选（可选）：
          * min_cost: 最小消耗值
          * max_cost: 最大消耗值
          * min_impressions: 最小展示数
          * max_impressions: 最大展示数
          * min_clicks: 最小点击数
          * max_clicks: 最大点击数
          * min_conversions: 最小转化数
          * max_conversions: 最大转化数
          * min_roas_*: 最小ROAS（支持不同时间窗口）
          * max_roas_*: 最大ROAS（支持不同时间窗口）
          * min_iap_roas_*: 最小内购ROAS
          * max_iap_roas_*: 最大内购ROAS
        
        - 其他可选参数：
          * metrics: 查询指标列表（默认D0 Total ROAS指标）
          * report_type: 报告类型（默认"advertiser"）
          * format: 返回格式（默认"json"）
          * use_cohort: 是否使用cohort数据（默认True）
        
        Returns:
            查询结果字典
        """
        # 设置默认时间范围（最近7天）
        if "start" not in kwargs:
            kwargs["start"] = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
        if "end" not in kwargs:
            kwargs["end"] = "now"
        
        # 设置默认指标
        if "metrics" not in kwargs:
            kwargs["metrics"] = None
        
        # 设置默认值
        report_type = kwargs.get("report_type", "advertiser")
        format_type = kwargs.get("format", "json")
        use_cohort = kwargs.get("use_cohort", True)
        
        # 设置默认指标 - D0 Total ROAS
        metrics = kwargs.get("metrics")
        if metrics is None:
            metrics = COMMON_METRICS["basic"] + ["roas_0d"]
        
        # 构建请求参数
        params = {
            "api_key": self.api_key,
            "start": kwargs.get("start"),
            "end": kwargs.get("end"),
            "columns": ",".join(metrics),
            "format": format_type,
            "report_type": report_type
        }
        
        # 添加筛选条件
        if "campaign" in kwargs and kwargs["campaign"]:
            params["filter_campaign"] = kwargs["campaign"]
        
        if "app" in kwargs and kwargs["app"]:
            params["filter_app"] = kwargs["app"]
        
        if "country" in kwargs and kwargs["country"]:
            country = kwargs["country"]
            if isinstance(country, list):
                params["filter_country"] = ",".join(country)
            else:
                params["filter_country"] = country
        
        if "platform" in kwargs and kwargs["platform"]:
            params["filter_platform"] = kwargs["platform"]
        
        if "network" in kwargs and kwargs["network"]:
            params["filter_network"] = kwargs["network"]
        
        if "device" in kwargs and kwargs["device"]:
            params["filter_device"] = kwargs["device"]
        
        # Add day_column for cohort data
        if use_cohort:
            params["day_column"] = "day"
        
        # 发送请求
        logger.info(f"查询参数: {params}")
        result = self._make_request(params)
        
        # 模糊查询筛选（客户端筛选）
        filtered_data = self._apply_filters(result.get("data", []), kwargs)
        
        # 数值条件筛选（客户端筛选）
        filtered_data = self._apply_numeric_filters(filtered_data, kwargs)
        
        return {"data": filtered_data, "columns": metrics}
    
    def _apply_filters(self, data: List[Dict], kwargs: Dict) -> List[Dict]:
        """
        应用模糊查询筛选
        
        Args:
            data: 原始数据
            kwargs: 查询参数
            
        Returns:
            筛选后的数据
        """
        if not data:
            return data
        
        filtered = data
        
        # 基础模糊查询（包含匹配，不区分大小写）
        like_filters = {
            "campaign_like": "campaign",
            "app_like": "app",
            "country_like": "country",
            "platform_like": "platform",
            "network_like": "network",
            "device_like": "device"
        }
        
        for param_key, field_key in like_filters.items():
            if param_key in kwargs and kwargs[param_key]:
                keyword = kwargs[param_key].lower()
                filtered = [
                    row for row in filtered
                    if keyword in str(row.get(field_key, "")).lower()
                ]
        
        # 高级模糊查询
        fuzzy_filters = {
            "campaign_fuzzy": "campaign",
            "product_fuzzy": "product",
            "app_fuzzy": "app",
            "country_fuzzy": "country",
            "platform_fuzzy": "platform",
            "network_fuzzy": "network",
            "device_fuzzy": "device"
        }
        
        for param_key, field_key in fuzzy_filters.items():
            if param_key in kwargs and kwargs[param_key]:
                pattern = kwargs[param_key]
                fuzzy_mode = kwargs.get("fuzzy_mode", "auto")
                case_sensitive = kwargs.get("case_sensitive", False)
                
                filtered = [
                    row for row in filtered
                    if self._match_pattern(
                        str(row.get(field_key, "")),
                        pattern,
                        fuzzy_mode,
                        case_sensitive
                    )
                ]
        
        return filtered
    
    def _match_pattern(self, text: str, pattern: str, mode: str, case_sensitive: bool) -> bool:
        """
        匹配模式
        
        Args:
            text: 待匹配文本
            pattern: 匹配模式
            mode: 匹配模式（auto/contains/regex/wildcard/exact）
            case_sensitive: 是否区分大小写
            
        Returns:
            是否匹配
        """
        if not case_sensitive:
            text = text.lower()
            pattern = pattern.lower()
        
        if mode == "exact":
            return text == pattern
        elif mode == "contains":
            return pattern in text
        elif mode == "regex":
            try:
                import re
                flags = 0 if case_sensitive else re.IGNORECASE
                return re.search(pattern, text, flags) is not None
            except re.error:
                return False
        elif mode == "wildcard":
            # 将通配符转换为正则表达式
            regex_pattern = pattern.replace("*", ".*").replace("?", ".")
            if not case_sensitive:
                regex_pattern = regex_pattern.lower()
                text = text.lower()
            try:
                import re
                return re.match(f"^{regex_pattern}$", text) is not None
            except re.error:
                return False
        else:  # auto
            # 自动检测：如果包含 * 或 ?，使用通配符；如果包含正则表达式特殊字符，使用正则；否则使用包含匹配
            if "*" in pattern or "?" in pattern:
                return self._match_pattern(text, pattern, "wildcard", case_sensitive)
            elif any(c in pattern for c in ["^", "$", "[", "]", "(", ")", "+", "{", "|", "\\"]):
                return self._match_pattern(text, pattern, "regex", case_sensitive)
            else:
                return self._match_pattern(text, pattern, "contains", case_sensitive)
    
    def _apply_numeric_filters(self, data: List[Dict], kwargs: Dict) -> List[Dict]:
        """
        应用数值条件筛选
        
        Args:
            data: 原始数据
            kwargs: 查询参数
            
        Returns:
            筛选后的数据
        """
        if not data:
            return data
        
        filtered = data
        
        # 数值条件筛选
        numeric_filters = {
            "min_cost": "cost",
            "max_cost": "cost",
            "min_impressions": "impressions",
            "max_impressions": "impressions",
            "min_clicks": "clicks",
            "max_clicks": "clicks",
            "min_conversions": "conversions",
            "max_conversions": "conversions"
        }
        
        for param_key, field_key in numeric_filters.items():
            if param_key in kwargs and kwargs[param_key] is not None:
                threshold = float(kwargs[param_key])
                
                if param_key.startswith("min_"):
                    filtered = [
                        row for row in filtered
                        if float(row.get(field_key, 0)) >= threshold
                    ]
                else:  # max_
                    filtered = [
                        row for row in filtered
                        if float(row.get(field_key, 0)) <= threshold
                    ]
        
        # ROAS 条件筛选
        roas_fields = ["roas_0d", "roas_1d", "roas_3d", "roas_7d", "roas_28d"]
        for roas_field in roas_fields:
            min_key = f"min_{roas_field}"
            max_key = f"max_{roas_field}"
            
            if min_key in kwargs and kwargs[min_key] is not None:
                threshold = float(kwargs[min_key])
                filtered = [
                    row for row in filtered
                    if float(row.get(roas_field, 0)) >= threshold
                ]
            
            if max_key in kwargs and kwargs[max_key] is not None:
                threshold = float(kwargs[max_key])
                filtered = [
                    row for row in filtered
                    if float(row.get(roas_field, 0)) <= threshold
                ]
        
        # IAP ROAS 条件筛选
        iap_roas_fields = ["iap_roas_0d", "iap_roas_1d", "iap_roas_3d", "iap_roas_7d", "iap_roas_28d"]
        for iap_roas_field in iap_roas_fields:
            min_key = f"min_{iap_roas_field}"
            max_key = f"max_{iap_roas_field}"
            
            if min_key in kwargs and kwargs[min_key] is not None:
                threshold = float(kwargs[min_key])
                filtered = [
                    row for row in filtered
                    if float(row.get(iap_roas_field, 0)) >= threshold
                ]
            
            if max_key in kwargs and kwargs[max_key] is not None:
                threshold = float(kwargs[max_key])
                filtered = [
                    row for row in filtered
                    if float(row.get(iap_roas_field, 0)) <= threshold
                ]
        
        return filtered

# 测试代码
if __name__ == "__main__":
    client = AxonReportingClient()
    
    # 测试查询
    try:
        result = client.query()
        print(f"查询成功，共 {len(result.get('data', []))} 条记录")
    except Exception as e:
        print(f"查询失败: {e}")
