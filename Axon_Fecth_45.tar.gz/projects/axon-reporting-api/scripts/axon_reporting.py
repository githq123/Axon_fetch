#!/usr/bin/env python3
"""
AppLovin Axon Reporting API Client
提供完整的广告投放数据查询和分析功能

ROAS Terminology:
- D0/D1/D3/D7/D28 ROAS = Total ROAS (IAA + IAP) by default
- IAP ROAS = IAP revenue only
- IAA ROAS = Ad revenue only

Data Source:
- Default: Cohort data (grouped by user acquisition date)
- Realtime: Use use_cohort=False for realtime estimates
"""

import os
import json
import csv
from coze_workload_identity import requests
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Union, Any
from dataclasses import dataclass
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# API配置
API_BASE_URL = "https://r.applovin.com/report"
API_KEY = os.environ.get("AXON_API_KEY", "")

# 常用指标列
# ROAS columns: D0/D1/D3/D7/D28 formats
# Default: roas_Xd = Total ROAS (IAA + IAP)
# IAP only: iap_roas_Xd
COMMON_METRICS = {
    "basic": ["day", "campaign", "impressions", "clicks", "conversions", "cost"],
    # D0 metrics
    "roas_d0": ["roas_0d", "iap_roas_0d", "iap_rev_0d", "total_rev_0d"],
    # D1 metrics
    "roas_d1": ["roas_1d", "iap_roas_1d", "iap_rev_1d", "total_rev_1d"],
    # D3 metrics
    "roas_d3": ["roas_3d", "iap_roas_3d", "iap_rev_3d", "total_rev_3d"],
    # D7 metrics (common)
    "roas_d7": ["roas_7d", "iap_roas_7d", "iap_rev_7d", "total_rev_7d"],
    # D28 metrics
    "roas_d28": ["roas_28d", "iap_roas_28d", "iap_rev_28d", "total_rev_28d"],
    # Revenue
    "revenue": ["iap_rev_0d", "iap_rev_7d", "total_rev_0d", "total_rev_7d"],
    # Retention
    "retention": ["ret_7d", "ret_28d"],
    # Advanced
    "advanced": ["installs", "spend", "cpi", "cpc", "ctr"]
}

# 导出CSV所需的指标集合
EXPORT_CSV_METRICS = [
    "day", "campaign", "country", "cost", "conversions",
    "roas_1d", "roas_3d", "roas_7d"
]

@dataclass
class CampaignInfo:
    """Campaign信息数据类"""
    name: str
    app: str
    platform: str
    network: str
    target: str
    optimization: str
    date: str
    full_name: str
    
    @classmethod
    def from_name(cls, campaign_name: str) -> 'CampaignInfo':
        """从Campaign名称解析信息"""
        parts = campaign_name.split('_')
        if len(parts) >= 6:
            return cls(
                name=campaign_name,
                app=parts[0],
                platform=parts[1],
                network=parts[2],
                target=parts[3],
                optimization=parts[4],
                date=parts[5],
                full_name=campaign_name
            )
        return cls(
            name=campaign_name,
            app="unknown",
            platform="unknown",
            network="unknown",
            target="unknown",
            optimization="unknown",
            date="unknown",
            full_name=campaign_name
        )

class AxonAPIError(Exception):
    """Axon API错误异常"""
    pass

class AxonReportingClient:
    """AppLovin Axon Reporting API客户端"""
    
    def __init__(self, api_key: str = None, base_url: str = None):
        """
        初始化客户端
        
        Args:
            api_key: Axon Reporting API密钥
            base_url: API基础URL
        """
        self.api_key = api_key or API_KEY
        self.base_url = base_url or API_BASE_URL
        
        if not self.api_key:
            logger.warning("API密钥未设置，请设置AXON_API_KEY环境变量或在调用时传入")
        
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "OpenClaw-Axon-Reporting-Client/1.0.0"
        })
    
    def _make_request(self, params: Dict) -> Dict:
        """
        发送API请求
        
        Args:
            params: 请求参数
            
        Returns:
            API响应数据
            
        Raises:
            AxonAPIError: API请求失败
        """
        try:
            response = self.session.get(self.base_url, params=params, timeout=30)
            response.raise_for_status()
            
            # 解析响应
            if params.get("format", "json") == "json":
                return response.json()
            else:
                return {"data": response.text, "format": "csv"}
                
        except requests.exceptions.RequestException as e:
            logger.error(f"API请求失败: {e}")
            raise AxonAPIError(f"API请求失败: {e}")
        except json.JSONDecodeError as e:
            logger.error(f"JSON解析失败: {e}")
            raise AxonAPIError(f"JSON解析失败: {e}")
    
    def query_campaign(self,
                      product_name: str = None,
                      campaign_name: str = None,
                      start_date: str = None,
                      end_date: str = "now",
                      metrics: List[str] = None,
                      report_type: str = "advertiser",
                      format: str = "json",
                      use_cohort: bool = True) -> Dict:
        """
        查询数据（支持按产品名称或Campaign名称查询）

        Args:
            product_name: 产品名称（优先级高于campaign_name）
            campaign_name: Campaign名称（如果product_name为空则使用此参数）
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD 或 "now")
            metrics: 查询指标列表，None则使用D0 Total ROAS指标
            report_type: 报告类型 (advertiser/publisher)
            format: 返回格式 (json/csv)
            use_cohort: 使用cohort数据 (默认True)。False为realtime。

        Returns:
            查询结果
        """
        if not self.api_key:
            raise AxonAPIError("API密钥未设置")

        # 确定查询参数
        target = product_name if product_name else campaign_name
        if not target:
            raise AxonAPIError("必须提供product_name或campaign_name参数")

        # 设置默认指标 - D0 Total ROAS
        if metrics is None:
            metrics = COMMON_METRICS["basic"] + ["roas_0d"]

        params = {
            "api_key": self.api_key,
            "start": start_date,
            "end": end_date,
            "columns": ",".join(metrics),
            "format": format,
            "report_type": report_type,
        }

        # 根据查询类型设置筛选参数
        if product_name:
            params["filter_product"] = product_name
            logger.info(f"按产品名称查询: {product_name}, 时间范围: {start_date} 到 {end_date}")
        else:
            params["filter_campaign"] = campaign_name
            logger.info(f"按Campaign名称查询: {campaign_name}, 时间范围: {start_date} 到 {end_date}")

        # Add day_column for cohort data (default behavior)
        if use_cohort:
            params["day_column"] = "day"

        data_type = "cohort" if use_cohort else "realtime"
        logger.info(f"数据源类型: {data_type}")
        return self._make_request(params)
    
    def batch_query_campaigns(self,
                            campaigns: List[str],
                            start_date: str,
                            end_date: str = "now",
                            metrics: List[str] = None,
                            report_type: str = "advertiser") -> Dict[str, Dict]:
        """
        批量查询多个Campaign
        
        Args:
            campaigns: Campaign名称列表
            start_date: 开始日期
            end_date: 结束日期
            metrics: 查询指标列表
            report_type: 报告类型
            
        Returns:
            各Campaign的查询结果字典
        """
        results = {}
        
        for campaign in campaigns:
            try:
                result = self.query_campaign(
                    campaign_name=campaign,
                    start_date=start_date,
                    end_date=end_date,
                    metrics=metrics,
                    report_type=report_type
                )
                results[campaign] = result
                logger.info(f"成功查询Campaign: {campaign}")
                
            except AxonAPIError as e:
                logger.error(f"查询Campaign失败 {campaign}: {e}")
                results[campaign] = {"error": str(e)}
        
        return results
    
    def analyze_roas(self,
                    product_name: str = None,
                    campaign_name: str = None,
                    time_window: str = "7d",
                    start_date: str = None,
                    end_date: str = "now",
                    use_cohort: bool = True) -> Dict:
        """
        分析ROAS表现（支持按产品名称或Campaign名称查询）

        Args:
            product_name: 产品名称（优先级高于campaign_name）
            campaign_name: Campaign名称（如果product_name为空则使用此参数）
            time_window: 时间窗口 (0d, 1d, 3d, 7d, 28d等)
            start_date: 开始日期，None则自动计算
            end_date: 结束日期
            use_cohort: 使用cohort数据 (默认True)

        Returns:
            ROAS分析报告
        """
        # 确定查询目标
        target = product_name if product_name else campaign_name
        if not target:
            raise AxonAPIError("必须提供product_name或campaign_name参数")

        # 自动计算开始日期
        if start_date is None:
            if end_date == "now":
                end_date_obj = datetime.now()
            else:
                end_date_obj = datetime.strptime(end_date, "%Y-%m-%d")

            # 根据时间窗口计算开始日期
            if time_window == "0d":
                days = 0
            elif time_window == "1d":
                days = 1
            elif time_window == "3d":
                days = 3
            elif time_window == "7d":
                days = 7
            elif time_window == "28d":
                days = 28
            elif time_window == "30d":
                days = 30
            elif time_window == "90d":
                days = 90
            elif time_window == "1y":
                days = 365
            else:
                days = 7  # 默认7天

            start_date_obj = end_date_obj - timedelta(days=days)
            start_date = start_date_obj.strftime("%Y-%m-%d")

        # 查询数据 - Total ROAS (IAA + IAP)
        metrics = [
            "day", "campaign", "impressions", "clicks", "conversions", "cost",
            f"roas_{time_window}", f"iap_roas_{time_window}", f"iap_rev_{time_window}",
            f"total_rev_{time_window}"
        ]

        data = self.query_campaign(
            product_name=product_name,
            campaign_name=campaign_name,
            start_date=start_date,
            end_date=end_date,
            metrics=metrics,
            use_cohort=use_cohort
        )

        query_type = "产品" if product_name else "Campaign"

        # 分析ROAS
        if "data" in data and data["data"]:
            df = pd.DataFrame(data["data"])

            # 计算平均ROAS
            avg_roas = df[f"roas_{time_window}"].mean() if f"roas_{time_window}" in df.columns else None
            avg_iap_roas = df[f"iap_roas_{time_window}"].mean() if f"iap_roas_{time_window}" in df.columns else None

            # 计算总成本
            total_cost = df["cost"].sum() if "cost" in df.columns else None

            # 计算总收入
            total_iap_rev = df[f"iap_rev_{time_window}"].sum() if f"iap_rev_{time_window}" in df.columns else None

            analysis = {
                "target": target,
                "target_type": query_type,
                "time_window": time_window,
                "date_range": f"{start_date} 到 {end_date}",
                "total_days": len(df),
                "average_roas": float(avg_roas) if avg_roas is not None else None,
                "average_iap_roas": float(avg_iap_roas) if avg_iap_roas is not None else None,
                "total_cost": float(total_cost) if total_cost is not None else None,
                "total_iap_revenue": float(total_iap_rev) if total_iap_rev is not None else None,
                "data_points": len(df),
                "summary": self._generate_roas_summary(avg_roas, avg_iap_roas)
            }

            return analysis
        else:
            return {"error": "未找到数据", "target": target, "target_type": query_type}
    
    def _generate_roas_summary(self, roas: float, iap_roas: float) -> str:
        """生成ROAS总结"""
        if roas is None and iap_roas is None:
            return "无ROAS数据"
        
        summary_parts = []
        
        if roas is not None:
            if roas > 2.0:
                summary_parts.append(f"总ROAS优秀 ({roas:.2f})")
            elif roas > 1.0:
                summary_parts.append(f"总ROAS良好 ({roas:.2f})")
            else:
                summary_parts.append(f"总ROAS需优化 ({roas:.2f})")
        
        if iap_roas is not None:
            if iap_roas > 2.0:
                summary_parts.append(f"内购ROAS优秀 ({iap_roas:.2f})")
            elif iap_roas > 1.0:
                summary_parts.append(f"内购ROAS良好 ({iap_roas:.2f})")
            else:
                summary_parts.append(f"内购ROAS需优化 ({iap_roas:.2f})")
        
        return " | ".join(summary_parts)
    
    def compare_campaigns(self,
                         campaigns: List[str],
                         start_date: str,
                         end_date: str = "now",
                         primary_metric: str = "roas_7d") -> Dict:
        """
        比较多个Campaign的表现
        
        Args:
            campaigns: Campaign名称列表
            start_date: 开始日期
            end_date: 结束日期
            primary_metric: 主要比较指标
            
        Returns:
            比较分析报告
        """
        # 查询所有Campaign数据
        all_data = self.batch_query_campaigns(
            campaigns=campaigns,
            start_date=start_date,
            end_date=end_date,
            metrics=["day", "campaign", "impressions", "clicks", "cost", primary_metric]
        )
        
        comparison = {
            "date_range": f"{start_date} 到 {end_date}",
            "primary_metric": primary_metric,
            "campaigns": {},
            "ranking": []
        }
        
        # 分析每个Campaign
        for campaign, data in all_data.items():
            if "error" in data:
                comparison["campaigns"][campaign] = {"error": data["error"]}
                continue
            
            if "data" in data and data["data"]:
                df = pd.DataFrame(data["data"])
                
                # 计算指标
                total_impressions = df["impressions"].sum() if "impressions" in df.columns else 0
                total_clicks = df["clicks"].sum() if "clicks" in df.columns else 0
                total_cost = df["cost"].sum() if "cost" in df.columns else 0
                avg_primary = df[primary_metric].mean() if primary_metric in df.columns else None
                
                # 计算CTR
                ctr = (total_clicks / total_impressions * 100) if total_impressions > 0 else 0
                
                # 计算CPC
                cpc = (total_cost / total_clicks) if total_clicks > 0 else 0
                
                campaign_info = CampaignInfo.from_name(campaign)
                
                comparison["campaigns"][campaign] = {
                    "app": campaign_info.app,
                    "platform": campaign_info.platform,
                    "target": campaign_info.target,
                    "total_impressions": int(total_impressions),
                    "total_clicks": int(total_clicks),
                    "total_cost": float(total_cost),
                    "ctr": float(ctr),
                    "cpc": float(cpc),
                    f"average_{primary_metric}": float(avg_primary) if avg_primary is not None else None,
                    "data_points": len(df)
                }
                
                # 添加到排名
                if avg_primary is not None:
                    comparison["ranking"].append({
                        "campaign": campaign,
                        "value": float(avg_primary),
                        "metric": primary_metric
                    })
        
        # 排序排名
        comparison["ranking"].sort(key=lambda x: x["value"], reverse=True)
        
        return comparison
    
    def export_data(self, data: Dict, format: str = "json", filename: str = None) -> str:
        """
        导出数据到文件
        
        Args:
            data: 要导出的数据
            format: 导出格式 (json, csv, excel)
            filename: 文件名，None则自动生成
            
        Returns:
            文件路径
        """
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"axon_export_{timestamp}.{format}"
        
        filepath = os.path.join(os.getcwd(), filename)
        
        try:
            if format == "json":
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
            
            elif format == "csv":
                if "data" in data and isinstance(data["data"], list):
                    df = pd.DataFrame(data["data"])
                    df.to_csv(filepath, index=False, encoding='utf-8-sig')
                else:
                    # 如果不是标准数据结构，保存为JSON
                    with open(filepath, 'w', encoding='utf-8') as f:
                        json.dump(data, f, ensure_ascii=False, indent=2)
            
            elif format == "excel":
                if "data" in data and isinstance(data["data"], list):
                    df = pd.DataFrame(data["data"])
                    df.to_excel(filepath, index=False)
                else:
                    # 保存为JSON
                    json_filepath = filepath.replace('.xlsx', '.json')
                    with open(json_filepath, 'w', encoding='utf-8') as f:
                        json.dump(data, f, ensure_ascii=False, indent=2)
                    filepath = json_filepath
            
            logger.info(f"数据已导出到: {filepath}")
            return filepath
            
        except Exception as e:
            logger.error(f"导出数据失败: {e}")
            raise AxonAPIError(f"导出数据失败: {e}")
    
    def get_campaign_suggestions(self, app: str = None, platform: str = None) -> List[str]:
        """
        获取Campaign建议列表（基于命名规则）

        Args:
            app: 应用筛选
            platform: 平台筛选

        Returns:
            Campaign名称列表
        """
        # 基于用户提供的实际产品配置
        sample_campaigns = [
            "ios.pretty.boutique.merge.game",
            "ios.his.grip.match.game",
            "com.serenasecret.mergegame",
            "com.serena.mergemakeover.ios",
            "com.project.labuub.merge.game",
            "com.mansion.affairs.merge.game",
            "com.his.grip.match.game",
            "com.gbd.amy.secret.game",
            "com.amy.secret.game"
        ]

        suggestions = []

        for campaign in sample_campaigns:
            info = CampaignInfo.from_name(campaign)

            # 应用筛选
            if app and info.app.lower() != app.lower():
                continue

            # 平台筛选
            if platform and info.platform.lower() != platform.lower():
                continue

            suggestions.append(campaign)

        return suggestions

    def get_product_list(self) -> List[str]:
        """
        获取可用的产品名称列表

        Returns:
            产品名称列表
        """
        # 基于用户提供的实际产品配置
        return [
            "ios.pretty.boutique.merge.game",
            "ios.his.grip.match.game",
            "com.serenasecret.mergegame",
            "com.serena.mergemakeover.ios",
            "com.project.labuub.merge.game",
            "com.mansion.affairs.merge.game",
            "com.his.grip.match.game",
            "com.gbd.amy.secret.game",
            "com.amy.secret.game"
        ]

    def generate_product_report(self,
                               product_name: str,
                               days: int = 30,
                               use_cohort: bool = True) -> Dict:
        """
        生成产品的深度数据分析报告（类似提供的示例脚本）

        Args:
            product_name: 产品名称
            days: 分析天数（默认30天）
            use_cohort: 使用cohort数据（默认True）

        Returns:
            详细分析报告
        """
        if not self.api_key:
            raise AxonAPIError("API密钥未设置")

        # 计算日期范围
        end_date = "now"
        start_date = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")

        # 使用扩展指标集合
        metrics = EXTENDED_METRICS.copy()

        # 查询数据
        params = {
            "api_key": self.api_key,
            "start": start_date,
            "end": end_date,
            "columns": ",".join(metrics),
            "format": "json",
            "report_type": "advertiser",
            "filter_product": product_name
        }

        if use_cohort:
            params["day_column"] = "day"

        try:
            response = self.session.get(self.base_url, params=params, timeout=30)
            response.raise_for_status()
            data = response.json()

            # 处理返回的数据
            if "results" in data and data["results"]:
                df = pd.DataFrame(data["results"])

                # 数值转换
                numeric_cols = df.columns.difference(['day', 'campaign'])
                for col in numeric_cols:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors='coerce')

                # 基础统计
                total_entries = len(df)
                date_range = (df["day"].min(), df["day"].max()) if "day" in df.columns else (None, None)
                unique_campaigns = df["campaign"].nunique() if "campaign" in df.columns else 0

                # 过滤有效数据（有转化的）
                df_active = df[df['conversions'] > 0].copy()
                active_entries = len(df_active)

                # 基础指标汇总
                imp_sum = df_active['impressions'].sum() if 'impressions' in df_active.columns else 0
                click_sum = df_active['clicks'].sum() if 'clicks' in df_active.columns else 0
                conv_sum = df_active['conversions'].sum() if 'conversions' in df_active.columns else 0
                cost_sum = df_active['cost'].sum() if 'cost' in df_active.columns else 0

                ctr = (click_sum / imp_sum * 100) if imp_sum > 0 else 0
                cpc = (cost_sum / click_sum) if click_sum > 0 else 0
                cpi = (cost_sum / conv_sum) if conv_sum > 0 else 0

                # ROAS分析
                roas_analysis = {}
                for days_label in ['0d', '1d', '3d', '7d', '28d']:
                    roas_col = f'roas_{days_label}'
                    iap_roas_col = f'iap_roas_{days_label}'
                    iap_rev_col = f'iap_rev_{days_label}'
                    total_rev_col = f'total_rev_{days_label}'

                    if roas_col in df_active.columns:
                        roas_mean = df_active[roas_col].mean()
                        iap_roas_mean = df_active[iap_roas_col].mean() if iap_roas_col in df_active.columns else None
                        iap_rev_sum = df_active[iap_rev_col].sum() if iap_rev_col in df_active.columns else None
                        total_rev_sum = df_active[total_rev_col].sum() if total_rev_col in df_active.columns else None

                        if pd.notna(roas_mean) and roas_mean > 0:
                            iaa_roas = roas_mean - iap_roas_mean if pd.notna(iap_roas_mean) else None

                            roas_analysis[days_label] = {
                                "total_roas": float(roas_mean) if pd.notna(roas_mean) else None,
                                "iap_roas": float(iap_roas_mean) if pd.notna(iap_roas_mean) else None,
                                "iaa_roas": float(iaa_roas) if pd.notna(iaa_roas) else None,
                                "iap_revenue": float(iap_rev_sum) if pd.notna(iap_rev_sum) else None,
                                "total_revenue": float(total_rev_sum) if pd.notna(total_rev_sum) else None
                            }

                # 留存分析
                retention_analysis = {}
                for days_label in ['7d', '28d']:
                    ret_col = f'ret_{days_label}'
                    if ret_col in df_active.columns:
                        ret_mean = df_active[ret_col].mean()
                        if pd.notna(ret_mean) and ret_mean > 0:
                            retention_analysis[days_label] = float(ret_mean)

                # Campaign分布
                campaign_distribution = {}
                if 'campaign' in df_active.columns:
                    campaign_stats = df_active.groupby('campaign').agg({
                        'conversions': 'sum',
                        'cost': 'sum',
                        'roas_7d': 'mean'
                    }).sort_values('conversions', ascending=False)

                    for camp, row in campaign_stats.iterrows():
                        campaign_distribution[camp] = {
                            "conversions": float(row['conversions']),
                            "cost": float(row['cost']),
                            "d7_roas": float(row['roas_7d']) if pd.notna(row['roas_7d']) else None
                        }

                # 时间趋势（最近7天）
                recent_trend = []
                if len(df) > 0:
                    df_sorted = df.sort_values('day', ascending=False)
                    recent_7days = df_sorted.head(7)

                    for _, row in recent_7days.iterrows():
                        trend_entry = {
                            "day": row['day'],
                            "impressions": int(row['impressions']) if pd.notna(row['impressions']) else 0,
                            "clicks": int(row['clicks']) if pd.notna(row['clicks']) else 0,
                            "conversions": int(row['conversions']) if pd.notna(row['conversions']) else 0,
                            "cost": float(row['cost']) if pd.notna(row['cost']) else 0,
                            "d7_roas": float(row['roas_7d']) if pd.notna(row['roas_7d']) else None
                        }
                        recent_trend.append(trend_entry)

                # 组装报告
                report = {
                    "product": product_name,
                    "analysis_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "date_range": f"{start_date} 到 {end_date}",
                    "data_overview": {
                        "total_entries": total_entries,
                        "date_start": date_range[0],
                        "date_end": date_range[1],
                        "unique_campaigns": unique_campaigns,
                        "active_entries": active_entries
                    },
                    "performance_metrics": {
                        "total_impressions": float(imp_sum),
                        "total_clicks": float(click_sum),
                        "total_conversions": float(conv_sum),
                        "total_cost": float(cost_sum),
                        "ctr": float(ctr),
                        "cpc": float(cpc),
                        "cpi": float(cpi)
                    },
                    "roas_analysis": roas_analysis,
                    "retention_analysis": retention_analysis,
                    "campaign_distribution": campaign_distribution,
                    "recent_trend": recent_trend
                }

                return report

            else:
                return {
                    "product": product_name,
                    "error": "未找到数据",
                    "message": "API返回为空或格式不正确"
                }

        except requests.exceptions.RequestException as e:
            raise AxonAPIError(f"API请求失败: {e}")
        except Exception as e:
            raise AxonAPIError(f"数据处理异常: {e}")
    
    def validate_campaign_name(self, campaign_name: str) -> Dict:
        """
        验证Campaign名称格式
        
        Args:
            campaign_name: Campaign名称
            
        Returns:
            验证结果
        """
        info = CampaignInfo.from_name(campaign_name)
        
        validation = {
            "campaign": campaign_name,
            "is_valid_format": info.date != "unknown",
            "parsed_info": {
                "app": info.app,
                "platform": info.platform,
                "network": info.network,
                "target": info.target,
                "optimization": info.optimization,
                "date": info.date
            },
            "suggestions": []
        }
        
        # 如果格式无效，提供建议
        if not validation["is_valid_format"]:
            validation["suggestions"] = [
                "Campaign名称应遵循格式: [App]_[Platform]_[Network]_[Target]_[Optimization]_[Date]",
                "示例: InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203",
                "请检查名称格式是否正确"
            ]
        
        return validation

    def export_all_products_to_csv(self, days_back: int = 45, output_file: str = None) -> str:
        """
        拉取T-45到T-1（昨天）所有产品的数据，并导出到CSV文件

        CSV包含字段：dt, campaign, 产品, 国家, 消耗, CPA, ROI1, ROI3, ROI7

        Args:
            days_back: 拉取多少天的历史数据（默认45天）
            output_file: 输出文件名，None则自动生成

        Returns:
            CSV文件路径
        """
        if not self.api_key:
            raise AxonAPIError("API密钥未设置")

        # 计算日期范围：T-45 到 T-1（昨天）
        today = datetime.now()
        yesterday = today - timedelta(days=1)
        start_date = (yesterday - timedelta(days=days_back)).strftime("%Y-%m-%d")
        end_date = yesterday.strftime("%Y-%m-%d")

        # 获取所有产品列表
        products = self.get_product_list()

        logger.info(f"开始导出数据：时间范围 {start_date} 到 {end_date}，产品数量 {len(products)}")

        all_data = []

        # 遍历所有产品
        for product in products:
            try:
                # 查询数据
                params = {
                    "api_key": self.api_key,
                    "start": start_date,
                    "end": end_date,
                    "columns": ",".join(EXPORT_CSV_METRICS),
                    "format": "json",
                    "report_type": "advertiser",
                    "filter_product": product,
                    "day_column": "day"  # 使用Cohort数据
                }

                response = self.session.get(self.base_url, params=params, timeout=30)
                response.raise_for_status()
                data = response.json()

                # 处理返回的数据
                if "results" in data and data["results"]:
                    df = pd.DataFrame(data["results"])

                    # 数值转换
                    numeric_cols = ['cost', 'conversions', 'roas_1d', 'roas_3d', 'roas_7d']
                    for col in numeric_cols:
                        if col in df.columns:
                            df[col] = pd.to_numeric(df[col], errors='coerce')

                    # 转换数据格式
                    for _, row in df.iterrows():
                        # 计算CPA
                        cost_val = row.get('cost', 0)
                        conv_val = row.get('conversions', 0)
                        cpa = cost_val / conv_val if conv_val > 0 else 0

                        # ROI格式转换（百分比转小数）：50% -> 0.5
                        roi1 = row.get('roas_1d', 0) / 100 if pd.notna(row.get('roas_1d')) else 0
                        roi3 = row.get('roas_3d', 0) / 100 if pd.notna(row.get('roas_3d')) else 0
                        roi7 = row.get('roas_7d', 0) / 100 if pd.notna(row.get('roas_7d')) else 0

                        # 解析国家和产品信息
                        campaign_name = row.get('campaign', '')
                        country = self._extract_country_from_campaign(campaign_name)

                        record = {
                            "dt": row.get('day', ''),
                            "campaign": campaign_name,
                            "产品": product,
                            "国家": country,
                            "消耗": float(cost_val) if pd.notna(cost_val) else 0,
                            "CPA": float(cpa),
                            "ROI1": float(roi1),
                            "ROI3": float(roi3),
                            "ROI7": float(roi7)
                        }
                        all_data.append(record)

                    logger.info(f"产品 {product} 导出 {len(df)} 条数据")

            except Exception as e:
                logger.error(f"导出产品 {product} 失败: {e}")
                continue

        # 生成输出文件名
        if output_file is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"axon_products_{start_date}_to_{end_date}_{timestamp}.csv"

        # 保存CSV文件
        df_export = pd.DataFrame(all_data)
        df_export.to_csv(output_file, index=False, encoding='utf-8-sig')

        logger.info(f"数据已导出到: {output_file}，共 {len(all_data)} 条记录")
        return output_file

    def _extract_country_from_campaign(self, campaign_name: str) -> str:
        """
        从Campaign名称中提取国家信息

        Args:
            campaign_name: Campaign名称

        Returns:
            国家代码
        """
        # 尝试从Campaign名称中提取国家代码
        # 常见格式：XX_COUNTRY_...
        if not campaign_name:
            return "UNKNOWN"

        # 查找常见国家代码
        country_codes = ['US', 'GB', 'DE', 'FR', 'IT', 'ES', 'CA', 'AU', 'JP', 'KR', 'BR', 'MX', 'IN', 'ID', 'TH', 'VN', 'PH', 'SG', 'MY', 'TW', 'HK', 'CN']

        parts = campaign_name.split('_')
        for part in parts:
            if part.upper() in country_codes:
                return part.upper()

        # 如果找不到，返回默认值
        return "UNKNOWN"

# 工具函数
def get_campaign_roas_data(product_name: str = None, campaign_name: str = None,
                          start_date: str = None, end_date: str = "now", **kwargs) -> Dict:
    """
    获取ROAS数据的便捷函数（支持按产品名称或Campaign名称查询）

    Args:
        product_name: 产品名称（优先级高于campaign_name）
        campaign_name: Campaign名称（如果product_name为空则使用此参数）
        start_date: 开始日期
        end_date: 结束日期
        **kwargs: 其他参数

    Returns:
        ROAS数据
    """
    client = AxonReportingClient()
    return client.analyze_roas(product_name=product_name, campaign_name=campaign_name,
                              start_date=start_date, end_date=end_date, **kwargs)

def batch_query_campaigns(campaigns: List[str], start_date: str, end_date: str = "now", **kwargs) -> Dict:
    """
    批量查询Campaign的便捷函数

    Args:
        campaigns: Campaign列表
        start_date: 开始日期
        end_date: 结束日期
        **kwargs: 其他参数

    Returns:
        批量查询结果
    """
    client = AxonReportingClient()
    return client.batch_query_campaigns(campaigns, start_date, end_date, **kwargs)

def get_product_list() -> List[str]:
    """
    获取可用的产品名称列表的便捷函数

    Returns:
        产品名称列表
    """
    client = AxonReportingClient()
    return client.get_product_list()

def generate_campaign_report(product_name: str = None, campaign_name: str = None,
                           start_date: str = None, end_date: str = "now",
                           report_format: str = "markdown", **kwargs) -> str:
    """
    生成报告的便捷函数（支持按产品名称或Campaign名称查询）

    Args:
        product_name: 产品名称（优先级高于campaign_name）
        campaign_name: Campaign名称（如果product_name为空则使用此参数）
        start_date: 开始日期
        end_date: 结束日期
        report_format: 报告格式 (markdown, html, json)
        **kwargs: 其他参数

    Returns:
        报告内容
    """
    client = AxonReportingClient()

    # 确定查询目标
    target = product_name if product_name else campaign_name
    if not target:
        raise AxonAPIError("必须提供product_name或campaign_name参数")

    # 查询数据
    data = client.query_campaign(product_name=product_name, campaign_name=campaign_name,
                                start_date=start_date, end_date=end_date)
    roas_analysis = client.analyze_roas(product_name=product_name, campaign_name=campaign_name,
                                       start_date=start_date, end_date=end_date)

    # 生成报告
    if report_format == "markdown":
        return _generate_markdown_report(target, data, roas_analysis, start_date, end_date)
    elif report_format == "html":
        return _generate_html_report(target, data, roas_analysis, start_date, end_date)
    else:
        return json.dumps({
            "target": target,
            "date_range": f"{start_date} 到 {end_date}",
            "raw_data": data,
            "roas_analysis": roas_analysis
        }, ensure_ascii=False, indent=2)

def _generate_markdown_report(target: str, data: Dict, roas_analysis: Dict,
                            start_date: str, end_date: str) -> str:
    """生成Markdown格式报告"""
    target_type = "产品" if roas_analysis.get("target_type") == "产品" else "Campaign"

    report = f"""# {target_type}投放分析报告

## 基本信息
- **{target_type}**: {target}
- **时间范围**: {start_date} 到 {end_date}
- **生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## ROAS分析
"""

    if "error" not in roas_analysis:
        report += f"""
- **时间窗口**: {roas_analysis.get('time_window', 'N/A')}
- **平均总ROAS**: {roas_analysis.get('average_roas', 'N/A'):.2f}
- **平均内购ROAS**: {roas_analysis.get('average_iap_roas', 'N/A'):.2f}
- **总成本**: ${roas_analysis.get('total_cost', 'N/A'):.2f}
- **总内购收入**: ${roas_analysis.get('total_iap_revenue', 'N/A'):.2f}
- **总结**: {roas_analysis.get('summary', 'N/A')}
"""
    else:
        report += f"\n**错误**: {roas_analysis.get('error', '未知错误')}\n"

    # 数据概览
    if "data" in data and data["data"]:
        df = pd.DataFrame(data["data"])
        report += f"""
## 数据概览
- **数据点数**: {len(df)} 天
- **数据列**: {', '.join(df.columns.tolist())}

## 最近5天数据
{df.head().to_markdown(index=False)}

## 关键指标统计
"""
        # 计算关键指标
        if "impressions" in df.columns:
            report += f"- **总展示**: {df['impressions'].sum():,.0f}\n"
        if "clicks" in df.columns:
            report += f"- **总点击**: {df['clicks'].sum():,.0f}\n"
        if "cost" in df.columns:
            report += f"- **总成本**: ${df['cost'].sum():,.2f}\n"
        if "conversions" in df.columns:
            report += f"- **总转化**: {df['conversions'].sum():,.0f}\n"
    
    report += "\n---\n*报告由OpenClaw Axon Reporting Skill生成*"
    return report

def _generate_html_report(target: str, data: Dict, roas_analysis: Dict,
                         start_date: str, end_date: str) -> str:
    """生成HTML格式报告"""
    target_type = "产品" if roas_analysis.get("target_type") == "产品" else "Campaign"

    markdown_report = _generate_markdown_report(target, data, roas_analysis, start_date, end_date)

    # 简单的Markdown转HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{target_type}投放分析报告 - {target}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }}
        h1 {{ color: #333; border-bottom: 2px solid #eee; }}
        h2 {{ color: #555; margin-top: 30px; }}
        .info {{ background: #f5f5f5; padding: 15px; border-radius: 5px; }}
        .metric {{ margin: 10px 0; padding: 10px; background: #e8f4f8; border-left: 4px solid #2196F3; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #f2f2f2; }}
        .footer {{ margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; color: #777; font-size: 0.9em; }}
    </style>
</head>
<body>
    <h1>{target_type}投放分析报告</h1>

    <div class="info">
        <strong>{target_type}</strong>: {target}<br>
        <strong>时间范围</strong>: {start_date} 到 {end_date}<br>
        <strong>生成时间</strong>: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
    </div>
"""

    # 添加ROAS分析
    if "error" not in roas_analysis:
        html += f"""
    <h2>ROAS分析</h2>
    <div class="metric">
        <strong>时间窗口</strong>: {roas_analysis.get('time_window', 'N/A')}<br>
        <strong>平均总ROAS</strong>: {roas_analysis.get('average_roas', 'N/A'):.2f}<br>
        <strong>平均内购ROAS</strong>: {roas_analysis.get('average_iap_roas', 'N/A'):.2f}<br>
        <strong>总成本</strong>: ${roas_analysis.get('total_cost', 'N/A'):.2f}<br>
        <strong>总内购收入</strong>: ${roas_analysis.get('total_iap_revenue', 'N/A'):.2f}<br>
        <strong>总结</strong>: {roas_analysis.get('summary', 'N/A')}
    </div>
"""

    # 添加数据表格
    if "data" in data and data["data"]:
        df = pd.DataFrame(data["data"])
        html += f"""
    <h2>数据概览</h2>
    <p><strong>数据点数</strong>: {len(df)} 天</p>
    <p><strong>数据列</strong>: {', '.join(df.columns.tolist())}</p>

    <h3>最近5天数据</h3>
    {df.head().to_html(index=False, classes='data-table')}
"""

    html += """
    <div class="footer">
        报告由OpenClaw Axon Reporting Skill生成
    </div>
</body>
</html>
"""

    return html

def generate_product_report(product_name: str, days: int = 30, use_cohort: bool = True) -> Dict:
    """
    生成产品的深度数据分析报告的便捷函数

    Args:
        product_name: 产品名称
        days: 分析天数（默认30天）
        use_cohort: 使用cohort数据（默认True）

    Returns:
        详细分析报告
    """
    client = AxonReportingClient()
    return client.generate_product_report(product_name, days, use_cohort)


def batch_product_report(product_names: List[str], days: int = 30, use_cohort: bool = True) -> Dict[str, Dict]:
    """
    批量生成多个产品的深度分析报告

    Args:
        product_names: 产品名称列表
        days: 分析天数（默认30天）
        use_cohort: 使用cohort数据（默认True）

    Returns:
        各产品的分析报告字典
    """
    client = AxonReportingClient()
    results = {}

    for product in product_names:
        try:
            results[product] = client.generate_product_report(product, days, use_cohort)
            logger.info(f"成功生成报告: {product}")
        except AxonAPIError as e:
            logger.error(f"生成报告失败 {product}: {e}")
            results[product] = {"error": str(e)}

    return results


# 命令行接口
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="AppLovin Axon Reporting API工具")
    subparsers = parser.add_subparsers(dest="command", help="命令")
    
    # query命令
    query_parser = subparsers.add_parser("query", help="查询Campaign数据")
    query_parser.add_argument("campaign", help="Campaign名称")
    query_parser.add_argument("start_date", help="开始日期 (YYYY-MM-DD)")
    query_parser.add_argument("--end-date", default="now", help="结束日期 (默认: now)")
    query_parser.add_argument("--metrics", default="basic,roas", help="指标类型 (默认: basic,roas)")
    query_parser.add_argument("--format", default="json", choices=["json", "csv"], help="输出格式")
    
    # analyze命令
    analyze_parser = subparsers.add_parser("analyze", help="分析ROAS")
    analyze_parser.add_argument("campaign", help="Campaign名称")
    analyze_parser.add_argument("--start-date", help="开始日期")
    analyze_parser.add_argument("--end-date", default="now", help="结束日期")
    analyze_parser.add_argument("--time-window", default="7d", help="时间窗口")
    
    # compare命令
    compare_parser = subparsers.add_parser("compare", help="比较多个Campaign")
    compare_parser.add_argument("campaigns", nargs="+", help="Campaign名称列表")
    compare_parser.add_argument("start_date", help="开始日期")
    compare_parser.add_argument("--end-date", default="now", help="结束日期")
    
    # export命令
    export_parser = subparsers.add_parser("export", help="导出数据")
    export_parser.add_argument("campaign", help="Campaign名称")
    export_parser.add_argument("start_date", help="开始日期")
    export_parser.add_argument("--end-date", default="now", help="结束日期")
    export_parser.add_argument("--export-format", default="json", choices=["json", "csv", "excel"], help="导出格式")

def export_all_products_to_csv(days_back: int = 45, output_file: str = None) -> str:
    """
    拉取T-45到T-1（昨天）所有产品的数据，并导出到CSV文件的便捷函数

    Args:
        days_back: 拉取多少天的历史数据（默认45天）
        output_file: 输出文件名，None则自动生成

    Returns:
        CSV文件路径
    """
    client = AxonReportingClient()
    return client.export_all_products_to_csv(days_back, output_file)


# 命令行接口
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="AppLovin Axon Reporting API工具")
    subparsers = parser.add_subparsers(dest="command", help="命令")

    # query命令
    query_parser = subparsers.add_parser("query", help="查询Campaign数据")
    query_parser.add_argument("campaign", help="Campaign名称")
    query_parser.add_argument("start_date", help="开始日期 (YYYY-MM-DD)")
    query_parser.add_argument("--end-date", default="now", help="结束日期 (默认: now)")
    query_parser.add_argument("--metrics", default="basic,roas", help="指标类型 (默认: basic,roas)")
    query_parser.add_argument("--format", default="json", choices=["json", "csv"], help="输出格式")

    # analyze命令
    analyze_parser = subparsers.add_parser("analyze", help="分析ROAS")
    analyze_parser.add_argument("campaign", help="Campaign名称")
    analyze_parser.add_argument("--start-date", help="开始日期")
    analyze_parser.add_argument("--end-date", default="now", help="结束日期")
    analyze_parser.add_argument("--time-window", default="7d", help="时间窗口")

    # compare命令
    compare_parser = subparsers.add_parser("compare", help="比较多个Campaign")
    compare_parser.add_argument("campaigns", nargs="+", help="Campaign名称列表")
    compare_parser.add_argument("start_date", help="开始日期")
    compare_parser.add_argument("--end-date", default="now", help="结束日期")

    # export命令
    export_parser = subparsers.add_parser("export", help="导出数据")
    export_parser.add_argument("campaign", help="Campaign名称")
    export_parser.add_argument("start_date", help="开始日期")
    export_parser.add_argument("--end-date", default="now", help="结束日期")
    export_parser.add_argument("--export-format", default="json", choices=["json", "csv", "excel"], help="导出格式")

    # export-all命令（新增）
    export_all_parser = subparsers.add_parser("export-all", help="导出所有产品数据到CSV")
    export_all_parser.add_argument("--days-back", type=int, default=45, help="拉取多少天的历史数据（默认45天）")
    export_all_parser.add_argument("--output", help="输出文件名（可选）")

    args = parser.parse_args()

    client = AxonReportingClient()

    try:
        if args.command == "query":
            # 解析指标
            metric_types = args.metrics.split(',')
            metrics = []
            for mt in metric_types:
                if mt in COMMON_METRICS:
                    metrics.extend(COMMON_METRICS[mt])

            result = client.query_campaign(
                campaign_name=args.campaign,
                start_date=args.start_date,
                end_date=args.end_date,
                metrics=metrics,
                format=args.format
            )

            if args.format == "json":
                print(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                print(result.get("data", ""))

        elif args.command == "analyze":
            result = client.analyze_roas(
                campaign_name=args.campaign,
                time_window=args.time_window,
                start_date=args.start_date,
                end_date=args.end_date
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))

        elif args.command == "compare":
            result = client.compare_campaigns(
                campaigns=args.campaigns,
                start_date=args.start_date,
                end_date=args.end_date
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))

        elif args.command == "export":
            data = client.query_campaign(
                campaign_name=args.campaign,
                start_date=args.start_date,
                end_date=args.end_date
            )

            filename = client.export_data(data, format=args.export_format)
            print(f"数据已导出到: {filename}")

        elif args.command == "export-all":
            filename = client.export_all_products_to_csv(days_back=args.days_back, output_file=args.output)
            print(f"所有产品数据已导出到: {filename}")

        else:
            parser.print_help()

    except AxonAPIError as e:
        print(f"错误: {e}")

        exit(1)