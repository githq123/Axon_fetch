#!/usr/bin/env python3
"""
临时修复脚本：批量导出所有产品数据到CSV
"""
import os
import json
import csv
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional

# API配置
API_BASE_URL = "https://r.applovin.com/report"
API_KEY = os.environ.get("AXON_API_KEY", "")

# 可用产品列表
AVAILABLE_PRODUCTS = [
    "ios.pretty.boutique.merge.game",
    "ios.his.grip.match.game",
    "com.serenasecret.mergegame",
    "com.serena.mergemakeover.ios",
    "com.project.labuub.merge.game",
    "com.mansion.affairs.merge.game",
    "com.his.grip.match.game",
    "com.gbd.amy.secret.game",
    "com.amy.secret.game"
]

# 导出CSV所需的指标集合
EXPORT_CSV_METRICS = [
    "day", "campaign", "country", "cost", "conversions",
    "roas_1d", "roas_3d", "roas_7d"
]

# 完整的国家代码列表
COUNTRY_CODES = [
    "ZW", "ZM", "ZA", "YT", "YE", "WS", "VN", "VI", "VE", "UZ", "UY", "US", "UG", "UA", "TZ", "TW", "TT",
    "TR", "TN", "TM", "TL", "TJ", "TH", "TG", "TD", "TC", "SY", "SV", "ST", "SR", "SO", "SN", "SL", "SK",
    "SI", "SG", "SE", "SD", "SC", "SB", "SA", "RW", "RU", "RS", "RO", "RE", "QA", "PY", "PT", "PS", "PR",
    "PL", "PK", "PH", "PG", "PF", "PE", "PA", "OM", "NZ", "NP", "NO", "NL", "NI", "NG", "NE", "NC", "NA",
    "MZ", "MY", "MX", "MW", "MV", "MU", "MT", "MR", "MQ", "MP", "MO", "MN", "MM", "ML", "MK", "MG", "ME",
    "MD", "MC", "MA", "LY", "LV", "LU", "LT", "LR", "LK", "LI", "LB", "LA", "KZ", "KY", "KW", "KR", "KN",
    "KH", "KG", "KE", "JP", "JO", "JM", "IT", "IS", "IR", "IQ", "IN", "IL", "IE", "ID", "HU", "HT", "HR",
    "HN", "HK", "GY", "GW", "GU", "GT", "GR", "GQ", "GP", "GN", "GM", "GI", "GH", "GF", "GE", "GB", "GA",
    "FR", "FJ", "FI", "ET", "ES", "EG", "EE", "EC", "DZ", "DO", "DK", "DJ", "DE", "CZ", "CY", "CV", "CU",
    "CR", "CO", "CN", "CM", "CL", "CI", "CH", "CG", "CF", "CD", "CA", "BZ", "BY", "BW", "BT", "BR", "BO",
    "BN", "BJ", "BH", "BG", "BF", "BE", "BD", "BB", "BA", "AZ", "AW", "AU", "AT", "AR", "AO", "AM", "AL",
    "AF", "AE"
]

def make_request(params: Dict) -> Dict:
    """发送API请求"""
    import urllib.request
    import urllib.parse

    if not API_KEY:
        raise ValueError("API密钥未设置，请设置AXON_API_KEY环境变量")

    # 构建URL
    url = f"{API_BASE_URL}?{urllib.parse.urlencode(params)}"

    try:
        print(f"  请求URL: {API_BASE_URL}")
        print(f"  请求参数: {params}")

        req = urllib.request.Request(url)
        req.add_header("User-Agent", "OpenClaw-Axon-Reporting-Client/1.0.0")

        with urllib.request.urlopen(req, timeout=30) as response:
            response_text = response.read().decode('utf-8')
            print(f"  响应状态: {response.status}")
            print(f"  响应内容: {response_text[:200]}...")

            if params.get("format", "json") == "json":
                return json.loads(response_text)
            else:
                return {"data": response_text, "format": "csv"}
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        print(f"  HTTP错误 {e.code}: {e.reason}")
        print(f"  错误详情: {error_body}")
        raise Exception(f"API请求失败: HTTP Error {e.code}: {e.reason} - {error_body}")
    except Exception as e:
        print(f"  异常: {str(e)}")
        raise Exception(f"API请求失败: {str(e)}")

def query_product_data(product_name: str, start_date: str, end_date: str) -> List[Dict]:
    """查询单个产品的数据"""
    params = {
        "api_key": API_KEY,
        "start": start_date,
        "end": end_date,
        "columns": ",".join(EXPORT_CSV_METRICS),
        "filter_product": product_name,
        "day_column": "day",
        "format": "json",
        "report_type": "advertiser"
    }

    result = make_request(params)

    # 解析返回的数据
    data = []
    if isinstance(result, dict) and "results" in result:
        for row in result["results"]:
            # 验证国家代码
            country_code = row.get("country", "")
            if country_code and country_code.upper() in COUNTRY_CODES:
                data.append({
                    "产品": product_name,
                    "日期": row.get("day", ""),
                    "Campaign": row.get("campaign", ""),
                    "国家": country_code.upper(),
                    "消耗": row.get("cost", 0),
                    "转化数": row.get("conversions", 0),
                    "ROI1": row.get("roas_1d", 0),
                    "ROI3": row.get("roas_3d", 0),
                    "ROI7": row.get("roas_7d", 0)
                })
            else:
                # 如果国家代码无效，记录警告但仍然包含数据
                print(f"  警告: 无效的国家代码 '{country_code}'，跳过此记录")
    elif isinstance(result, list):
        for row in result:
            country_code = row.get("country", "")
            if country_code and country_code.upper() in COUNTRY_CODES:
                data.append({
                    "产品": product_name,
                    "日期": row.get("day", ""),
                    "Campaign": row.get("campaign", ""),
                    "国家": country_code.upper(),
                    "消耗": row.get("cost", 0),
                    "转化数": row.get("conversions", 0),
                    "ROI1": row.get("roas_1d", 0),
                    "ROI3": row.get("roas_3d", 0),
                    "ROI7": row.get("roas_7d", 0)
                })
            else:
                print(f"  警告: 无效的国家代码 '{country_code}'，跳过此记录")

    return data

def export_all_products_to_csv(days_back: int = 45, output_file: str = None) -> str:
    """
    拉取T-45到T-1（昨天）所有产品的数据，并导出到CSV文件

    Args:
        days_back: 拉取多少天的历史数据（默认45天）
        output_file: 输出文件名，None则自动生成

    Returns:
        CSV文件路径
    """
    # 计算日期范围
    end_date = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    start_date = (datetime.now() - timedelta(days=days_back)).strftime("%Y-%m-%d")

    print(f"开始导出数据，时间范围: {start_date} 到 {end_date}")
    print(f"产品数量: {len(AVAILABLE_PRODUCTS)}")

    # 收集所有数据
    all_data = []

    for i, product in enumerate(AVAILABLE_PRODUCTS, 1):
        print(f"[{i}/{len(AVAILABLE_PRODUCTS)}] 正在查询产品: {product}")

        try:
            data = query_product_data(product, start_date, end_date)
            all_data.extend(data)
            print(f"  -> 获取到 {len(data)} 条记录")
        except Exception as e:
            print(f"  -> 查询失败: {str(e)}")
            continue

    # 生成输出文件名
    if output_file is None:
        output_file = f"all_products_data_{start_date}_to_{end_date}.csv"

    # 导出到CSV
    if all_data:
        df = pd.DataFrame(all_data)
        df.to_csv(output_file, index=False, encoding='utf-8-sig')
        print(f"\n✅ 数据导出成功！")
        print(f"   文件名: {output_file}")
        print(f"   总记录数: {len(all_data)}")
        return output_file
    else:
        raise Exception("没有获取到任何数据")

if __name__ == "__main__":
    try:
        csv_file = export_all_products_to_csv(days_back=45)
        print(f"\n最终文件: {csv_file}")
    except Exception as e:
        print(f"\n❌ 导出失败: {str(e)}")
        exit(1)
