---
name: axon-reporting-api
description: 提供AppLovin Axon广告投放数据查询和ROAS分析能力；当用户需要查询广告数据、分析Campaign表现、监控ROAS指标或生成投放报告时使用
dependency:
  python:
    - requests>=2.31.0
    - pandas>=2.0.0
    - openpyxl>=3.1.0
    - tabulate>=0.9.0
---

# Axon Reporting API Skill

## 任务目标
- 本Skill用于: 查询和分析AppLovin Axon广告投放数据，包括Campaign表现、ROAS指标、收入分析等
- 能力包含: 产品/Campaign数据查询、ROAS分析、收入分析、留存分析、数据导出、Campaign比较分析、批量导出所有产品数据
- 触发条件: 用户需要查询广告数据、分析ROAS、监控投放效果、生成报告或导出数据时

## 前置准备
- 依赖说明: 脚本所需的依赖包及版本
  ```
  requests>=2.31.0
  pandas>=2.0.0
  openpyxl>=3.1.0
  tabulate>=0.9.0
  ```

## 操作步骤
- 标准流程:
  1. **参数准备**: 确定产品名称或Campaign名称、时间范围、查询指标
  2. **数据查询**: 调用 `scripts/axon_reporting.py` 中的相应函数查询数据
  3. **结果处理**: 根据需求分析数据、生成报告或导出结果

- 可选分支:
  - 当需要基础数据: 使用 `query_campaign()` 或 `batch_query_campaigns()`
  - 当需要ROAS分析: 使用 `analyze_roas()` 或 `get_campaign_roas_data()`
  - 当需要批量导出所有产品: 使用 `export_all_products_to_csv()`
  - 当需要比较Campaign: 使用 `compare_campaigns()`
  - 当需要导出数据: 使用 `export_data()`
  - 当需要生成报告: 使用 `generate_campaign_report()`
  - 当需要获取产品列表: 使用 `get_product_list()`

## 查询方式说明
- **产品名称查询**: 使用 `product_name` 参数，按产品维度聚合数据
- **Campaign名称查询**: 使用 `campaign_name` 参数，按具体Campaign查询数据
- **优先级**: 当同时提供 `product_name` 和 `campaign_name` 时，优先使用 `product_name`

## 可用产品列表

当前支持的产品名称：
- `ios.pretty.boutique.merge.game`
- `ios.his.grip.match.game`
- `com.serenasecret.mergegame`
- `com.serena.mergemakeover.ios`
- `com.project.labuub.merge.game`
- `com.mansion.affairs.merge.game`
- `com.his.grip.match.game`
- `com.gbd.amy.secret.game`
- `com.amy.secret.game`

## ROAS术语说明
- **D0/D1/D3/D7/D28 ROAS** = Total ROAS (IAA + IAP combined)
- **D0/D1/D3/D7/D28 IAP ROAS** = IAP ROAS only
- **D0/D1/D3/D7/D28 IAA ROAS** = IAA (Ad) ROAS only
- **ROI格式**: 百分比转换为小数（50% → 0.5）

## 数据源说明
- **默认**: Cohort数据（按用户获取日期分组），使用 `day_column=day` 参数
- **Realtime**: 仅在明确要求时使用（如"查询realtime数据"），不添加 `day_column` 参数

## 资源索引
- 必要脚本: 见 [scripts/axon_reporting.py](scripts/axon_reporting.py)（提供完整的Axon Reporting API客户端，支持按产品或Campaign查询、分析、比较、导出和批量导出功能）

## 注意事项
- 所有查询需要有效的AppLovin Axon Reporting API密钥
- 日期格式必须为 YYYY-MM-DD
- 默认使用Cohort数据，需要Realtime数据时需明确指定
- API密钥通过环境变量 AXON_API_KEY 提供，由凭证系统自动注入
- 按产品名称查询时，API会使用 `filter_product` 参数进行筛选
- 批量导出功能默认拉取T-45到T-1（昨天）的数据
- ROI值会自动从百分比转换为小数格式（50% → 0.5）

## 使用示例

### 批量导出所有产品数据到CSV（T-45到T-1）
```python
from scripts.axon_reporting import export_all_products_to_csv

# 导出最近45天的所有产品数据
csv_file = export_all_products_to_csv(days_back=45)

# CSV包含字段：
# - dt: 日期
# - campaign: Campaign名称
# - 产品: 产品名称
# - 国家: 国家代码
# - 消耗: 广告消耗
# - CPA: 单次转化成本
# - ROI1: 1日ROI（小数格式，0.5表示50%）
# - ROI3: 3日ROI
# - ROI7: 7日ROI
```

### 指定输出文件名
```python
from scripts.axon_reporting import export_all_products_to_csv

csv_file = export_all_products_to_csv(
    days_back=45,
    output_file="my_products_data.csv"
)
print(f"数据已保存到: {csv_file}")
```

### 获取可用产品列表
```python
from scripts.axon_reporting import get_product_list

products = get_product_list()
print(products)
# 输出: ['ios.pretty.boutique.merge.game', 'ios.his.grip.match.game', ...]
```

### 按产品名称查询
```python
from scripts.axon_reporting import get_campaign_roas_data

data = get_campaign_roas_data(
    product_name="ios.pretty.boutique.merge.game",
    start_date="2026-02-01",
    end_date="now"
)
```

### 按Campaign名称查询
```python
from scripts.axon_reporting import get_campaign_roas_data

data = get_campaign_roas_data(
    campaign_name="ios.pretty.boutique.merge.game",
    start_date="2026-02-01",
    end_date="now"
)
```

### 批量查询多个Campaign
```python
from scripts.axon_reporting import AxonReportingClient

client = AxonReportingClient()
products = ["ios.pretty.boutique.merge.game", "com.serenasecret.mergegame"]

results = {}
for product in products:
    results[product] = client.query_campaign(
        product_name=product,
        start_date="2026-02-01",
        end_date="now"
    )
```

## 错误处理
- **API密钥错误**: 检查API密钥是否正确配置
- **日期格式错误**: 确保使用 YYYY-MM-DD 格式
- **网络错误**: 检查网络连接和API服务状态
- **参数错误**: 必须提供 `product_name` 或 `campaign_name` 中的至少一个参数
- **数据为空**: 某些产品可能没有数据，会自动跳过并记录日志
