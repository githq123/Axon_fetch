---
name: axon-reporting-api
description: 提供AppLovin Axon广告投放数据查询和ROAS分析能力；当用户需要查询广告数据、分析Campaign表现、监控ROAS指标或生成投放报告时使用
dependency:
  python:
    - pandas>=2.0.0
---

# Axon Reporting API Skill

## 任务目标
- 本Skill用于: 查询和分析AppLovin Axon广告投放数据，包括Campaign表现、ROAS指标、收入分析等
- 能力包含: 产品/Campaign数据查询、ROAS分析、收入分析、留存分析、数据导出、Campaign比较分析、批量导出所有产品数据
- 触发条件: 用户需要查询广告数据、分析ROAS、监控投放效果、生成报告或导出数据时

## 前置准备
- 依赖说明: 脚本所需的依赖包及版本
  ```
  pandas>=2.0.0
  ```
- 临时导出脚本使用Python标准库，无需额外依赖

## 操作步骤
- 标准流程:
  1. **参数准备**: 确定产品名称或Campaign名称、时间范围、查询指标
  2. **数据查询**: 调用 `scripts/` 中的相应脚本查询数据
  3. **结果处理**: 根据需求分析数据、生成报告或导出结果

- 可选分支:
  - 当需要批量导出所有产品: 使用 `scripts/export_products_fix.py`（推荐，使用标准库）
  - 当需要获取产品列表: 查看脚本中的 `AVAILABLE_PRODUCTS` 列表

## 可用产品列表

当前支持的产品名称：
- `ios.pretty.boutique.merge.game`
- `ios.his.grip.match.game`
- `com.serenasecret.mergegame`
- `com.serena.mergemakeover.ios`
- `com.project.labuub.merge.game`
- `com.mansion.affairs.merge.game`
- `com.his.grip.match.game`
- `com.gbd.amy.secret.game`
- `com.amy.secret.game`

## 资源索引
- 导出脚本: 见 [scripts/export_products_fix.py](scripts/export_products_fix.py)（批量导出所有产品数据到CSV，使用Python标准库）

## 注意事项
- 所有查询需要有效的AppLovin Axon Reporting API密钥
- API密钥通过环境变量 AXON_API_KEY 提供
- 批量导出功能默认拉取T-45到T-1（昨天）的数据
- ROI值会自动从百分比转换为小数格式（50% → 0.5）
- CSV字段包含：dt, campaign, 产品, 国家, 消耗, 转化数, ROI1, ROI3, ROI7

## 使用示例

### 批量导出所有产品数据到CSV（T-45到T-1）
```bash
# 直接运行导出脚本
python scripts/export_products_fix.py
```

**CSV输出字段**：
- `dt`：日期
- `campaign`：Campaign名称
- `产品`：产品名称
- `国家`：国家代码（245个国家/地区）
- `消耗`：广告消耗
- `转化数`：转化数量
- `ROI1`：1日ROI（小数格式，0.5表示50%）
- `ROI3`：3日ROI
- `ROI7`：7日ROI

**输出示例**：
```
开始导出数据，时间范围: 2026-01-23 到 2026-03-08
产品数量: 9
[1/9] 正在查询产品: ios.pretty.boutique.merge.game
  -> 获取到 43 条记录
...
✅ 数据导出成功！
   文件名: all_products_data_2026-01-23_to_2026-03-08.csv
   总记录数: 385
```

## 错误处理
- **API密钥错误**: 检查API密钥是否正确设置在环境变量AXON_API_KEY中
- **网络错误**: 检查网络连接和API服务状态
- **数据为空**: 某些产品可能没有数据，会自动跳过并记录日志
- **无效国家代码**: 自动过滤无效的国家代码，仅保留有效的ISO标准代码
