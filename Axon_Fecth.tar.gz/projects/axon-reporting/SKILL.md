---
name: axon-reporting
description: 提供AppLovin Axon Reporting API的完整数据查询、分析和导出能力；当用户需要查询广告投放数据、分析ROAS性能、导出CSV报告或监控Campaign表现时使用。
dependency:
  python:
    - requests>=2.31.0
    - pandas>=2.0.0
    - openpyxl>=3.1.0
    - tabulate>=0.9.0
    - pyyaml>=6.0
  system:
    - mkdir -p ~/.openclaw/workspace/exports
---

# Axon Reporting API Skill

## Description
专业的AppLovin Axon广告投放数据查询和分析工具。提供完整的Reporting API访问能力，支持Campaign性能分析、ROAS监控、数据导出等功能。

## When to Use
- 需要查询AppLovin Axon广告投放数据时
- 分析Campaign表现和ROAS指标时
- 生成广告投放报告时
- 监控广告预算和效果时

## Prerequisites
1. AppLovin Axon Reporting API密钥
2. Python requests库（已预装）

## ROAS Terminology

**Default Behavior:**
- **D0/D1/D3/D7/D28 ROAS** = Total ROAS (IAA + IAP combined)
- **D0/D1/D3/D7/D28 IAP ROAS** = IAP ROAS only
- **D0/D1/D3/D7/D28 IAA ROAS** = IAA (Ad) ROAS only

**Examples:**
- "查询D7 ROAS" → 返回 Total ROAS (IAA + IAP)
- "查询D7 IAP ROAS" → 返回 IAP ROAS only
- "查询D7 IAA ROAS" → 返回 Ad ROAS only

## Data Source

**Default: Cohort Data**
- 所有查询默认使用 **cohort data**（按用户获取日期分组）
- Cohort 数据准确，会随时间更新
- 使用 `day_column=day` 参数

**Realtime Data (explicitly requested)**
- 仅在明确要求时使用: "查询realtime数据"
- Realtime 数据是估算值，可能与cohort不同
- 查询时不添加 `day_column` 参数

## API Configuration

### Base Configuration
```python
API_BASE_URL = "https://r.applovin.com/report"
API_KEY = "your_reporting_key_here"  # 从Axon Dashboard获取
```

### Report Types
- `advertiser`: 广告主数据（投放侧）
- `publisher`: 发布者数据（变现侧）

## Core Functions

### 1. 基础数据查询
查询Campaign基础表现数据（展示、点击、转化、成本等）

### 2. ROAS分析
分析不同时间窗口的ROAS指标（7日、28日等）

### 3. 收入分析
查询内购收入和总收入数据

### 4. 留存分析
分析用户留存率数据

### 5. 数据导出
将查询结果导出为JSON、CSV等格式

### 6. 模糊查询
支持字段值的包含匹配，不区分大小写

### 7. 诊断工具
提供查询诊断功能，帮助快速定位查询问题

## API Configuration

Axon Reporting Client 支持三种方式配置 API 密钥：

### 1. 环境变量（推荐）
```bash
export COZE_AXON_API_7615249631357927458="your_api_key_here"
```

### 2. 配置文件
创建配置文件 `~/.openclaw/workspace/config/axon.yml`：

```yaml
api_key: "your_api_key_here"
```

### 3. 代码中传入
```python
client = AxonReportingClient(api_key="your_api_key_here")
```

**优先级**：代码传入 > 环境变量 COZE_AXON_API_* > 配置文件 > 环境变量 AXON_API_KEY

## Usage Examples

### 灵活查询（推荐）
所有参数都可选，支持任意组合的筛选条件：

```python
from axon_reporting import AxonReportingClient

client = AxonReportingClient()

# 无任何条件（默认查询最近7天所有数据）
data = client.query()

# 按应用查询
data = client.query(app="com.example.app")

# 按Campaign查询
data = client.query(campaign="MyCampaign")

# 按国家和平台查询
data = client.query(country="US", platform="iOS")

# 多个国家组合
data = client.query(country=["US", "GB", "CA"])

# 按消耗值筛选
data = client.query(min_cost=1000, max_cost=5000)

# 按ROAS筛选
data = client.query(min_roas_7d=2.0)

# 组合条件
data = client.query(
    app="com.example.app",
    platform="iOS",
    min_cost=1000,
    min_roas_7d=1.5
)

# 指定时间范围和多个条件
data = client.query(
    start="2026-02-01",
    end="2026-02-28",
    campaign="MyCampaign",
    country=["US", "GB"],
    min_roas_7d=1.0,
    max_cost=10000
)
```

### 数据保存为 CSV

```python
from axon_reporting import AxonReportingClient
from axon_onebyone_runner import save_to_cache

# 查询数据（获取所有列的完整数据）
client = AxonReportingClient()
data = client.query(
    start="2026-03-01",
    end="now",
    campaign_fuzzy="*grip*"
)

# 保存到缓存文件
filepath = save_to_cache(data)
print(f"数据已保存到: {filepath}")
```

**文件配置**：
- **脚本位置**：`~/.openclaw/workspace/scripts/axon_onebyone_runner.py`
- **缓存文件**：`~/.openclaw/workspace/exports/axon_monitor_cache.csv`
- **数据说明**：查询时获取所有列的完整数据，保存时只输出简化格式（dt, campaign, product_name, country, cost, cpa, roi1, roi3, roi7）

**其他功能**：
- `save_with_filters()`: 带筛选条件保存
- `append_to_cache()`: 追加数据到缓存（不覆盖）
- `get_cache_filepath()`: 获取缓存文件路径

详细说明见 [Runner 使用指南](references/runner-usage-guide.md)
```

### Cohort vs Realtime 数据口径

**Cohort 数据（默认，use_cohort=True）**：
- 按用户获取日期分组
- 适用于分析用户生命周期价值（LTV）
- 如果最近没有新用户获取，数据可能为空

**Realtime 数据（use_cohort=False）**：
- 按活动发生日期分组
- 适用于监控实时投放效果
- 推荐用于日常数据监控和报表

```python
from axon_reporting import AxonReportingClient

client = AxonReportingClient()

# 使用 Cohort 数据（默认）
data = client.query(use_cohort=True)  # 或直接省略该参数

# 使用 Realtime 数据（推荐用于日常监控）
data = client.query(use_cohort=False)

# 查询特定时间范围的 Realtime 数据
data = client.query(
    start="2026-03-01",
    end="now",
    campaign_like="grip",
    use_cohort=False  # 使用 Realtime 口径
)
```

**建议**：
- 日常投放监控：使用 `use_cohort=False`（Realtime）
- LTV 分析和用户生命周期研究：使用 `use_cohort=True`（Cohort）

### 查询诊断工具

当查询结果为空或不符合预期时，使用诊断工具快速定位问题：

#### 1. 完整诊断脚本

```bash
# 运行完整诊断
python ~/.openclaw/workspace/scripts/diagnose_grip_query.py
```

该脚本会自动测试多种查询方式：
- Cohort 口径 + 模糊查询
- Realtime 口径 + 模糊查询（推荐）
- Realtime 口径 + 查询所有 Campaign

并给出推荐的查询方法。

#### 2. 列出所有 Campaign

```bash
# 查看所有可用的 Campaign
python ~/.openclaw/workspace/scripts/list_all_campaigns.py
```

该脚本会列出近7日所有有消耗的 Campaign，帮助找到正确的 Campaign 名称。

#### 3. Realtime 查询脚本

```bash
# 使用 Realtime 口径查询 grip 产品
python ~/.openclaw/workspace/scripts/query_grip_realtime.py
```

该脚本使用 Realtime 口径查询 grip 产品数据，并自动保存到 CSV 文件。

**常见问题及解决方案**：

| 问题 | 可能原因 | 解决方案 |
|------|----------|----------|
| 查询结果为空 | Cohort 口径无新用户 | 使用 `use_cohort=False` |
| 找不到 Campaign | 关键词不匹配 | 运行 `list_all_campaigns.py` 查看所有 Campaign |
| API 认证失败 | API 密钥错误 | 检查配置文件 `~/.openclaw/workspace/config/axon.yml` |
| 时间范围无数据 | 日期设置不正确 | 调整 `start` 和 `end` 参数 |

### 高级模糊查询（推荐用于复杂匹配）

```python
from axon_reporting import AxonReportingClient

client = AxonReportingClient()

# 包含匹配（不区分大小写，默认）
data = client.query(campaign_fuzzy="MyApp")

# 通配符匹配（* 匹配任意字符）
data = client.query(campaign_fuzzy="MyApp*")

# 正则表达式匹配
data = client.query(campaign_fuzzy="^MyApp.*Test$")

# 精确匹配（区分大小写）
data = client.query(campaign_fuzzy="MyApp_IOS", fuzzy_mode="exact")

# 大小写敏感的包含匹配
data = client.query(campaign_fuzzy="MyApp", case_sensitive=True)

# 按产品名称模糊查询
data = client.query(product_fuzzy="Beauty")

# 组合使用：通配符 + 数值条件
data = client.query(
    campaign_fuzzy="Test*",
    min_cost=1000,
    min_roas_7d=2.0
)

# 多个高级模糊条件
data = client.query(
    campaign_fuzzy="*IOS*",
    country_fuzzy="U*"
)
```

### 基础模糊查询（简单包含匹配）

```python
from axon_reporting import AxonReportingClient

client = AxonReportingClient()

# 查询 Campaign 名称包含 "MyApp" 的所有数据（不区分大小写）
data = client.query(campaign_like="MyApp")

# 查询应用名称包含 "example" 的所有数据
data = client.query(app_like="example")

# 查询平台名称包含 "iOS" 的数据
data = client.query(platform_like="ios")

# 模糊查询 + 精确筛选组合
data = client.query(
    campaign_like="MyApp",
    platform="iOS",
    min_cost=1000
)

# 多个模糊条件
data = client.query(
    campaign_like="Test",
    country_like="US"
)
```

### 批量查询多个Campaign
```python
from axon_reporting import AxonReportingClient

client = AxonReportingClient()

campaigns = [
    "InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203",
    "HeyBeauty_AND_AL_D7Ad_ROAS_20260215",
    "Joylit_IOS_AL_D0IAP_CPP_20260220"
]

results = client.batch_query_campaigns(
    campaigns=campaigns,
    start_date="2026-02-01",
    end_date="now"
)
```

### 生成投放报告
```python
from axon_reporting import AxonReportingClient

client = AxonReportingClient()

report = client.generate_campaign_report(
    campaign_name="InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203",
    start_date="2026-02-01",
    end_date="now",
    report_format="markdown"  # 支持markdown, html, json
)
```

# 按应用、国家和设备筛选
data = client.query(
    start="2026-02-01",
    app="com.example.app",
    country="US",
    device="phone",
    metrics=["impressions", "clicks", "cost", "roas_7d"]
)
```

## Available Tools

### 工具1: axon_query（推荐）
完全灵活的查询方法，所有参数都可选

**参数**:
- 时间参数（可选）:
  - `start`: 开始日期（YYYY-MM-DD格式），默认7天前
  - `end`: 结束日期（YYYY-MM-DD或"now"），默认"now"
- 维度筛选（可选，任意组合）:
  - `campaign`: Campaign名称（精确匹配）
  - `app`: 应用名称（精确匹配）
  - `country`: 国家代码（支持单个或列表）
  - `platform`: 平台（iOS/Android）
  - `network`: 广告网络
  - `device`: 设备类型
- 基础模糊查询（可选，任意组合）:
  - `campaign_like`: Campaign名称包含匹配（不区分大小写）
  - `app_like`: 应用名称包含匹配（不区分大小写）
  - `country_like`: 国家代码包含匹配（不区分大小写）
  - `platform_like`: 平台名称包含匹配（不区分大小写）
  - `network_like`: 网络名称包含匹配（不区分大小写）
  - `device_like`: 设备类型包含匹配（不区分大小写）
- 高级模糊查询（可选，任意组合，推荐用于复杂匹配）:
  - `campaign_fuzzy`: Campaign名称高级模糊查询
  - `product_fuzzy`: 产品名称高级模糊查询
  - `app_fuzzy`: 应用名称高级模糊查询
  - `country_fuzzy`: 国家代码高级模糊查询
  - `platform_fuzzy`: 平台名称高级模糊查询
  - `network_fuzzy`: 网络名称高级模糊查询
  - `device_fuzzy`: 设备类型高级模糊查询
  - `fuzzy_mode`: 匹配模式（可选）
    - `auto`: 自动识别（默认）
    - `contains`: 包含匹配
    - `regex`: 正则表达式匹配
    - `wildcard`: 通配符匹配（* 和 ?）
    - `exact`: 精确匹配
  - `case_sensitive`: 是否区分大小写（默认False）
- 数值条件筛选（可选）:
  - `min_cost`: 最小消耗值
  - `max_cost`: 最大消耗值
  - `min_impressions`: 最小展示数
  - `max_impressions`: 最大展示数
  - `min_clicks`: 最小点击数
  - `max_clicks`: 最大点击数
  - `min_conversions`: 最小转化数
  - `max_conversions`: 最大转化数
  - `min_roas_*`: 最小ROAS（如 min_roas_7d）
  - `max_roas_*`: 最大ROAS（如 max_roas_7d）
  - `min_iap_roas_*`: 最小内购ROAS
  - `max_iap_roas_*`: 最大内购ROAS
- 其他可选参数:
  - `metrics`: 查询指标列表
  - `report_type`: 报告类型（默认"advertiser"）
  - `format`: 返回格式（默认"json"）
  - `use_cohort`: 是否使用cohort数据（默认True）

**返回**: JSON格式的查询结果

**优势**: 
- 所有参数都可选，无必需参数
- 支持精确匹配、基础模糊查询、高级模糊查询和数值条件组合
- 高级模糊查询支持多种匹配模式（自动、包含、正则、通配符、精确）
- 兼容大小写（可通过 case_sensitive 参数控制）
- 无需构造filters字典，使用更直观

**示例**:
```python
# 无任何条件（默认查询最近7天）
client.query()

# 基础模糊查询：Campaign名称包含 "MyApp"
client.query(campaign_like="MyApp")

# 高级模糊查询：自动识别匹配模式
client.query(campaign_fuzzy="MyApp")  # 包含匹配
client.query(campaign_fuzzy="MyApp*")  # 通配符匹配
client.query(campaign_fuzzy="^MyApp.*Test$")  # 正则匹配

# 高级模糊查询：指定匹配模式和大小写敏感
client.query(campaign_fuzzy="MyApp", fuzzy_mode="exact", case_sensitive=True)
client.query(campaign_fuzzy="*IOS*", fuzzy_mode="wildcard")

# 组合：模糊查询 + 数值条件
client.query(campaign_fuzzy="Test", min_cost=1000, min_roas_7d=2.0)
```

# 组合：模糊查询 + 数值条件
client.query(campaign_like="Test", min_cost=1000, min_roas_7d=2.0)
```client.query()

# 按应用查询
client.query(app="com.example.app")

# 按消耗值筛选
client.query(min_cost=1000, max_cost=5000)

# 按ROAS筛选
client.query(min_roas_7d=2.0)

# 复杂组合
client.query(
    app="com.example.app",
    platform="iOS",
    min_cost=1000,
    min_roas_7d=1.5
)
```

### 工具3: axon_compare_campaigns
比较多个Campaign的表现

**参数**:
- `campaigns`: Campaign名称列表
- `start_date`: 开始日期
- `end_date`: 结束日期
- `primary_metric`: 主要比较指标

**返回**: 比较分析报告

### 工具4: axon_export_data
导出查询数据到文件

**参数**:
- `data`: 查询数据
- `format`: 导出格式（json, csv, excel）
- `filename`: 文件名

**返回**: 文件路径

### 工具6: axon_get_campaign_list
获取可用的Campaign列表

**参数**:
- `app_filter`: 应用筛选（可选）
- `platform_filter`: 平台筛选（可选）

**返回**: Campaign列表
- `time_window`: 时间窗口（7d, 28d等）
- `start_date`: 开始日期
- `end_date`: 结束日期

**返回**: ROAS分析报告

### 工具4: axon_compare_campaigns
比较多个Campaign的表现

**参数**:
- `campaigns`: Campaign名称列表
- `start_date`: 开始日期
- `end_date`: 结束日期
- `primary_metric`: 主要比较指标

**返回**: 比较分析报告

### 工具5: axon_export_data
导出查询数据到文件

**参数**:
- `data`: 查询数据
- `format`: 导出格式（json, csv, excel）
- `filename`: 文件名

**返回**: 文件路径

### 工具6: axon_get_campaign_list
获取可用的Campaign列表

**参数**:
- `app_filter`: 应用筛选（可选）
- `platform_filter`: 平台筛选（可选）

**返回**: Campaign列表

## Error Handling

### 常见错误
1. **API密钥错误**: 检查API密钥是否正确
2. **日期格式错误**: 使用YYYY-MM-DD格式
3. **列名错误**: 使用正确的列名格式
4. **网络错误**: 检查网络连接

### 错误码
- `400`: 请求参数错误
- `401`: 认证失败
- `403`: 权限不足
- `429`: 请求频率过高
- `500`: 服务器错误

## Best Practices

### 1. 数据缓存
对于频繁查询的数据，建议实现缓存机制

### 2. 错误重试
实现指数退避的重试机制

### 3. 数据验证
验证API返回数据的完整性和准确性

### 4. 安全存储
安全存储API密钥，避免硬编码

## Integration Examples

### 与OpenClaw其他技能集成
```python
# 与数据分析技能集成
