# Axon 基础数据存储脚本使用指南

## 文件信息

**脚本文件**：`~/.openclaw/workspace/scripts/axon_onebyone_runner.py`

**用途**：写入缓存 CSV

**缓存文件**：`~/.openclaw/workspace/exports/axon_monitor_cache.csv`

**用途**：Axon 基础数据存储文件（CSV）

## 功能说明

### 核心功能

1. **save_to_cache()** - 保存数据到缓存文件
2. **save_with_filters()** - 带筛选条件保存数据
3. **append_to_cache()** - 追加数据到缓存文件
4. **get_cache_filepath()** - 获取缓存文件路径

## 使用方法

### 方法 1：保存所有数据到缓存

```python
from axon_reporting import AxonReportingClient
from axon_onebyone_runner import save_to_cache

# 查询数据（获取所有列的完整数据）
client = AxonReportingClient()
data = client.query(
    start="2026-03-01",
    end="now",
    campaign_fuzzy="*grip*"
)

# 保存到缓存文件
filepath = save_to_cache(data)
print(f"数据已保存到: {filepath}")
```

### 方法 2：保存特定产品数据

```python
from axon_reporting import AxonReportingClient
from axon_onebyone_runner import save_with_filters

# 查询数据
client = AxonReportingClient()
data = client.query(start="2026-03-01", end="now")

# 筛选并保存 grip 产品数据到缓存
filepath = save_with_filters(
    data,
    filters={"campaign": "*grip*"}
)
```

### 方法 3：追加数据到缓存

```python
from axon_onebyone_runner import append_to_cache

# 追加新数据到缓存文件（不覆盖现有数据）
filepath = append_to_cache(data)
```

### 方法 4：获取缓存文件路径

```python
from axon_onebyone_runner import get_cache_filepath

cache_path = get_cache_filepath()
print(f"缓存文件位置: {cache_path}")
# 输出: /root/.openclaw/workspace/exports/axon_monitor_cache.csv
```

## 完整示例：查询 grip 产品近7天数据并保存

```python
from axon_reporting import AxonReportingClient
from axon_onebyone_runner import save_to_cache, get_cache_filepath

# 初始化客户端
client = AxonReportingClient()

# 查询 grip 产品近7天的数据（获取所有列）
data = client.query(
    campaign_fuzzy="*grip*"
)

# 保存到缓存文件
filepath = save_to_cache(data)

print(f"✅ 查询完成，共 {len(data)} 条记录")
print(f"✅ 数据已保存到缓存: {filepath}")
```

## CSV 格式说明

### 输出列

| 列名 | 说明 | 示例 |
|------|------|------|
| dt | 日期 | 2026-03-09 |
| campaign | Campaign 名称 | InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203 |
| product_name | 产品名称（从 Campaign 提取） | InHisGrip |
| country | 国家代码 | US |
| cost | 消耗成本 | 1000.50 |
| cpa | CPA（每次转化成本） | 10.01 |
| roi1 | D1 ROI（小数格式） | 0.15 |
| roi3 | D3 ROI（小数格式） | 0.35 |
| roi7 | D7 ROI（小数格式） | 0.66 |

### ROI 格式转换规则

- **百分比格式**（如 50% → 50）：自动转换为小数（0.50）
- **小数格式**（如 1.5）：直接使用
- **转换逻辑**：如果 ROAS > 10，则除以 100 转换为小数

### CPA 计算公式

```
CPA = Cost / Conversions
```

- 如果 Conversions = 0，则 CPA = 0

### 产品名称提取

- Campaign 命名格式：`AppName_Platform_Network_Target_Optimization_Date`
- 产品名称：提取第一部分（AppName）
- 例如：`InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203` → `InHisGrip`

## 路径配置

### 默认路径

- **脚本位置**：`~/.openclaw/workspace/scripts/axon_onebyone_runner.py`
- **缓存文件**：`~/.openclaw/workspace/exports/axon_monitor_cache.csv`

### 路径自动处理

- 自动展开 `~` 为用户主目录
- 自动创建不存在的目录
- 支持自定义路径覆盖

### 自定义路径

```python
from axon_onebyone_runner import save_to_cache

# 使用自定义路径
custom_path = "/path/to/custom/cache.csv"
save_to_cache(data, filename=custom_path)
```

## 目录结构

```
~/.openclaw/workspace/
├── scripts/
│   └── axon_onebyone_runner.py    # 数据存储脚本
└── exports/
    └── axon_monitor_cache.csv     # 缓存数据文件
```

## 注意事项

1. **数据格式**：
   - ROI 数据会自动从百分比转换为小数（50% → 0.50）
   - CPA 保留 2 位小数
   - ROI 保留 2 位小数

2. **文件处理**：
   - `save_to_cache()`：覆盖现有文件
   - `append_to_cache()`：追加到现有文件
   - 目录不存在时自动创建

3. **编码格式**：
   - CSV 文件使用 UTF-8 编码
   - 支持中文和其他特殊字符

4. **空值处理**：
   - 如果字段为空，默认为空字符串
   - 如果 ROAS 为空，默认为 0.0
   - 如果无法计算 CPA，默认为 0.0

## 错误处理

```python
try:
    filepath = save_to_cache(data)
except ValueError as e:
    print(f"保存失败: {e}")
except Exception as e:
    print(f"发生错误: {e}")
```

常见错误：
- `ValueError: 数据为空，无法保存` - 查询结果为空
- `PermissionError` - 没有写入权限
- `OSError` - 磁盘空间不足

## 集成到自动化流程

```python
import schedule
import time
from axon_reporting import AxonReportingClient
from axon_onebyone_runner import save_to_cache

def update_cache():
    """定时更新缓存"""
    try:
        client = AxonReportingClient()
        data = client.query(start="2026-03-01", end="now")
        save_to_cache(data)
        print("✅ 缓存已更新")
    except Exception as e:
        print(f"❌ 更新失败: {e}")

# 每小时更新一次
schedule.every().hour.do(update_cache)

while True:
    schedule.run_pending()
    time.sleep(60)
```
