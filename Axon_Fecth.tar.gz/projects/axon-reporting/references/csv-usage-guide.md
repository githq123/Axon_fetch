# CSV 数据存储脚本使用指南

## 功能说明

`save_to_csv.py` 脚本用于将 Axon Reporting 查询结果保存为 CSV 文件，并自动格式化数据。

## 支持的格式

### CSV 列说明

| 列名 | 说明 | 示例 |
|------|------|------|
| dt | 日期 | 2026-03-09 |
| campaign | Campaign 名称 | InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203 |
| product_name | 产品名称（从 Campaign 提取） | InHisGrip |
| country | 国家代码 | US |
| cost | 消耗成本 | 1000.50 |
| cpa | CPA（每次转化成本） | 10.01 |
| roi1 | D1 ROI（小数格式） | 0.15 |
| roi3 | D3 ROI（小数格式） | 0.35 |
| roi7 | D7 ROI（小数格式） | 0.66 |

### ROI 格式转换规则

- **百分比格式**（如 50% → 50）：自动转换为小数（0.50）
- **小数格式**（如 1.5）：直接使用
- **转换逻辑**：如果 ROAS > 10，则除以 100 转换为小数

## 使用方法

### 方法 1：保存所有数据

```python
from axon_reporting import AxonReportingClient
from save_to_csv import save_to_csv

# 查询数据
client = AxonReportingClient()
data = client.query(
    start="2026-03-01",
    end="2026-03-09",
    campaign_fuzzy="*grip*"
)

# 保存为 CSV
filename = save_to_csv(data)
print(f"数据已保存到: {filename}")
```

### 方法 2：保存特定产品数据

```python
from axon_reporting import AxonReportingClient
from save_to_csv import save_with_filters

# 查询数据
client = AxonReportingClient()
data = client.query(start="2026-03-01", end="now")

# 筛选并保存 grip 产品数据
filename = save_with_filters(
    data,
    filename="grip_product_data.csv",
    filters={"campaign": "*grip*"}
)
```

### 方法 3：带多个筛选条件保存

```python
# 筛选美国地区的 grip 产品数据
filename = save_with_filters(
    data,
    filename="grip_us_data.csv",
    filters={
        "campaign": "*grip*",
        "country": "US"
    }
)
```

## 完整示例

### 查询 grip 产品近7天数据并保存

```python
from axon_reporting import AxonReportingClient
from save_to_csv import save_to_csv

# 初始化客户端
client = AxonReportingClient()

# 查询 grip 产品近7天的数据（默认获取所有列）
data = client.query(
    campaign_fuzzy="*grip*"
)

# 保存为 CSV 文件（自动提取需要的列）
filename = save_to_csv(data, filename="grip_last_7days.csv")

print(f"✅ 查询完成，共 {len(data)} 条记录")
print(f"✅ 数据已保存到: {filename}")
```

**重要说明**：
- 查询时默认获取所有列（完整数据）
- 保存 CSV 时只输出指定列（dt, campaign, product_name, country, cost, cpa, roi1, roi3, roi7）
- 无需手动指定 metrics，系统自动获取所有可用指标

## 数据字段说明

### 查询时的完整数据

查询时默认获取所有可用指标（完整数据），包括：

**基础指标**：
- day, campaign, impressions, clicks, conversions, cost

**ROAS 指标（D0/D1/D3/D7/D28）**：
- roas_0d, iap_roas_0d, iap_rev_0d, total_rev_0d
- roas_1d, iap_roas_1d, iap_rev_1d, total_rev_1d
- roas_3d, iap_roas_3d, iap_rev_3d, total_rev_3d
- roas_7d, iap_roas_7d, iap_rev_7d, total_rev_7d
- roas_28d, iap_roas_28d, iap_rev_28d, total_rev_28d

**收入指标**：
- iap_rev_0d, iap_rev_7d, total_rev_0d, total_rev_7d

**留存指标**：
- ret_7d, ret_28d

**高级指标**：
- installs, spend, cpi, cpc, ctr

### CSV 输出的简化格式

保存 CSV 时只输出以下列：

| 列名 | 说明 | 数据来源 |
|------|------|----------|
| dt | 日期 | day |
| campaign | Campaign 名称 | campaign |
| product_name | 产品名称 | 从 campaign 提取 |
| country | 国家代码 | country |
| cost | 消耗成本 | cost |
| cpa | CPA（每次转化成本） | cost / conversions |
| roi1 | D1 ROI（小数格式） | roas_1d（格式化） |
| roi3 | D3 ROI（小数格式） | roas_3d（格式化） |
| roi7 | D7 ROI（小数格式） | roas_7d（格式化） |

### 产品名称提取

- Campaign 命名格式：`AppName_Platform_Network_Target_Optimization_Date`
- 产品名称：提取第一部分（AppName）
- 例如：`InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203` → `InHisGrip`

### CPA 计算公式

```
CPA = Cost / Conversions
```

- 如果 Conversions = 0，则 CPA = 0
- 数据来源：查询结果中的 cost 和 conversions 字段

### ROI 格式转换规则

- **百分比格式**（如 50% → 50）：自动转换为小数（0.50）
- **小数格式**（如 1.5）：直接使用
- **转换逻辑**：如果 ROAS > 10，则除以 100 转换为小数
- 数据来源：查询结果中的 roas_1d, roas_3d, roas_7d 字段

## 输出示例

### 生成的 CSV 文件内容

```csv
dt,campaign,product_name,country,cost,cpa,roi1,roi3,roi7
2026-03-09,InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203,InHisGrip,US,1000.5,10.01,0.15,0.35,0.66
2026-03-08,InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203,InHisGrip,US,950.25,9.52,0.18,0.38,0.70
2026-03-07,InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203,InHisGrip,US,1100.0,11.0,0.12,0.32,0.62
```

## 注意事项

1. **数据格式**：
   - ROI 数据会自动从百分比转换为小数（50% → 0.50）
   - CPA 保留 2 位小数
   - ROI 保留 2 位小数

2. **文件命名**：
   - 默认文件名：`axon_data_YYYYMMDD_HHMMSS.csv`
   - 可以自定义文件名

3. **编码格式**：
   - CSV 文件使用 UTF-8 编码
   - 支持中文和其他特殊字符

4. **空值处理**：
   - 如果字段为空，默认为空字符串
   - 如果 ROAS 为空，默认为 0.0
   - 如果无法计算 CPA，默认为 0.0

## 错误处理

```python
try:
    filename = save_to_csv(data)
except ValueError as e:
    print(f"保存失败: {e}")
```

常见错误：
- `ValueError: 数据为空，无法保存` - 查询结果为空
- `ValueError: 无效的 ROAS 值` - ROAS 数据格式不正确
