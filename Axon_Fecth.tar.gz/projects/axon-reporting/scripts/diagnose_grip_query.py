#!/usr/bin/env python3
"""
诊断 grip 产品查询问题

提供多种查询方式，帮助找到正确的查询方法
"""

import os
import sys
from datetime import datetime, timedelta

# 添加 scripts 目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 使用独立版本的客户端
try:
    from axon_reporting_standalone import AxonReportingClient
except ImportError:
    print("错误：无法导入 axon_reporting_standalone 模块")
    sys.exit(1)

def diagnose_query():
    """
    诊断 grip 产品查询问题
    """
    # 初始化客户端
    client = AxonReportingClient()
    
    # 计算时间范围（T-7 到 T-1）
    end_date = datetime.now()
    start_date = end_date - timedelta(days=7)
    
    start_str = start_date.strftime("%Y-%m-%d")
    end_str = end_date.strftime("%Y-%m-%d")
    
    print("=" * 60)
    print("🔍 Grip 产品查询诊断")
    print("=" * 60)
    print(f"📅 查询时间范围: {start_str} 到 {end_str}\n")
    
    # 测试1：Cohort 口径 + 模糊查询
    print("测试 1: Cohort 口径 + 模糊查询 (原始方法)")
    print("-" * 60)
    data1 = client.query(
        start=start_str,
        end=end_str,
        campaign_like="grip",
        use_cohort=True
    )
    result1 = len(data1.get("data", [])) if "data" in data1 else 0
    print(f"结果: {result1} 条记录\n")
    
    # 测试2：Realtime 口径 + 模糊查询
    print("测试 2: Realtime 口径 + 模糊查询 (推荐方法)")
    print("-" * 60)
    data2 = client.query(
        start=start_str,
        end=end_str,
        campaign_like="grip",
        use_cohort=False
    )
    result2 = len(data2.get("data", [])) if "data" in data2 else 0
    print(f"结果: {result2} 条记录")
    if result2 > 0:
        print("✅ 找到数据！建议使用 Realtime 口径查询")
        print("\n前3条记录：")
        for i, row in enumerate(data2["data"][:3], 1):
            print(f"  {i}. {row.get('day')} | {row.get('campaign', 'N/A')[:60]}")
    print()
    
    # 测试3：Realtime 口径 + 无筛选（查询所有）
    print("测试 3: Realtime 口径 + 无筛选（查询所有 Campaign）")
    print("-" * 60)
    data3 = client.query(
        start=start_str,
        end=end_str,
        use_cohort=False
    )
    result3 = len(data3.get("data", [])) if "data" in data3 else 0
    print(f"结果: {result3} 条记录")
    
    if result3 > 0:
        # 提取所有 Campaign 名称
        campaigns = set()
        for row in data3["data"]:
            campaign = row.get('campaign', 'N/A')
            campaigns.add(campaign)
        
        print(f"共找到 {len(campaigns)} 个不同的 Campaign")
        
        # 筛选包含 "grip" 的 Campaign
        grip_campaigns = [c for c in campaigns if 'grip' in c.lower()]
        
        if grip_campaigns:
            print(f"\n✅ 找到 {len(grip_campaigns)} 个包含 'grip' 的 Campaign：")
            for i, campaign in enumerate(grip_campaigns, 1):
                cost = sum(float(row.get('cost', 0)) for row in data3["data"] if row.get('campaign') == campaign)
                print(f"  {i}. {campaign}")
                print(f"     7日总消耗: ${cost:,.2f}")
            
            # 建议使用精确 Campaign 名称查询
            print(f"\n💡 建议：使用以下精确 Campaign 名称查询：")
            print(f"   client.query(campaign=\"{grip_campaigns[0]}\", use_cohort=False)")
        else:
            print(f"\n⚠️  未找到包含 'grip' 关键词的 Campaign")
            print(f"\n💡 所有 Campaign 列表（前10个）：")
            for i, campaign in enumerate(sorted(campaigns)[:10], 1):
                cost = sum(float(row.get('cost', 0)) for row in data3["data"] if row.get('campaign') == campaign)
                print(f"  {i}. {campaign[:60]}")
                print(f"     7日总消耗: ${cost:,.2f}")
            if len(campaigns) > 10:
                print(f"  ... 还有 {len(campaigns) - 10} 个 Campaign")
            
            print(f"\n💡 建议：选择上述任意一个 Campaign 名称进行精确查询")
    else:
        print("❌ 未找到任何数据")
        print("\n可能原因：")
        print("  1. API 认证失败（请检查配置文件中的 API 密钥）")
        print("  2. 近7日无任何投放数据")
        print("  3. 时间范围设置不正确")
    
    print("\n" + "=" * 60)
    print("诊断完成")
    print("=" * 60)
    
    # 返回最有效的查询方法
    if result2 > 0:
        print("\n✅ 推荐查询方法：")
        print("   使用 Realtime 口径 + 模糊查询")
        print(f"   client.query(start=\"{start_str}\", end=\"{end_str}\", campaign_like=\"grip\", use_cohort=False)")
    elif result3 > 0:
        print("\n✅ 推荐查询方法：")
        print("   使用 Realtime 口径 + 精确 Campaign 名称")
        print("   client.query(campaign=\"<准确的Campaign名称>\", use_cohort=False)")
    else:
        print("\n❌ 未找到有效的查询方法，请检查：")
        print("   1. API 密钥配置是否正确")
        print("   2. 是否有近7日的投放数据")
        print("   3. 时间范围设置是否正确")

if __name__ == "__main__":
    diagnose_query()
