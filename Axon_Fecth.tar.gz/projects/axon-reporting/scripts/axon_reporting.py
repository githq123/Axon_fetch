#!/usr/bin/env python3
"""
AppLovin Axon Reporting API Client
提供完整的广告投放数据查询和分析功能

ROAS Terminology:
- D0/D1/D3/D7/D28 ROAS = Total ROAS (IAA + IAP) by default
- IAP ROAS = IAP revenue only
- IAA ROAS = Ad revenue only

Data Source:
- Default: Cohort data (grouped by user acquisition date)
- Realtime: Use use_cohort=False for realtime estimates
"""

import os
import json
import csv
import re
from coze_workload_identity import requests
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Union, Any
from dataclasses import dataclass
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# API配置
API_BASE_URL = "https://r.applovin.com/report"
skill_id = "7615249631357927458"

# 从环境变量或配置文件获取API密钥
def _load_api_key() -> Optional[str]:
    """
    加载API密钥
    
    优先级：
    1. 环境变量 COZE_AXON_API_7615249631357927458
    2. 配置文件 ~/.openclaw/workspace/config/axon.yml 中的 api_key
    3. 环境变量 AXON_API_KEY（兼容）
    """
    # 1. 优先尝试环境变量
    api_key = os.getenv("COZE_AXON_API_7615249631357927458")
    if api_key:
        logger.info("从环境变量 COZE_AXON_API_7615249631357927458 加载 API 密钥")
        return api_key
    
    # 2. 尝试从配置文件读取
    config_path = os.path.expanduser("~/.openclaw/workspace/config/axon.yml")
    try:
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                import yaml
                config = yaml.safe_load(f)
                if config and isinstance(config, dict):
                    api_key = config.get('api_key')
                    if api_key:
                        logger.info(f"从配置文件 {config_path} 加载 API 密钥")
                        return api_key
    except Exception as e:
        logger.warning(f"读取配置文件失败: {e}")
    
    # 3. 兼容旧环境变量名
    api_key = os.getenv("AXON_API_KEY")
    if api_key:
        logger.info("从环境变量 AXON_API_KEY 加载 API 密钥")
        return api_key
    
    logger.warning("未找到 API 密钥配置")
    return None

API_KEY = _load_api_key()

# 常用指标列
# ROAS columns: D0/D1/D3/D7/D28 formats
# Default: roas_Xd = Total ROAS (IAA + IAP)
# IAP only: iap_roas_Xd
COMMON_METRICS = {
    "basic": ["day", "campaign", "impressions", "clicks", "conversions", "cost"],
    # D0 metrics
    "roas_d0": ["roas_0d", "iap_roas_0d", "iap_rev_0d", "total_rev_0d"],
    # D1 metrics
    "roas_d1": ["roas_1d", "iap_roas_1d", "iap_rev_1d", "total_rev_1d"],
    # D3 metrics
    "roas_d3": ["roas_3d", "iap_roas_3d", "iap_rev_3d", "total_rev_3d"],
    # D7 metrics (common)
    "roas_d7": ["roas_7d", "iap_roas_7d", "iap_rev_7d", "total_rev_7d"],
    # D28 metrics
    "roas_d28": ["roas_28d", "iap_roas_28d", "iap_rev_28d", "total_rev_28d"],
    # Revenue
    "revenue": ["iap_rev_0d", "iap_rev_7d", "total_rev_0d", "total_rev_7d"],
    # Retention
    "retention": ["ret_7d", "ret_28d"],
    # Advanced
    "advanced": ["installs", "spend", "cpi", "cpc", "ctr"]
}

# 完整指标列表（用于获取所有列）
ALL_METRICS = []
for metrics_list in COMMON_METRICS.values():
    ALL_METRICS.extend(metrics_list)
# 去重
ALL_METRICS = list(dict.fromkeys(ALL_METRICS))

@dataclass
class CampaignInfo:
    """Campaign信息数据类"""
    name: str
    app: str
    platform: str
    network: str
    target: str
    optimization: str
    date: str
    full_name: str
    
    @classmethod
    def from_name(cls, campaign_name: str) -> 'CampaignInfo':
        """从Campaign名称解析信息"""
        parts = campaign_name.split('_')
        if len(parts) >= 6:
            return cls(
                name=campaign_name,
                app=parts[0],
                platform=parts[1],
                network=parts[2],
                target=parts[3],
                optimization=parts[4],
                date=parts[5],
                full_name=campaign_name
            )
        return cls(
            name=campaign_name,
            app="unknown",
            platform="unknown",
            network="unknown",
            target="unknown",
            optimization="unknown",
            date="unknown",
            full_name=campaign_name
        )

class AxonAPIError(Exception):
    """Axon API错误异常"""
    pass

class AxonReportingClient:
    """AppLovin Axon Reporting API客户端"""
    
    def __init__(self, api_key: str = None, base_url: str = None):
        """
        初始化客户端
        
        Args:
            api_key: Axon Reporting API密钥
            base_url: API基础URL
        """
        self.api_key = api_key or API_KEY
        self.base_url = base_url or API_BASE_URL
        
        if not self.api_key:
            logger.warning("API密钥未设置，请设置AXON_API_KEY环境变量或在调用时传入")
        
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "OpenClaw-Axon-Reporting-Client/1.0.0"
        })
    
    def _make_request(self, params: Dict) -> Dict:
        """
        发送API请求
        
        Args:
            params: 请求参数
            
        Returns:
            API响应数据
            
        Raises:
            AxonAPIError: API请求失败
        """
        try:
            response = self.session.get(self.base_url, params=params, timeout=30)
            response.raise_for_status()
            
            # 解析响应
            if params.get("format", "json") == "json":
                return response.json()
            else:
                return {"data": response.text, "format": "csv"}
                
        except requests.exceptions.RequestException as e:
            logger.error(f"API请求失败: {e}")
            raise AxonAPIError(f"API请求失败: {e}")
        except json.JSONDecodeError as e:
            logger.error(f"JSON解析失败: {e}")
            raise AxonAPIError(f"JSON解析失败: {e}")
    
    def query_campaign(self,
                      campaign_name: str,
                      start_date: str,
                      end_date: str = "now",
                      metrics: List[str] = None,
                      report_type: str = "advertiser",
                      format: str = "json",
                      use_cohort: bool = True) -> Dict:
        """
        查询单个Campaign数据

        Args:
            campaign_name: Campaign名称
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD 或 "now")
            metrics: 查询指标列表，None则使用D0 Total ROAS指标
            report_type: 报告类型 (advertiser/publisher)
            format: 返回格式 (json/csv)
            use_cohort: 使用cohort数据 (默认True)。False为realtime。

        Returns:
            查询结果
        """
        if not self.api_key:
            raise AxonAPIError("API密钥未设置")

        # 设置默认指标 - D0 Total ROAS
        if metrics is None:
            metrics = COMMON_METRICS["basic"] + ["roas_0d"]

        params = {
            "api_key": self.api_key,
            "start": start_date,
            "end": end_date,
            "columns": ",".join(metrics),
            "format": format,
            "report_type": report_type,
            "filter_campaign": campaign_name
        }

        # Add day_column for cohort data (default behavior)
        if use_cohort:
            params["day_column"] = "day"

        data_type = "cohort" if use_cohort else "realtime"
        logger.info(f"查询Campaign: {campaign_name}, 时间范围: {start_date} 到 {end_date} ({data_type})")
        return self._make_request(params)
    
    def query(self, **kwargs) -> Dict:
        """
        完全灵活的查询方法，所有参数都可选
        
        参数说明：
        - 时间参数（可选）：
          * start: 开始日期（YYYY-MM-DD格式），默认7天前
          * end: 结束日期（YYYY-MM-DD或"now"），默认"now"
        
        - 维度筛选（可选）：
          * campaign: Campaign名称
          * app: 应用名称
          * country: 国家代码（支持单个值如"US"或列表如["US", "GB"]）
          * platform: 平台（如iOS、Android）
          * network: 广告网络
          * device: 设备类型
        
        - 数值条件筛选（可选，基于返回数据二次过滤）：
          * min_cost: 最小消耗值
          * max_cost: 最大消耗值
          * min_impressions: 最小展示数
          * max_impressions: 最大展示数
          * min_clicks: 最小点击数
          * max_clicks: 最大点击数
          * min_conversions: 最小转化数
          * max_conversions: 最大转化数
          * min_roas_*: 最小ROAS（支持不同时间窗口，如 min_roas_7d）
          * max_roas_*: 最大ROAS（支持不同时间窗口，如 max_roas_7d）
          * min_iap_roas_*: 最小内购ROAS
          * max_iap_roas_*: 最大内购ROAS
        
        - 其他可选参数：
          * metrics: 查询指标列表（默认D0 Total ROAS指标）
          * report_type: 报告类型（默认"advertiser"）
          * format: 返回格式（默认"json"）
          * use_cohort: 是否使用cohort数据（默认True）
        
        Returns:
            查询结果字典
        
        Examples:
            # 无任何条件（默认查询最近7天所有数据）
            client.query()
            
            # 按应用查询
            client.query(app="com.example.app")
            
            # 按消耗值筛选
            client.query(min_cost=1000, max_cost=5000)
            
            # 按ROAS筛选
            client.query(min_roas_7d=2.0)
            
            # 组合条件
            client.query(
                app="com.example.app",
                platform="iOS",
                min_cost=1000,
                min_roas_7d=1.5
            )
            
            # 指定时间范围和多个条件
            client.query(
                start="2026-02-01",
                end="2026-02-28",
                campaign="MyCampaign",
                country=["US", "GB"],
                min_roas_7d=1.0,
                max_cost=10000
            )
        """
        if not self.api_key:
            raise AxonAPIError("API密钥未设置")
        
        # 提取时间参数，设置默认值
        start = kwargs.pop("start", None)
        end = kwargs.pop("end", "now")
        
        # 如果没有提供时间范围，默认查询最近7天
        if not start:
            end_date_obj = datetime.now()
            start_date_obj = end_date_obj - timedelta(days=7)
            start = start_date_obj.strftime("%Y-%m-%d")
            logger.info(f"未指定时间范围，使用默认范围: 最近7天 ({start} 到 {end})")
        
        # 提取可选参数，设置默认值
        metrics = kwargs.pop("metrics", None)
        report_type = kwargs.pop("report_type", "advertiser")
        format_type = kwargs.pop("format", "json")
        use_cohort = kwargs.pop("use_cohort", True)
        
        # 设置默认指标 - 使用完整指标列表获取所有列
        if metrics is None:
            metrics = ALL_METRICS
        
        # 构建基础参数
        params = {
            "api_key": self.api_key,
            "start": start,
            "end": end,
            "columns": ",".join(metrics),
            "format": format_type,
            "report_type": report_type
        }
        
        # 定义维度筛选条件映射
        dimension_filters = {
            "campaign": "filter_campaign",
            "app": "filter_app",
            "country": "filter_country",
            "platform": "filter_platform",
            "network": "filter_network",
            "device": "filter_device"
        }
        
        # 定义数值条件前缀、模糊查询后缀和高级模糊查询后缀
        numeric_prefixes = ("min_", "max_")
        fuzzy_suffix = "_like"
        fuzzy_advanced_suffix = "_fuzzy"
        
        # 分离维度筛选、数值条件、基础模糊查询和高级模糊查询
        dimension_kwargs = {}
        numeric_kwargs = {}
        fuzzy_kwargs = {}
        fuzzy_advanced_kwargs = {}
        
        for key, value in kwargs.items():
            if key in dimension_filters:
                dimension_kwargs[key] = value
            elif key.startswith(numeric_prefixes):
                numeric_kwargs[key] = value
            elif key.endswith(fuzzy_suffix):
                fuzzy_kwargs[key] = value
            elif key.endswith(fuzzy_advanced_suffix):
                fuzzy_advanced_kwargs[key] = value
            else:
                logger.warning(f"不支持的参数: {key}，已忽略")
        
        # 处理维度筛选条件
        applied_filters = []
        for key, value in dimension_kwargs.items():
            param_name = dimension_filters[key]
            if isinstance(value, list):
                params[param_name] = ",".join(value)
                applied_filters.append(f"{key}=[{','.join(value)}]")
            else:
                params[param_name] = value
                applied_filters.append(f"{key}={value}")
        
        if applied_filters:
            logger.info(f"应用维度筛选: {', '.join(applied_filters)}")
        
        # Add day_column for cohort data (default behavior)
        if use_cohort:
            params["day_column"] = "day"
        
        data_type = "cohort" if use_cohort else "realtime"
        logger.info(f"执行查询: 时间范围 {start} 到 {end} ({data_type})")
        
        # 执行API查询
        result = self._make_request(params)
        
        # 应用基础模糊查询筛选（如果存在）
        if fuzzy_kwargs and "data" in result and result["data"]:
            logger.info(f"应用基础模糊查询筛选: {', '.join(fuzzy_kwargs.keys())}")
            filtered_data = self._apply_fuzzy_filters(result["data"], fuzzy_kwargs)
            result["data"] = filtered_data
            logger.info(f"基础模糊筛选后剩余 {len(filtered_data)} 条记录")
        
        # 应用高级模糊查询筛选（如果存在）
        if fuzzy_advanced_kwargs and "data" in result and result["data"]:
            logger.info(f"应用高级模糊查询筛选: {', '.join(fuzzy_advanced_kwargs.keys())}")
            
            # 提取匹配模式和大小写敏感选项
            fuzzy_mode = kwargs.pop("fuzzy_mode", "auto")
            case_sensitive = kwargs.pop("case_sensitive", False)
            
            filtered_data = self._apply_advanced_fuzzy_filters(
                result["data"], 
                fuzzy_advanced_kwargs,
                fuzzy_mode=fuzzy_mode,
                case_sensitive=case_sensitive
            )
            result["data"] = filtered_data
            logger.info(f"高级模糊筛选后剩余 {len(filtered_data)} 条记录")
        
        # 应用数值条件筛选（如果存在）
        if numeric_kwargs and "data" in result and result["data"]:
            logger.info(f"应用数值条件筛选: {', '.join(numeric_kwargs.keys())}")
            filtered_data = self._apply_numeric_filters(result["data"], numeric_kwargs)
            result["data"] = filtered_data
            logger.info(f"数值筛选后剩余 {len(filtered_data)} 条记录")
        
        return result
    
    def _apply_fuzzy_filters(self, data: List[Dict], filters: Dict) -> List[Dict]:
        """
        应用模糊查询筛选（包含匹配，不区分大小写）
        
        Args:
            data: 原始数据列表
            filters: 模糊查询条件字典，key格式为 "field_like"
        
        Returns:
            筛选后的数据列表
        """
        filtered = []
        
        for row in data:
            match = True
            
            for filter_key, filter_value in filters.items():
                # 提取字段名（去掉 "_like" 后缀）
                field_name = filter_key[:-5]
                
                # 检查字段是否存在
                if field_name not in row:
                    match = False
                    break
                
                # 进行包含匹配（不区分大小写）
                field_value = str(row[field_name]).lower()
                search_value = str(filter_value).lower()
                
                if search_value not in field_value:
                    match = False
                    break
            
            if match:
                filtered.append(row)
        
        return filtered
    
    def _apply_advanced_fuzzy_filters(self, data: List[Dict], filters: Dict, 
                                     fuzzy_mode: str = "auto", 
                                     case_sensitive: bool = False) -> List[Dict]:
        """
        应用高级模糊查询筛选（支持多种匹配模式）
        
        Args:
            data: 原始数据列表
            filters: 高级模糊查询条件字典，key格式为 "field_fuzzy"
            fuzzy_mode: 匹配模式
                - "auto": 自动识别（默认）
                - "contains": 包含匹配
                - "regex": 正则表达式匹配
                - "wildcard": 通配符匹配（* 和 ?）
                - "exact": 精确匹配
            case_sensitive: 是否区分大小写（默认False）
        
        Returns:
            筛选后的数据列表
        """
        filtered = []
        
        for row in data:
            match = True
            
            for filter_key, filter_value in filters.items():
                # 提取字段名（去掉 "_fuzzy" 后缀）
                field_name = filter_key[:-6]
                
                # 检查字段是否存在
                if field_name not in row:
                    match = False
                    break
                
                field_value = str(row[field_name])
                search_value = str(filter_value)
                
                # 确定匹配模式
                mode = fuzzy_mode
                if mode == "auto":
                    # 自动识别匹配模式
                    if "*" in search_value or "?" in search_value:
                        mode = "wildcard"
                    elif search_value.startswith("^") or search_value.endswith("$"):
                        mode = "regex"
                    else:
                        mode = "contains"
                
                # 应用匹配
                try:
                    if mode == "contains":
                        # 包含匹配
                        if case_sensitive:
                            if search_value not in field_value:
                                match = False
                                break
                        else:
                            if search_value.lower() not in field_value.lower():
                                match = False
                                break
                    
                    elif mode == "regex":
                        # 正则表达式匹配
                        flags = 0 if case_sensitive else re.IGNORECASE
                        if not re.search(search_value, field_value, flags):
                            match = False
                            break
                    
                    elif mode == "wildcard":
                        # 通配符匹配（* 和 ?）
                        pattern = search_value.replace(".", r"\.").replace("*", ".*").replace("?", ".")
                        flags = 0 if case_sensitive else re.IGNORECASE
                        if not re.fullmatch(pattern, field_value, flags):
                            match = False
                            break
                    
                    elif mode == "exact":
                        # 精确匹配
                        if case_sensitive:
                            if search_value != field_value:
                                match = False
                                break
                        else:
                            if search_value.lower() != field_value.lower():
                                match = False
                                break
                    
                    else:
                        logger.warning(f"不支持的匹配模式: {mode}")
                        match = False
                        break
                
                except re.error as e:
                    logger.error(f"正则表达式错误: {e}")
                    match = False
                    break
            
            if match:
                filtered.append(row)
        
        return filtered
    
    def _apply_numeric_filters(self, data: List[Dict], filters: Dict) -> List[Dict]:
        """
        应用数值条件筛选
        
        Args:
            data: 原始数据列表
            filters: 数值条件字典
        
        Returns:
            筛选后的数据列表
        """
        filtered = []
        
        for row in data:
            match = True
            
            for filter_key, filter_value in filters.items():
                # 提取字段名和操作类型
                if filter_key.startswith("min_"):
                    field_name = filter_key[4:]  # 去掉 "min_" 前缀
                    # 检查字段是否存在且值大于等于最小值
                    if field_name not in row:
                        match = False
                        break
                    try:
                        if float(row[field_name]) < float(filter_value):
                            match = False
                            break
                    except (ValueError, TypeError):
                        match = False
                        break
                
                elif filter_key.startswith("max_"):
                    field_name = filter_key[4:]  # 去掉 "max_" 前缀
                    # 检查字段是否存在且值小于等于最大值
                    if field_name not in row:
                        match = False
                        break
                    try:
                        if float(row[field_name]) > float(filter_value):
                            match = False
                            break
                    except (ValueError, TypeError):
                        match = False
                        break
            
            if match:
                filtered.append(row)
        
        return filtered
    
    def query_with_filters(self,
                         start_date: str,
                         end_date: str = "now",
                         metrics: List[str] = None,
                         filters: Dict[str, Union[str, List[str]]] = None,
                         report_type: str = "advertiser",
                         format: str = "json",
                         use_cohort: bool = True) -> Dict:
        """
        使用多个筛选条件查询数据
        
        Args:
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD 或 "now")
            metrics: 查询指标列表，None则使用D0 Total ROAS指标
            filters: 筛选条件字典，支持多个条件组合
                支持的筛选条件:
                - campaign: Campaign名称
                - app: 应用名称
                - country: 国家代码 (如 US, CN, GB)，支持列表
                - platform: 平台 (iOS/Android)
                - network: 广告网络
                - device: 设备类型
            report_type: 报告类型 (advertiser/publisher)
            format: 返回格式 (json/csv)
            use_cohort: 使用cohort数据 (默认True)。False为realtime。
        
        Returns:
            查询结果
            
        Examples:
            # 单个筛选条件
            query_with_filters(start_date="2026-02-01", filters={"country": "US"})
            
            # 多个筛选条件
            query_with_filters(
                start_date="2026-02-01",
                filters={
                    "campaign": "CampaignName",
                    "country": ["US", "GB"],
                    "platform": "iOS"
                }
            )
        """
        if not self.api_key:
            raise AxonAPIError("API密钥未设置")
        
        # 设置默认指标 - D0 Total ROAS
        if metrics is None:
            metrics = COMMON_METRICS["basic"] + ["roas_0d"]
        
        # 构建基础参数
        params = {
            "api_key": self.api_key,
            "start": start_date,
            "end": end_date,
            "columns": ",".join(metrics),
            "format": format,
            "report_type": report_type
        }
        
        # 添加筛选条件
        if filters:
            # 支持的筛选条件映射
            filter_mapping = {
                "campaign": "filter_campaign",
                "app": "filter_app",
                "country": "filter_country",
                "platform": "filter_platform",
                "network": "filter_network",
                "device": "filter_device"
            }
            
            for key, value in filters.items():
                if key in filter_mapping:
                    param_name = filter_mapping[key]
                    # 支持单个值和列表值
                    if isinstance(value, list):
                        params[param_name] = ",".join(value)
                    else:
                        params[param_name] = value
                    logger.info(f"添加筛选条件: {key}={value}")
                else:
                    logger.warning(f"不支持的筛选条件: {key}，已忽略")
        
        # Add day_column for cohort data (default behavior)
        if use_cohort:
            params["day_column"] = "day"
        
        data_type = "cohort" if use_cohort else "realtime"
        filter_info = ", ".join([f"{k}={v}" for k, v in (filters or {}).items()])
        logger.info(f"多条件查询: 时间范围 {start_date} 到 {end_date} ({data_type}), 筛选条件: {filter_info}")
        return self._make_request(params)
    
    def batch_query_campaigns(self,
                            campaigns: List[str],
                            start_date: str,
                            end_date: str = "now",
                            metrics: List[str] = None,
                            report_type: str = "advertiser") -> Dict[str, Dict]:
        """
        批量查询多个Campaign
        
        Args:
            campaigns: Campaign名称列表
            start_date: 开始日期
            end_date: 结束日期
            metrics: 查询指标列表
            report_type: 报告类型
            
        Returns:
            各Campaign的查询结果字典
        """
        results = {}
        
        for campaign in campaigns:
            try:
                result = self.query_campaign(
                    campaign_name=campaign,
                    start_date=start_date,
                    end_date=end_date,
                    metrics=metrics,
                    report_type=report_type
                )
                results[campaign] = result
                logger.info(f"成功查询Campaign: {campaign}")
                
            except AxonAPIError as e:
                logger.error(f"查询Campaign失败 {campaign}: {e}")
                results[campaign] = {"error": str(e)}
        
        return results
    
    def analyze_roas(self,
                    campaign_name: str,
                    time_window: str = "7d",
                    start_date: str = None,
                    end_date: str = "now",
                    use_cohort: bool = True) -> Dict:
        """
        分析Campaign的ROAS表现

        Args:
            campaign_name: Campaign名称
            time_window: 时间窗口 (0d, 1d, 3d, 7d, 28d等)
            start_date: 开始日期，None则自动计算
            end_date: 结束日期
            use_cohort: 使用cohort数据 (默认True)

        Returns:
            ROAS分析报告
        """
        # 自动计算开始日期
        if start_date is None:
            if end_date == "now":
                end_date_obj = datetime.now()
            else:
                end_date_obj = datetime.strptime(end_date, "%Y-%m-%d")

            # 根据时间窗口计算开始日期
            if time_window == "0d":
                days = 0
            elif time_window == "1d":
                days = 1
            elif time_window == "3d":
                days = 3
            elif time_window == "7d":
                days = 7
            elif time_window == "28d":
                days = 28
            elif time_window == "30d":
                days = 30
            elif time_window == "90d":
                days = 90
            elif time_window == "1y":
                days = 365
            else:
                days = 7  # 默认7天

            start_date_obj = end_date_obj - timedelta(days=days)
            start_date = start_date_obj.strftime("%Y-%m-%d")

        # 查询数据 - Total ROAS (IAA + IAP)
        metrics = [
            "day", "campaign", "impressions", "clicks", "conversions", "cost",
            f"roas_{time_window}", f"iap_roas_{time_window}", f"iap_rev_{time_window}",
            f"total_rev_{time_window}"
        ]

        data = self.query_campaign(
            campaign_name=campaign_name,
            start_date=start_date,
            end_date=end_date,
            metrics=metrics,
            use_cohort=use_cohort
        )
        
        # 分析ROAS
        if "data" in data and data["data"]:
            df = pd.DataFrame(data["data"])
            
            # 计算平均ROAS
            avg_roas = df[f"roas_{time_window}"].mean() if f"roas_{time_window}" in df.columns else None
            avg_iap_roas = df[f"iap_roas_{time_window}"].mean() if f"iap_roas_{time_window}" in df.columns else None
            
            # 计算总成本
            total_cost = df["cost"].sum() if "cost" in df.columns else None
            
            # 计算总收入
            total_iap_rev = df[f"iap_rev_{time_window}"].sum() if f"iap_rev_{time_window}" in df.columns else None
            
            analysis = {
                "campaign": campaign_name,
                "time_window": time_window,
                "date_range": f"{start_date} 到 {end_date}",
                "total_days": len(df),
                "average_roas": float(avg_roas) if avg_roas is not None else None,
                "average_iap_roas": float(avg_iap_roas) if avg_iap_roas is not None else None,
                "total_cost": float(total_cost) if total_cost is not None else None,
                "total_iap_revenue": float(total_iap_rev) if total_iap_rev is not None else None,
                "data_points": len(df),
                "summary": self._generate_roas_summary(avg_roas, avg_iap_roas)
            }
            
            return analysis
        else:
            return {"error": "未找到数据", "campaign": campaign_name}
    
    def _generate_roas_summary(self, roas: float, iap_roas: float) -> str:
        """生成ROAS总结"""
        if roas is None and iap_roas is None:
            return "无ROAS数据"
        
        summary_parts = []
        
        if roas is not None:
            if roas > 2.0:
                summary_parts.append(f"总ROAS优秀 ({roas:.2f})")
            elif roas > 1.0:
                summary_parts.append(f"总ROAS良好 ({roas:.2f})")
            else:
                summary_parts.append(f"总ROAS需优化 ({roas:.2f})")
        
        if iap_roas is not None:
            if iap_roas > 2.0:
                summary_parts.append(f"内购ROAS优秀 ({iap_roas:.2f})")
            elif iap_roas > 1.0:
                summary_parts.append(f"内购ROAS良好 ({iap_roas:.2f})")
            else:
                summary_parts.append(f"内购ROAS需优化 ({iap_roas:.2f})")
        
        return " | ".join(summary_parts)
    
    def compare_campaigns(self,
                         campaigns: List[str],
                         start_date: str,
                         end_date: str = "now",
                         primary_metric: str = "roas_7d") -> Dict:
        """
        比较多个Campaign的表现
        
        Args:
            campaigns: Campaign名称列表
            start_date: 开始日期
            end_date: 结束日期
            primary_metric: 主要比较指标
            
        Returns:
            比较分析报告
        """
        # 查询所有Campaign数据
        all_data = self.batch_query_campaigns(
            campaigns=campaigns,
            start_date=start_date,
            end_date=end_date,
            metrics=["day", "campaign", "impressions", "clicks", "cost", primary_metric]
        )
        
        comparison = {
            "date_range": f"{start_date} 到 {end_date}",
            "primary_metric": primary_metric,
            "campaigns": {},
            "ranking": []
        }
        
        # 分析每个Campaign
        for campaign, data in all_data.items():
            if "error" in data:
                comparison["campaigns"][campaign] = {"error": data["error"]}
                continue
            
            if "data" in data and data["data"]:
                df = pd.DataFrame(data["data"])
                
                # 计算指标
                total_impressions = df["impressions"].sum() if "impressions" in df.columns else 0
                total_clicks = df["clicks"].sum() if "clicks" in df.columns else 0
                total_cost = df["cost"].sum() if "cost" in df.columns else 0
                avg_primary = df[primary_metric].mean() if primary_metric in df.columns else None
                
                # 计算CTR
                ctr = (total_clicks / total_impressions * 100) if total_impressions > 0 else 0
                
                # 计算CPC
                cpc = (total_cost / total_clicks) if total_clicks > 0 else 0
                
                campaign_info = CampaignInfo.from_name(campaign)
                
                comparison["campaigns"][campaign] = {
                    "app": campaign_info.app,
                    "platform": campaign_info.platform,
                    "target": campaign_info.target,
                    "total_impressions": int(total_impressions),
                    "total_clicks": int(total_clicks),
                    "total_cost": float(total_cost),
                    "ctr": float(ctr),
                    "cpc": float(cpc),
                    f"average_{primary_metric}": float(avg_primary) if avg_primary is not None else None,
                    "data_points": len(df)
                }
                
                # 添加到排名
                if avg_primary is not None:
                    comparison["ranking"].append({
                        "campaign": campaign,
                        "value": float(avg_primary),
                        "metric": primary_metric
                    })
        
        # 排序排名
        comparison["ranking"].sort(key=lambda x: x["value"], reverse=True)
        
        return comparison
    
    def export_data(self, data: Dict, format: str = "json", filename: str = None) -> str:
        """
        导出数据到文件
        
        Args:
            data: 要导出的数据
            format: 导出格式 (json, csv, excel)
            filename: 文件名，None则自动生成
            
        Returns:
            文件路径
        """
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"axon_export_{timestamp}.{format}"
        
        filepath = os.path.join(os.getcwd(), filename)
        
        try:
            if format == "json":
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
            
            elif format == "csv":
                if "data" in data and isinstance(data["data"], list):
                    df = pd.DataFrame(data["data"])
                    df.to_csv(filepath, index=False, encoding='utf-8-sig')
                else:
                    # 如果不是标准数据结构，保存为JSON
                    with open(filepath, 'w', encoding='utf-8') as f:
                        json.dump(data, f, ensure_ascii=False, indent=2)
            
            elif format == "excel":
                if "data" in data and isinstance(data["data"], list):
                    df = pd.DataFrame(data["data"])
                    df.to_excel(filepath, index=False)
                else:
                    # 保存为JSON
                    json_filepath = filepath.replace('.xlsx', '.json')
                    with open(json_filepath, 'w', encoding='utf-8') as f:
                        json.dump(data, f, ensure_ascii=False, indent=2)
                    filepath = json_filepath
            
            logger.info(f"数据已导出到: {filepath}")
            return filepath
            
        except Exception as e:
            logger.error(f"导出数据失败: {e}")
            raise AxonAPIError(f"导出数据失败: {e}")
    
    def get_campaign_suggestions(self, app: str = None, platform: str = None) -> List[str]:
        """
        获取Campaign建议列表（基于命名规则）
        
        Args:
            app: 应用筛选
            platform: 平台筛选
            
        Returns:
            Campaign名称列表
        """
        # 这里可以根据实际情况从数据库或配置文件中获取
        # 目前返回一些示例Campaign
        
        sample_campaigns = [
            "InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203",
            "HeyBeauty_AND_AL_D7Ad_ROAS_20260215",
            "Joylit_IOS_AL_D0IAP_CPP_20260220",
            "Amy_AND_AL_D28IAP_ROAS_20260210",
            "Serena_IOS_AL_D7Ad_CPP_20260218",
            "JoyVox_AND_AL_D0IAP_ROAS_20260225"
        ]
        
        suggestions = []
        
        for campaign in sample_campaigns:
            info = CampaignInfo.from_name(campaign)
            
            # 应用筛选
            if app and info.app.lower() != app.lower():
                continue
            
            # 平台筛选
            if platform and info.platform.lower() != platform.lower():
                continue
            
            suggestions.append(campaign)
        
        return suggestions
    
    def validate_campaign_name(self, campaign_name: str) -> Dict:
        """
        验证Campaign名称格式
        
        Args:
            campaign_name: Campaign名称
            
        Returns:
            验证结果
        """
        info = CampaignInfo.from_name(campaign_name)
        
        validation = {
            "campaign": campaign_name,
            "is_valid_format": info.date != "unknown",
            "parsed_info": {
                "app": info.app,
                "platform": info.platform,
                "network": info.network,
                "target": info.target,
                "optimization": info.optimization,
                "date": info.date
            },
            "suggestions": []
        }
        
        # 如果格式无效，提供建议
        if not validation["is_valid_format"]:
            validation["suggestions"] = [
                "Campaign名称应遵循格式: [App]_[Platform]_[Network]_[Target]_[Optimization]_[Date]",
                "示例: InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203",
                "请检查名称格式是否正确"
            ]
        
        return validation

# 工具函数
def get_campaign_roas_data(campaign_name: str, start_date: str, end_date: str = "now", **kwargs) -> Dict:
    """
    获取Campaign ROAS数据的便捷函数
    
    Args:
        campaign_name: Campaign名称
        start_date: 开始日期
        end_date: 结束日期
        **kwargs: 其他参数
        
    Returns:
        ROAS数据
    """
    client = AxonReportingClient()
    return client.analyze_roas(campaign_name, start_date=start_date, end_date=end_date, **kwargs)

def batch_query_campaigns(campaigns: List[str], start_date: str, end_date: str = "now", **kwargs) -> Dict:
    """
    批量查询Campaign的便捷函数
    
    Args:
        campaigns: Campaign列表
        start_date: 开始日期
        end_date: 结束日期
        **kwargs: 其他参数
        
    Returns:
        批量查询结果
    """
    client = AxonReportingClient()
    return client.batch_query_campaigns(campaigns, start_date, end_date, **kwargs)

def generate_campaign_report(campaign_name: str, start_date: str, end_date: str = "now", 
                           report_format: str = "markdown", **kwargs) -> str:
    """
    生成Campaign报告的便捷函数
    
    Args:
        campaign_name: Campaign名称
        start_date: 开始日期
        end_date: 结束日期
        report_format: 报告格式 (markdown, html, json)
        **kwargs: 其他参数
        
    Returns:
        报告内容
    """
    client = AxonReportingClient()
    
    # 查询数据
    data = client.query_campaign(campaign_name, start_date, end_date)
    roas_analysis = client.analyze_roas(campaign_name, start_date=start_date, end_date=end_date)
    
    # 生成报告
    if report_format == "markdown":
        return _generate_markdown_report(campaign_name, data, roas_analysis, start_date, end_date)
    elif report_format == "html":
        return _generate_html_report(campaign_name, data, roas_analysis, start_date, end_date)
    else:
        return json.dumps({
            "campaign": campaign_name,
            "date_range": f"{start_date} 到 {end_date}",
            "raw_data": data,
            "roas_analysis": roas_analysis
        }, ensure_ascii=False, indent=2)

def _generate_markdown_report(campaign_name: str, data: Dict, roas_analysis: Dict, 
                            start_date: str, end_date: str) -> str:
    """生成Markdown格式报告"""
    report = f"""# Campaign投放分析报告

## 基本信息
- **Campaign**: {campaign_name}
- **时间范围**: {start_date} 到 {end_date}
- **生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## ROAS分析
"""
    
    if "error" not in roas_analysis:
        report += f"""
- **时间窗口**: {roas_analysis.get('time_window', 'N/A')}
- **平均总ROAS**: {roas_analysis.get('average_roas', 'N/A'):.2f}
- **平均内购ROAS**: {roas_analysis.get('average_iap_roas', 'N/A'):.2f}
- **总成本**: ${roas_analysis.get('total_cost', 'N/A'):.2f}
- **总内购收入**: ${roas_analysis.get('total_iap_revenue', 'N/A'):.2f}
- **总结**: {roas_analysis.get('summary', 'N/A')}
"""
    else:
        report += f"\n**错误**: {roas_analysis.get('error', '未知错误')}\n"
    
    # 数据概览
    if "data" in data and data["data"]:
        df = pd.DataFrame(data["data"])
        report += f"""
## 数据概览
- **数据点数**: {len(df)} 天
- **数据列**: {', '.join(df.columns.tolist())}

## 最近5天数据
{df.head().to_markdown(index=False)}

## 关键指标统计
"""
        # 计算关键指标
        if "impressions" in df.columns:
            report += f"- **总展示**: {df['impressions'].sum():,.0f}\n"
        if "clicks" in df.columns:
            report += f"- **总点击**: {df['clicks'].sum():,.0f}\n"
        if "cost" in df.columns:
            report += f"- **总成本**: ${df['cost'].sum():,.2f}\n"
        if "conversions" in df.columns:
            report += f"- **总转化**: {df['conversions'].sum():,.0f}\n"
    
    report += "\n---\n*报告由OpenClaw Axon Reporting Skill生成*"
    return report

def _generate_html_report(campaign_name: str, data: Dict, roas_analysis: Dict,
                         start_date: str, end_date: str) -> str:
    """生成HTML格式报告"""
    markdown_report = _generate_markdown_report(campaign_name, data, roas_analysis, start_date, end_date)
    
    # 简单的Markdown转HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Campaign投放分析报告 - {campaign_name}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }}
        h1 {{ color: #333; border-bottom: 2px solid #eee; }}
        h2 {{ color: #555; margin-top: 30px; }}
        .info {{ background: #f5f5f5; padding: 15px; border-radius: 5px; }}
        .metric {{ margin: 10px 0; padding: 10px; background: #e8f4f8; border-left: 4px solid #2196F3; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #f2f2f2; }}
        .footer {{ margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; color: #777; font-size: 0.9em; }}
    </style>
</head>
<body>
    <h1>Campaign投放分析报告</h1>
    
    <div class="info">
        <strong>Campaign</strong>: {campaign_name}<br>
        <strong>时间范围</strong>: {start_date} 到 {end_date}<br>
        <strong>生成时间</strong>: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
    </div>
"""
    
    # 添加ROAS分析
    if "error" not in roas_analysis:
        html += f"""
    <h2>ROAS分析</h2>
    <div class="metric">
        <strong>时间窗口</strong>: {roas_analysis.get('time_window', 'N/A')}<br>
        <strong>平均总ROAS</strong>: {roas_analysis.get('average_roas', 'N/A'):.2f}<br>
        <strong>平均内购ROAS</strong>: {roas_analysis.get('average_iap_roas', 'N/A'):.2f}<br>
        <strong>总成本</strong>: ${roas_analysis.get('total_cost', 'N/A'):.2f}<br>
        <strong>总内购收入</strong>: ${roas_analysis.get('total_iap_revenue', 'N/A'):.2f}<br>
        <strong>总结</strong>: {roas_analysis.get('summary', 'N/A')}
    </div>
"""
    
    # 添加数据表格
    if "data" in data and data["data"]:
        df = pd.DataFrame(data["data"])
        html += f"""
    <h2>数据概览</h2>
    <p><strong>数据点数</strong>: {len(df)} 天</p>
    <p><strong>数据列</strong>: {', '.join(df.columns.tolist())}</p>
    
    <h3>最近5天数据</h3>
    {df.head().to_html(index=False, classes='data-table')}
"""
    
    html += """
    <div class="footer">
        报告由OpenClaw Axon Reporting Skill生成
    </div>
</body>
</html>
"""
    
    return html

# 命令行接口
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="AppLovin Axon Reporting API工具")
    subparsers = parser.add_subparsers(dest="command", help="命令")
    
    # query命令
    query_parser = subparsers.add_parser("query", help="查询Campaign数据")
    query_parser.add_argument("campaign", help="Campaign名称")
    query_parser.add_argument("start_date", help="开始日期 (YYYY-MM-DD)")
    query_parser.add_argument("--end-date", default="now", help="结束日期 (默认: now)")
    query_parser.add_argument("--metrics", default="basic,roas", help="指标类型 (默认: basic,roas)")
    query_parser.add_argument("--format", default="json", choices=["json", "csv"], help="输出格式")
    
    # analyze命令
    analyze_parser = subparsers.add_parser("analyze", help="分析ROAS")
    analyze_parser.add_argument("campaign", help="Campaign名称")
    analyze_parser.add_argument("--start-date", help="开始日期")
    analyze_parser.add_argument("--end-date", default="now", help="结束日期")
    analyze_parser.add_argument("--time-window", default="7d", help="时间窗口")
    
    # compare命令
    compare_parser = subparsers.add_parser("compare", help="比较多个Campaign")
    compare_parser.add_argument("campaigns", nargs="+", help="Campaign名称列表")
    compare_parser.add_argument("start_date", help="开始日期")
    compare_parser.add_argument("--end-date", default="now", help="结束日期")
    
    # export命令
    export_parser = subparsers.add_parser("export", help="导出数据")
    export_parser.add_argument("campaign", help="Campaign名称")
    export_parser.add_argument("start_date", help="开始日期")
    export_parser.add_argument("--end-date", default="now", help="结束日期")
    export_parser.add_argument("--export-format", default="json", choices=["json", "csv", "excel"], help="导出格式")
    
    args = parser.parse_args()
    
    client = AxonReportingClient()
    
    try:
        if args.command == "query":
            # 解析指标
            metric_types = args.metrics.split(',')
            metrics = []
            for mt in metric_types:
                if mt in COMMON_METRICS:
                    metrics.extend(COMMON_METRICS[mt])
            
            result = client.query_campaign(
                campaign_name=args.campaign,
                start_date=args.start_date,
                end_date=args.end_date,
                metrics=metrics,
                format=args.format
            )
            
            if args.format == "json":
                print(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                print(result.get("data", ""))
                
        elif args.command == "analyze":
            result = client.analyze_roas(
                campaign_name=args.campaign,
                time_window=args.time_window,
                start_date=args.start_date,
                end_date=args.end_date
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            
        elif args.command == "compare":
            result = client.compare_campaigns(
                campaigns=args.campaigns,
                start_date=args.start_date,
                end_date=args.end_date
            )
            print(json.dumps(result, ensure_ascii=False, indent=2))
            
        elif args.command == "export":
            data = client.query_campaign(
                campaign_name=args.campaign,
                start_date=args.start_date,
                end_date=args.end_date
            )
            
            filename = client.export_data(data, format=args.export_format)
            print(f"数据已导出到: {filename}")
            
        else:
            parser.print_help()
            
    except AxonAPIError as e:
        print(f"错误: {e}")
        exit(1)