#!/usr/bin/env python3
"""
查询 grip 产品近7日投放数据（Realtime 口径）

使用 Realtime 口径查询，避免 Cohort 数据为空的问题
"""

import os
import sys
from datetime import datetime, timedelta

# 添加 scripts 目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 使用独立版本的客户端
try:
    from axon_reporting_standalone import AxonReportingClient
except ImportError:
    print("错误：无法导入 axon_reporting_standalone 模块")
    sys.exit(1)
from axon_onebyone_runner import save_to_cache

def query_grip_realtime():
    """
    查询 grip 产品近7日数据（Realtime 口径）
    """
    # 初始化客户端
    client = AxonReportingClient()
    
    # 计算时间范围（T-7 到 T-1）
    end_date = datetime.now()
    start_date = end_date - timedelta(days=7)
    
    start_str = start_date.strftime("%Y-%m-%d")
    end_str = end_date.strftime("%Y-%m-%d")
    
    print(f"📅 查询时间范围: {start_str} 到 {end_str}")
    print(f"📊 查询口径: Realtime（实时数据）")
    print(f"🔍 筛选条件: Campaign 名称包含 'grip'（不区分大小写）\n")
    
    # 查询数据（使用 Realtime 口径）
    data = client.query(
        start=start_str,
        end=end_str,
        campaign_like="grip",  # 模糊查询，不区分大小写
        use_cohort=False,      # 使用 Realtime 口径
        metrics=None           # 使用默认指标（所有列）
    )
    
    # 检查结果
    if "data" in data and data["data"]:
        print(f"✅ 查询成功，共 {len(data['data'])} 条记录\n")
        
        # 显示前5条记录
        print("📋 数据预览（前5条）：")
        for i, row in enumerate(data["data"][:5], 1):
            print(f"  {i}. {row.get('day')} | {row.get('campaign', 'N/A')[:50]} | Cost: {row.get('cost', 0)} | ROAS 7D: {row.get('roas_7d', 0)}")
        
        if len(data["data"]) > 5:
            print(f"  ... 还有 {len(data['data']) - 5} 条记录")
        
        # 保存到 CSV
        filepath = save_to_cache(data)
        print(f"\n✅ 数据已保存到: {filepath}")
        
        # 计算汇总数据
        total_cost = sum(float(row.get('cost', 0)) for row in data["data"])
        print(f"\n💰 7日总消耗: ${total_cost:,.2f}")
        
        return data
    else:
        print("❌ 查询结果为空")
        print("可能原因：")
        print("  1. 近7日无花费")
        print("  2. Campaign 名称中不包含 'grip' 关键词")
        print("  3. API 认证失败")
        return None

if __name__ == "__main__":
    query_grip_realtime()
