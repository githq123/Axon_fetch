#!/usr/bin/env python3
"""
列出所有 Campaign，帮助找到正确的 Campaign 名称
"""

import os
import sys
from datetime import datetime, timedelta

# 添加 scripts 目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 使用独立版本的客户端
try:
    from axon_reporting_standalone import AxonReportingClient
except ImportError:
    print("错误：无法导入 axon_reporting_standalone 模块")
    sys.exit(1)

def list_all_campaigns():
    """
    查询所有 Campaign（Realtime 口径）
    """
    # 初始化客户端
    client = AxonReportingClient()
    
    # 计算时间范围（T-7 到 T-1）
    end_date = datetime.now()
    start_date = end_date - timedelta(days=7)
    
    start_str = start_date.strftime("%Y-%m-%d")
    end_str = end_date.strftime("%Y-%m-%d")
    
    print(f"📅 查询时间范围: {start_str} 到 {end_str}")
    print(f"📊 查询口径: Realtime（实时数据）\n")
    
    # 查询所有数据（不设置任何筛选条件）
    data = client.query(
        start=start_str,
        end=end_str,
        use_cohort=False  # 使用 Realtime 口径
    )
    
    # 检查结果
    if "data" in data and data["data"]:
        print(f"✅ 查询成功，共 {len(data['data'])} 条记录\n")
        
        # 提取所有 Campaign 名称（去重）
        campaigns = set()
        for row in data["data"]:
            campaign = row.get('campaign', 'N/A')
            campaigns.add(campaign)
        
        print(f"📋 找到 {len(campaigns)} 个不同的 Campaign：\n")
        
        # 按字母顺序排序并显示
        for i, campaign in enumerate(sorted(campaigns), 1):
            cost = sum(float(row.get('cost', 0)) for row in data["data"] if row.get('campaign') == campaign)
            print(f"  {i}. {campaign}")
            print(f"     7日总消耗: ${cost:,.2f}\n")
        
        # 筛选包含 "grip" 的 Campaign
        grip_campaigns = [c for c in campaigns if 'grip' in c.lower()]
        if grip_campaigns:
            print(f"\n🔍 包含 'grip' 关键词的 Campaign ({len(grip_campaigns)} 个)：")
            for i, campaign in enumerate(grip_campaigns, 1):
                cost = sum(float(row.get('cost', 0)) for row in data["data"] if row.get('campaign') == campaign)
                print(f"  {i}. {campaign}")
                print(f"     7日总消耗: ${cost:,.2f}")
        else:
            print(f"\n⚠️  未找到包含 'grip' 关键词的 Campaign")
            print(f"   建议使用以下 Campaign 名称之一进行查询：")
        
        return data
    else:
        print("❌ 查询结果为空")
        print("可能原因：")
        print("  1. 近7日无花费")
        print("  2. API 认证失败")
        return None

if __name__ == "__main__":
    list_all_campaigns()
