#!/usr/bin/env python3
"""
Axon 基础数据存储脚本文件
用途：写入缓存 CSV

默认输出路径：~/.openclaw/workspace/exports/axon_monitor_cache.csv
"""

import csv
import os
from datetime import datetime
from typing import List, Dict, Any
import re


# 默认配置
DEFAULT_CACHE_DIR = os.path.expanduser("~/.openclaw/workspace/exports")
DEFAULT_CACHE_FILE = os.path.join(DEFAULT_CACHE_DIR, "axon_monitor_cache.csv")


def ensure_dir_exists(filepath: str) -> None:
    """
    确保目录存在，如果不存在则创建
    
    Args:
        filepath: 文件路径
    """
    directory = os.path.dirname(filepath)
    if directory and not os.path.exists(directory):
        os.makedirs(directory, exist_ok=True)
        print(f"✅ 创建目录: {directory}")


def save_to_cache(data: List[Dict], filename: str = DEFAULT_CACHE_FILE) -> str:
    """
    将查询数据保存到缓存 CSV 文件
    
    Args:
        data: 查询结果数据列表
        filename: 输出文件名，默认为 ~/.openclaw/workspace/exports/axon_monitor_cache.csv
    
    Returns:
        保存的文件路径
    """
    if not data:
        raise ValueError("数据为空，无法保存")
    
    # 展开路径中的 ~
    filepath = os.path.expanduser(filename)
    
    # 确保目录存在
    ensure_dir_exists(filepath)
    
    # 定义 CSV 列顺序
    fieldnames = [
        "dt",
        "campaign",
        "product_name",
        "country",
        "cost",
        "cpa",
        "roi1",
        "roi3",
        "roi7"
    ]
    
    # 转换并格式化数据
    formatted_data = []
    for row in data:
        formatted_row = {
            "dt": row.get("day", ""),
            "campaign": row.get("campaign", ""),
            "product_name": extract_product_name(row.get("campaign", "")),
            "country": row.get("country", ""),
            "cost": row.get("cost", 0),
            "cpa": calculate_cpa(row),
            "roi1": format_roi(row.get("roas_1d")),
            "roi3": format_roi(row.get("roas_3d")),
            "roi7": format_roi(row.get("roas_7d"))
        }
        formatted_data.append(formatted_row)
    
    # 写入 CSV 文件
    with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(formatted_data)
    
    print(f"✅ 数据已保存到: {filepath}")
    print(f"✅ 共保存 {len(formatted_data)} 条记录")
    
    return filepath


def extract_product_name(campaign_name: str) -> str:
    """
    从 Campaign 名称中提取产品名称
    
    Args:
        campaign_name: Campaign 名称
    
    Returns:
        产品名称
    """
    if not campaign_name:
        return ""
    
    # Campaign 命名格式通常为：AppName_Platform_Network_Target_Optimization_Date
    # 产品名称通常是第一部分
    parts = campaign_name.split('_')
    if parts:
        return parts[0]
    return campaign_name


def calculate_cpa(row: Dict) -> float:
    """
    计算 CPA (Cost Per Acquisition)
    
    Args:
        row: 数据行
    
    Returns:
        CPA 值，如果无法计算则返回 0
    """
    try:
        cost = float(row.get("cost", 0))
        conversions = float(row.get("conversions", 0))
        
        if conversions > 0:
            return round(cost / conversions, 2)
        return 0.0
    except (ValueError, TypeError):
        return 0.0


def format_roi(roas_value: Any) -> float:
    """
    格式化 ROAS 值，将百分比转换为小数
    
    Args:
        roas_value: ROAS 值（可能是百分比或小数）
    
    Returns:
        格式化后的 ROI 小数值
    """
    if roas_value is None:
        return 0.0
    
    try:
        roas = float(roas_value)
        
        # 如果 ROAS > 10，可能是百分比形式（如 50% -> 50）
        # 转换为小数：50 -> 0.50
        if roas > 10:
            return round(roas / 100, 2)
        
        # 否则已经是小数形式，直接返回
        return round(roas, 2)
    
    except (ValueError, TypeError):
        return 0.0


def save_with_filters(data: List[Dict], filename: str = DEFAULT_CACHE_FILE, 
                     filters: Dict = None) -> str:
    """
    带筛选条件保存数据
    
    Args:
        data: 查询结果数据列表
        filename: 输出文件名
        filters: 筛选条件，如 {"campaign": "*grip*"}
    
    Returns:
        保存的文件路径
    """
    if filters:
        # 应用筛选条件
        filtered_data = []
        for row in data:
            match = True
            for key, value in filters.items():
                row_value = row.get(key, "")
                if isinstance(value, str) and "*" in value:
                    # 通配符匹配
                    pattern = value.replace("*", ".*").replace("?", ".")
                    if not re.search(pattern, str(row_value), re.IGNORECASE):
                        match = False
                        break
                elif isinstance(value, str):
                    # 包含匹配（不区分大小写）
                    if value.lower() not in str(row_value).lower():
                        match = False
                        break
                elif value != row_value:
                    match = False
                    break
            if match:
                filtered_data.append(row)
        data = filtered_data
    
    return save_to_cache(data, filename)


def get_cache_filepath() -> str:
    """
    获取缓存文件路径
    
    Returns:
        缓存文件的完整路径
    """
    return DEFAULT_CACHE_FILE


def append_to_cache(data: List[Dict], filename: str = DEFAULT_CACHE_FILE) -> str:
    """
    追加数据到缓存文件（如果文件存在则追加，否则创建新文件）
    
    Args:
        data: 查询结果数据列表
        filename: 输出文件名
    
    Returns:
        保存的文件路径
    """
    if not data:
        raise ValueError("数据为空，无法保存")
    
    # 展开路径中的 ~
    filepath = os.path.expanduser(filename)
    
    # 确保目录存在
    ensure_dir_exists(filepath)
    
    # 定义 CSV 列顺序
    fieldnames = [
        "dt",
        "campaign",
        "product_name",
        "country",
        "cost",
        "cpa",
        "roi1",
        "roi3",
        "roi7"
    ]
    
    # 转换并格式化数据
    formatted_data = []
    for row in data:
        formatted_row = {
            "dt": row.get("day", ""),
            "campaign": row.get("campaign", ""),
            "product_name": extract_product_name(row.get("campaign", "")),
            "country": row.get("country", ""),
            "cost": row.get("cost", 0),
            "cpa": calculate_cpa(row),
            "roi1": format_roi(row.get("roas_1d")),
            "roi3": format_roi(row.get("roas_3d")),
            "roi7": format_roi(row.get("roas_7d"))
        }
        formatted_data.append(formatted_row)
    
    # 判断文件是否存在
    file_exists = os.path.exists(filepath)
    
    # 写入或追加 CSV 文件
    mode = 'a' if file_exists else 'w'
    with open(filepath, mode, newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        # 如果是新文件，写入表头
        if not file_exists:
            writer.writeheader()
        
        # 写入数据
        writer.writerows(formatted_data)
    
    action = "追加" if file_exists else "创建"
    print(f"✅ 数据已{action}到: {filepath}")
    print(f"✅ 共保存 {len(formatted_data)} 条记录")
    
    return filepath


# 使用示例
if __name__ == "__main__":
    # 示例数据（实际使用时从 AxonReportingClient 获取）
    sample_data = [
        {
            "day": "2026-03-09",
            "campaign": "InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203",
            "country": "US",
            "cost": 1000.50,
            "conversions": 100,
            "roas_1d": 15.5,
            "roas_3d": 35.2,
            "roas_7d": 65.8
        },
        {
            "day": "2026-03-08",
            "campaign": "InHisGrip_AL_IOS_D28IAP_ROAS_CPP_20260203",
            "country": "US",
            "cost": 950.25,
            "conversions": 95,
            "roas_1d": 18.3,
            "roas_3d": 40.1,
            "roas_7d": 75.5
        },
        {
            "day": "2026-03-09",
            "campaign": "HeyBeauty_AL_AND_D7Ad_ROAS_20260215",
            "country": "GB",
            "cost": 2500.75,
            "conversions": 250,
            "roas_1d": 20.3,
            "roas_3d": 45.1,
            "roas_7d": 80.5
        }
    ]
    
    print("=" * 60)
    print("Axon 基础数据存储脚本")
    print("=" * 60)
    print()
    
    # 保存所有数据到缓存文件
    print("1. 保存所有数据到缓存文件")
    save_to_cache(sample_data)
    print()
    
    # 保存特定产品数据
    print("2. 保存 grip 产品数据")
    save_with_filters(sample_data, filters={"campaign": "*grip*"})
    print()
    
    # 追加数据到缓存文件
    print("3. 追加数据到缓存文件")
    append_to_cache(sample_data)
    print()
    
    print("=" * 60)
    print("✅ 所有操作完成")
    print(f"✅ 缓存文件位置: {get_cache_filepath()}")
    print("=" * 60)
