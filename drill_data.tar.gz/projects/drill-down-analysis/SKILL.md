---
name: drill-down-analysis
description: 提供多维度层级下钻分析能力，支持数据切片、聚合与趋势洞察；当用户需要深入分析数据、探索异常原因、按维度细分指标或进行层级数据探索时使用
dependency:
  python:
    - pandas>=2.0.0
    - sqlalchemy>=2.0.0
  system: []
---

# 下钻分析 Skill

## 任务目标
- 本 Skill 用于：对数据进行多维度层级下钻分析，发现数据背后的深层原因
- 能力包含：多维度聚合、层级数据探索、异常定位、趋势分析
- 触发条件：用户需要深入分析数据、探索异常原因、按维度细分指标或进行层级数据探索

## 前置准备
- 依赖说明：
  ```
  pandas>=2.0.0
  ```

## 操作步骤

### 1. 理解分析需求
- 明确分析目标：异常探索、趋势分析、细分对比、根因定位
- 识别核心指标：需要重点关注的 KPI 或度量值
- 确定分析范围：时间范围、业务范围、数据范围

### 2. 评估数据准备情况

#### 2.1 可用数据源（非日报场景优先使用）
对于投放数据相关下钻分析，优先使用以下已有数据源，无需重新拉数据：

**内部基础数据（SQLite）**：
- 路径：`~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite`
- 用途：缓存投放基础数据（近4个月），供监控、对比与下钻分析复用
- 可用维度：dt, app_name, media_source, campaign_name, deep_conversion_type, country, country_tier, video_url, img_url, cover_url, h5_url
- 可用指标：act_count, 现金消耗, CPA, 2留, 3留, 7留, 4留, 14留, 30留, 1日ROI, 2日ROI, 3日ROI, 4日ROI, 7日ROI, 14日ROI, 30日ROI, 1日LTV_总, 3日LTV_总, 4日LTV_总, 7日LTV_总, 14日LTV_总, 30日LTV_总, 付费率_1日, 付费率_3日, 付费率_7日, 付费率_14日, 付费率_30日, 累计客单价_1日, 累计客单价_3日, 累计客单价_7日, 累计客单价_14日, 1日付费用户成本, 3日付费用户成本, 7日付费用户成本, 14日付费用户成本, 30日付费用户成本

**ROI 预测数据（SQLite）**：
- 路径：`~/.openclaw/workspace/data_analysis/roi_predict/data/roi_predict_campaign_distribute_roi1_180_last4m.sqlite`
- 用途：存储 ROI 预测与分布相关聚合数据（近4个月）
- 可用维度：ts, campaign, app_name
- 可用指标：spend, roi1_agg-roi180_agg, actual_roi1_agg-actual_roi180_agg

**Axon 基础数据（CSV）**：
- 路径：`~/.openclaw/workspace/exports/axon_monitor_cache.csv`
- 可用维度：产品, 日期, Campaign, 国家
- 可用指标：消耗, 转化数, ROI1, ROI3, ROI7

**Axon ROI 预测数据（CSV）**：
- 路径：`~/.openclaw/workspace/exports/axon_roi_predict.csv`
- 可用维度：产品, 日期, Campaign, 消耗
- 可用指标：roi1, roi3, roi7, roi14_predict, roi30_predict, roi45_predict, roi60_predict, roi120_predict, roi180_predict

#### 2.2 自定义数据准备
如果需要使用自定义数据：
- 检查输入数据格式是否符合规范
  - 参考文档：[references/data-format-guide.md](references/data-format-guide.md)
- 使用模板：[assets/data-template.csv](assets/data-template.csv)
- 确保数据包含时间维度、分类维度和度量指标

### 3. 设计下钻策略
- 根据业务场景选择下钻维度模式
  - 参考文档：[references/dimension-patterns.md](references/dimension-patterns.md)
  - 常见模式：时间下钻、地理下钻、组织下钻、产品下钻
- 规划下钻层级：从总体到细分的层级关系
- 确定聚合方式：求和、计数、平均值、最大值、最小值

### 4. 执行下钻分析

#### 4.1 使用现有数据源（推荐）
对于投放数据相关分析，直接从 SQLite 或 CSV 文件读取数据：

**SQLite 数据源示例**：
```bash
# 先导出数据为 CSV
sqlite3 ~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite \
  "SELECT dt, app_name, media_source, country, act_count, 现金消耗, ROI1, ROI7 FROM 表名 WHERE dt >= '2024-01-01' LIMIT 10000" \
  > ./data.csv

# 然后执行下钻分析
python /workspace/projects/drill-down-analysis/scripts/drill_analyzer.py \
  --input ./data.csv \
  --output ./result.csv \
  --dimensions app_name,media_source,country \
  --metrics act_count,现金消耗,ROI1 \
  --agg sum
```

**CSV 数据源示例**：
```bash
# 直接使用 Axon 缓存数据
python /workspace/projects/drill-down-analysis/scripts/drill_analyzer.py \
  --input ~/.openclaw/workspace/exports/axon_monitor_cache.csv \
  --output ./result.csv \
  --dimensions 产品,Campaign,国家 \
  --metrics 消耗,转化数,ROI1,ROI7 \
  --agg sum
```

#### 4.2 使用自定义数据源
```bash
python /workspace/projects/drill-down-analysis/scripts/drill_analyzer.py \
  --input ./data.csv \
  --output ./result.csv \
  --dimensions [维度列表] \
  --metrics [指标列表] \
  --agg [聚合方式]
```
- 参数说明：
  - `--input`：输入数据文件路径（绝对路径或相对路径）
  - `--output`：输出结果文件路径（相对路径）
  - `--dimensions`：聚合维度，多个维度用逗号分隔（如：year,month,region）
  - `--metrics`：度量指标，多个指标用逗号分隔（如：sales,quantity）
  - `--agg`：聚合方式，支持 sum/count/mean/max/min（默认：sum）

### 5. 解读分析结果
- 分析各层级的数据变化趋势
- 识别异常点或关键转折点
- 对比不同维度的表现差异
- 挖掘数据背后的业务原因

### 6. 输出分析报告
- **数据展示**：以结构化方式展示关键指标、趋势图表、对比表格
  - 参考：[references/output-format-guide.md](references/output-format-guide.md)
- **结论总结**：基于数据分析得出的核心发现和洞察（3-5个）
- **行动建议**：针对结论提出的具体业务建议和行动方案（3-5条）
- **数据来源标注**：标注分析的时间范围、数据来源、覆盖范围

## 资源索引
- 核心脚本：[scripts/drill_analyzer.py](scripts/drill_analyzer.py)（用途：多维度数据聚合与层级计算）
- 维度模式参考：[references/dimension-patterns.md](references/dimension-patterns.md)（何时读取：设计下钻策略时）
- 数据格式指南：[references/data-format-guide.md](references/data-format-guide.md)（何时读取：准备或验证输入数据时）
- 输出格式指南：[references/output-format-guide.md](references/output-format-guide.md)（何时读取：输出分析结果时）
- 数据模板：[assets/data-template.csv](assets/data-template.csv)（用途：提供标准数据结构示例）

## 使用示例

### 示例1：投放数据媒体源下钻分析
**场景**：分析不同媒体源的投放表现，深入到国家维度

**执行方式**：
1. 智能体设计下钻策略：app_name → media_source → country
2. 从 SQLite 导出数据：
   ```bash
   sqlite3 ~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite \
     "SELECT dt, app_name, media_source, country, act_count, 现金消耗, ROI1, ROI7, CPA FROM activate_performance WHERE dt >= '2024-01-01'" \
     > ./投放数据.csv
   ```
3. 调用脚本执行聚合：
   ```bash
   python /workspace/projects/drill-down-analysis/scripts/drill_analyzer.py \
     --input ./投放数据.csv \
     --output ./media_source_drill.csv \
     --dimensions app_name,media_source,country \
     --metrics act_count,现金消耗,ROI1,ROI7,CPA \
     --agg sum
   ```
4. 智能体解读结果，识别高 ROI 媒体源和国家组合

### 示例2：ROI 预测下钻分析
**场景**：对比不同 Campaign 的实际 ROI 与预测 ROI，分析预测准确性

**执行方式**：
1. 智能体设计下钻策略：app_name → campaign
2. 从 SQLite 导出数据：
   ```bash
   sqlite3 ~/.openclaw/workspace/data_analysis/roi_predict/data/roi_predict_campaign_distribute_roi1_180_last4m.sqlite \
     "SELECT ts, campaign, app_name, spend, roi1_agg, roi7_agg, roi30_agg, actual_roi1_agg, actual_roi7_agg, actual_roi30_agg FROM roi_predict" \
     > ./roi_predict.csv
   ```
3. 调用脚本执行聚合：
   ```bash
   python /workspace/projects/drill-down-analysis/scripts/drill_analyzer.py \
     --input ./roi_predict.csv \
     --output ./roi_drill.csv \
     --dimensions app_name,campaign \
     --metrics roi1_agg,roi7_agg,actual_roi1_agg,actual_roi7_agg \
     --agg mean
   ```
4. 智能体对比预测值与实际值，分析预测偏差

### 示例3：Axon 数据多维度交叉分析
**场景**：分析 Axon 平台不同产品的国家表现，结合 ROI 预测数据

**执行方式**：
1. 智能体设计下钻策略：产品 → 国家
2. 直接使用 Axon 缓存数据：
   ```bash
   python /workspace/projects/drill-down-analysis/scripts/drill_analyzer.py \
     --input ~/.openclaw/workspace/exports/axon_monitor_cache.csv \
     --output ./axon_drill.csv \
     --dimensions 产品,国家 \
     --metrics 消耗,转化数,ROI1,ROI3,ROI7 \
     --agg sum
   ```
3. 结合 ROI 预测数据：
   ```bash
   python /workspace/projects/drill-down-analysis/scripts/drill_analyzer.py \
     --input ~/.openclaw/workspace/exports/axon_roi_predict.csv \
     --output ./axon_roi_drill.csv \
     --dimensions 产品,Campaign \
     --metrics roi1,roi7,roi14_predict,roi30_predict \
     --agg mean
   ```
4. 智能体综合两个数据源，提供投放策略建议

## 注意事项

### 数据获取规范
- **明确日期区间**：必须根据分析需求明确指定日期范围（如：近7天、近30天、2024-01-01 至 2024-03-01），从已有数据表中提取对应时间范围的数据
- **投放类型识别**：deep_conversion_type 包含 D28Ad、D7Ad、D7IAP、D28IAP 等类型，通过 campaign 名称模糊匹配即可识别投放类型
- **数据源选择**：投放数据相关分析优先使用已有数据源（SQLite/CSV），无需重新拉数据
- **数据时效性**：内部基础数据和 ROI 预测数据包含近4个月数据，分析时注意时间范围

### 数据聚合规范
- **多维度 group by**：拆分视角分析时，支持多维度组合（如：投放类型 + 产品名称 + 国家等）进行 group by
- **ROI 指标加权聚合**：计算 ROI 等比率指标时，必须使用加权平均（以消耗或转化数为权重），不能简单算术平均
- **CPA 指标聚合**：CPA 的聚合需要使用总消耗 / 总激活数，不能直接平均
- **留存率聚合**：留存率的聚合同样需要加权处理

### 输出规范
- **卡片形式展示**：分析结果以结构化卡片形式发送，包含以下模块：
  1. **数据展示**：关键指标数据、趋势图表、对比表格
  2. **结论**：基于数据分析得出的核心发现和洞察
  3. **建议**：针对结论提出的具体业务建议和行动方案

### 分析质量要求
- 下钻层级不宜过深，建议控制在 3-5 层
- 每个下钻层级应具备业务意义，避免无意义的细分
- 分析结果需结合业务背景解读，避免数据误导
- 当数据量较大时，建议先抽样或分批处理
- 仅在需要时读取参考文档，保持上下文简洁
- 数据处理部分优先使用脚本，结果解读由智能体完成
