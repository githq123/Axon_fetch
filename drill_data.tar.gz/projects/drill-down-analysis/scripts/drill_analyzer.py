#!/usr/bin/env python3
"""
下钻分析数据处理器
支持多维度聚合计算和层级数据切片
"""

import argparse
import sys
from pathlib import Path

try:
    import pandas as pd
except ImportError:
    print("错误: 需要安装 pandas 依赖库")
    print("请运行: pip install pandas>=2.0.0")
    sys.exit(1)


def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='下钻分析数据处理器')
    parser.add_argument('--input', required=True, help='输入数据文件路径 (CSV/Excel)')
    parser.add_argument('--output', required=True, help='输出结果文件路径 (CSV)')
    parser.add_argument('--dimensions', required=True, help='聚合维度，多个维度用逗号分隔 (如: year,month,region)')
    parser.add_argument('--metrics', required=True, help='度量指标，多个指标用逗号分隔 (如: sales,quantity)')
    parser.add_argument('--agg', default='sum', 
                       choices=['sum', 'count', 'mean', 'max', 'min'],
                       help='聚合方式 (默认: sum)')
    return parser.parse_args()


def load_data(input_path: str) -> pd.DataFrame:
    """
    加载输入数据文件
    
    参数:
        input_path: 输入文件路径
        
    返回:
        DataFrame对象
    """
    path = Path(input_path)
    
    if not path.exists():
        raise FileNotFoundError(f"输入文件不存在: {input_path}")
    
    # 根据文件扩展名选择加载方式
    suffix = path.suffix.lower()
    if suffix == '.csv':
        df = pd.read_csv(input_path)
    elif suffix in ['.xlsx', '.xls']:
        df = pd.read_excel(input_path)
    else:
        raise ValueError(f"不支持的文件格式: {suffix}，仅支持 CSV 和 Excel 文件")
    
    return df


def validate_data(df: pd.DataFrame, dimensions: list, metrics: list) -> None:
    """
    验证数据完整性
    
    参数:
        df: 数据DataFrame
        dimensions: 维度列表
        metrics: 指标列表
        
    异常:
        ValueError: 当数据验证失败时抛出
    """
    # 检查必需的维度列是否存在
    missing_dims = [d for d in dimensions if d not in df.columns]
    if missing_dims:
        raise ValueError(f"数据中缺少维度列: {missing_dims}")
    
    # 检查必需的指标列是否存在
    missing_metrics = [m for m in metrics if m not in df.columns]
    if missing_metrics:
        raise ValueError(f"数据中缺少指标列: {missing_metrics}")
    
    # 检查指标列是否为数值类型
    for metric in metrics:
        if not pd.api.types.is_numeric_dtype(df[metric]):
            try:
                df[metric] = pd.to_numeric(df[metric], errors='raise')
            except ValueError:
                raise ValueError(f"指标列 '{metric}' 无法转换为数值类型")


def drill_down_analysis(
    df: pd.DataFrame, 
    dimensions: list, 
    metrics: list, 
    agg_func: str
) -> pd.DataFrame:
    """
    执行下钻聚合分析
    
    参数:
        df: 原始数据
        dimensions: 聚合维度列表
        metrics: 度量指标列表
        agg_func: 聚合函数 (sum/count/mean/max/min)
        
    返回:
        聚合后的DataFrame
    """
    # 构建聚合字典
    agg_dict = {}
    for metric in metrics:
        if agg_func == 'count':
            agg_dict[metric] = 'count'
        else:
            agg_dict[metric] = agg_func
    
    # 执行分组聚合
    try:
        result = df.groupby(dimensions, dropna=False).agg(agg_dict).reset_index()
    except Exception as e:
        raise RuntimeError(f"聚合计算失败: {str(e)}")
    
    # 处理多级列名（当有多个指标时）
    if len(metrics) > 1:
        # 只处理指标列的列名，维度列保持原样
        new_columns = []
        for col in result.columns.values:
            if isinstance(col, tuple):
                # 如果是多级列名
                if col[0] in dimensions:
                    # 维度列，只取第一层
                    new_columns.append(col[0])
                elif col[1] == agg_func:
                    # 指标列，如果聚合方式匹配，只取指标名
                    new_columns.append(col[0])
                else:
                    # 其他情况，组合列名
                    new_columns.append(f"{col[0]}_{col[1]}")
            else:
                # 单级列名，保持不变
                new_columns.append(col)
        result.columns = new_columns
    else:
        # 单指标情况，扁平化列名
        if isinstance(result.columns, pd.MultiIndex):
            result.columns = [col[0] if col[0] in dimensions else f"{col[0]}_{col[1]}" 
                             for col in result.columns.values]
    
    # 按维度排序
    result = result.sort_values(by=dimensions, na_position='first')
    
    return result


def save_result(df: pd.DataFrame, output_path: str) -> None:
    """
    保存分析结果
    
    参数:
        df: 结果DataFrame
        output_path: 输出文件路径
    """
    path = Path(output_path)
    
    # 确保输出目录存在
    path.parent.mkdir(parents=True, exist_ok=True)
    
    # 保存为CSV格式
    df.to_csv(output_path, index=False, encoding='utf-8-sig')
    print(f"结果已保存到: {output_path}")


def main():
    """主函数"""
    try:
        # 解析参数
        args = parse_args()
        
        # 加载数据
        print(f"正在加载数据: {args.input}")
        df = load_data(args.input)
        print(f"数据加载成功，共 {len(df)} 行，{len(df.columns)} 列")
        
        # 解析维度和指标
        dimensions = [d.strip() for d in args.dimensions.split(',')]
        metrics = [m.strip() for m in args.metrics.split(',')]
        
        print(f"聚合维度: {dimensions}")
        print(f"度量指标: {metrics}")
        print(f"聚合方式: {args.agg}")
        
        # 验证数据
        print("正在验证数据...")
        validate_data(df, dimensions, metrics)
        print("数据验证通过")
        
        # 执行下钻分析
        print("正在执行下钻聚合...")
        result = drill_down_analysis(df, dimensions, metrics, args.agg)
        print(f"聚合完成，生成 {len(result)} 个维度组合")
        
        # 保存结果
        save_result(result, args.output)
        
        # 输出结果摘要
        print("\n=== 结果摘要 ===")
        print(result.head(10).to_string(index=False))
        if len(result) > 10:
            print(f"\n... 还有 {len(result) - 10} 行数据")
        
        print("\n分析完成！")
        
    except Exception as e:
        print(f"错误: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
