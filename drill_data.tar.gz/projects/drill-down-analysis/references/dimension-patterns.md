# 常见下钻维度模式

## 目录
1. 时间维度下钻
2. 地理维度下钻
3. 组织维度下钻
4. 产品维度下钻
5. 客户维度下钻
6. 渠道维度下钻
7. 投放数据专用维度

## 概览
本文档提供了6种常用的下钻维度模式，涵盖业务分析中的常见场景。每种模式包含层级结构、应用场景和使用建议。

## 核心内容

### 1. 时间维度下钻

**层级结构**：
- 年 → 季度 → 月 → 周 → 日
- 年 → 季度 → 月 → 日 → 小时（适用于高粒度数据）

**应用场景**：
- 销售趋势分析
- 流量波动分析
- 业务周期性分析
- 季节性因素识别

**数据字段要求**：
```csv
date,year,quarter,month,week,day
2024-01-15,2024,Q1,January,W3,15
```

**使用建议**：
- 从高层级开始（年、季度），逐步下钻到细节
- 注意节假日、促销活动等特殊时间点
- 对比同环比时需考虑季节因素

### 2. 地理维度下钻

**层级结构**：
- 国家/地区 → 大区 → 省/州 → 城市 → 区域 → 门店
- 中国标准：全国 → 大区（华东/华南/华北等） → 省 → 城市 → 区县 → 门店

**应用场景**：
- 区域销售对比分析
- 市场渗透率分析
- 地域化策略制定
- 区域异常排查

**数据字段要求**：
```csv
region,province,city,district,store_id
华东,浙江,杭州,西湖区,S001
```

**使用建议**：
- 考虑地域经济发展水平差异
- 注意气候、文化等地域因素影响
- 新旧区域对比时需考虑发展成熟度

### 3. 组织维度下钻

**层级结构**：
- 公司 → 事业部 → 部门 → 团队 → 个人
- 公司 → 分公司 → 部门 → 小组 → 个人

**应用场景**：
- 团队绩效分析
- 人力资源效率分析
- 组织效能评估
- 跨部门协作分析

**数据字段要求**：
```csv
company,division,department,team,employee_id
ABC公司,销售事业部,华东销售部,杭州团队,E001
```

**使用建议**：
- 考虑团队规模差异（人均指标更公平）
- 注意组织架构调整对数据的影响
- 关注团队协作和跨部门因素

### 4. 产品维度下钻

**层级结构**：
- 产品线 → 产品类 → 产品子类 → SKU
- 品牌 → 产品线 → 系列 → 型号

**应用场景**：
- 产品结构分析
- 销售占比分析
- 产品生命周期分析
- 库存周转分析

**数据字段要求**：
```csv
brand,product_line,category,subcategory,sku
品牌A,电子产品,手机,智能手机,P001
```

**使用建议**：
- 区分核心产品和长尾产品
- 关注新老产品替换周期
- 考虑季节性产品特性

### 5. 客户维度下钻

**层级结构**：
- 客户类型 → 细分群体 → 客户标签 → 具体客户
- 客户等级 → 行业 → 地域 → 具体客户

**应用场景**：
- 客户价值分析（RFM模型）
- 客户留存分析
- 获客成本分析
- 客户生命周期分析

**数据字段要求**：
```csv
customer_type,segment,tier,industry,customer_id
企业客户,大客户,VIP,制造业,C001
```

**使用建议**：
- 结合客户分层策略分析
- 关注新老客户表现差异
- 考虑客户生命周期阶段

### 6. 渠道维度下钻

**层级结构**：
- 渠道类型 → 渠道子类 → 具体渠道 → 门店/账号
- 线上/线下 → 渠道平台 → 店铺/直播间

**应用场景**：
- 渠道效果对比
- 渠道成本分析
- 转化率分析
- 渠道优化决策

**数据字段要求**：
```csv
channel_type,channel_category,platform,store_id
线上,电商平台,天猫,T001
线下,实体店,华东区,S001
```

**使用建议**：
- 区分自营和第三方渠道
- 关注渠道成本和转化率差异
- 考虑渠道间的协同效应

## 多维度交叉下钻

**交叉模式示例**：

1. **时间 + 地理**：
   - 分析不同区域的季节性趋势
   - 维度：year,month,region,province

2. **产品 + 渠道**：
   - 分析不同渠道的产品表现
   - 维度：product_line,channel_type,platform

3. **客户 + 产品**：
   - 分析不同客户群体的产品偏好
   - 维度：customer_tier,product_category

4. **时间 + 产品 + 地理**：
   - 三维交叉分析，发现复杂业务洞察
   - 维度：year,month,product_line,region

**使用建议**：
- 交叉维度不宜超过3个，避免结果过于碎片化
- 确保每个维度都有业务意义和解释力
- 优先选择相互独立的维度进行交叉

## 示例

### 示例1：销售数据多层级下钻
```bash
# 三层时间下钻
python drill_analyzer.py \
  --input sales.csv \
  --output result.csv \
  --dimensions year,quarter,month \
  --metrics sales_amount \
  --agg sum

# 时间 + 地理交叉下钻
python drill_analyzer.py \
  --input sales.csv \
  --output result.csv \
  --dimensions year,region,province,city \
  --metrics sales_amount,order_count \
  --agg sum
```

### 示例2：客户价值分析下钻
```bash
# 客户分层 + 产品类下钻
python drill_analyzer.py \
  --input customer_data.csv \
  --output result.csv \
  --dimensions customer_tier,product_category \
  --metrics purchase_amount,order_count \
  --agg sum
```

### 示例3：渠道效果多维分析
```bash
# 时间 + 渠道类型 + 产品线交叉
python drill_analyzer.py \
  --input channel_data.csv \
  --output result.csv \
  --dimensions month,channel_type,product_line \
  --metrics gmv,profit,conversion_rate \
  --agg mean
```

### 7. 投放数据专用维度

**层级结构（基于内部数据表）**：
- 应用维度：app_name
- 媒体源维度：media_source → campaign_name
- 地理维度：country → country_tier
- 时间维度：dt（天）
- 深度转化：deep_conversion_type
- 创意维度：video_url, img_url, cover_url, h5_url（用于创意层面分析）

**应用场景**：
- 投放效果分析（激活数、消耗、ROI）
- 媒体源表现对比
- 国家层级投放优化
- ROI 预测准确性分析
- 深度转化漏斗分析

**数据字段要求（投放基础数据）**：
```csv
dt,app_name,media_source,campaign_name,deep_conversion_type,country,country_tier,video_url,img_url,cover_url,h5_url,act_count,现金消耗,CPA,2留,3留,7留,4留,14留,30留,1日ROI,2日ROI,3日ROI,4日ROI,7日ROI,14日ROI,30日ROI,1日LTV_总,3日LTV_总,4日LTV_总,7日LTV_总,14日LTV_总,30日LTV_总,付费率_1日,付费率_3日,付费率_7日,付费率_14日,付费率_30日,累计客单价_1日,累计客单价_3日,累计客单价_7日,累计客单价_14日,1日付费用户成本,3日付费用户成本,7日付费用户成本,14日付费用户成本,30日付费用户成本
2024-01-15,AppA,Facebook,Camp001,install,US,T1,http://...,http://...,http://...,http://...,1000,5000,5,0.4,0.35,0.3,0.25,0.15,0.08,1.2,1.3,1.4,1.5,1.8,2.2,2.8,10,25,30,35,45,50,0.08,0.12,0.15,0.18,0.20,50,60,70,80,100,125,150,175,200
```

**数据字段要求（ROI 预测数据）**：
```csv
ts,campaign,app_name,spend,roi1_agg,roi2_agg,roi3_agg,roi4_agg,roi7_agg,roi14_agg,roi30_agg,roi45_agg,roi60_agg,roi90_agg,roi180_agg,actual_roi1_agg,actual_roi2_agg,actual_roi3_agg,actual_roi4_agg,actual_roi7_agg,actual_roi14_agg,actual_roi30_agg,actual_roi45_agg,actual_roi60_agg,actual_roi90_agg,actual_roi180_agg
2024-01-15,Camp001,AppA,5000,1.2,1.3,1.4,1.5,1.8,2.2,2.8,3.2,3.5,3.8,4.2,1.15,1.25,1.35,1.45,1.75,2.15,2.65,3.05,3.35,3.65,4.05
```

**可用数据源**：
- 内部基础数据（SQLite）：`~/.openclaw/workspace/data_analysis/act_performance/data/activate_performance_creative_last4m.sqlite`
- ROI 预测数据（SQLite）：`~/.openclaw/workspace/data_analysis/roi_predict/data/roi_predict_campaign_distribute_roi1_180_last4m.sqlite`
- Axon 基础数据（CSV）：`~/.openclaw/workspace/exports/axon_monitor_cache.csv`
- Axon ROI 预测（CSV）：`~/.openclaw/workspace/exports/axon_roi_predict.csv`

**使用建议**：
- 优先使用已有数据源，无需重新拉数据
- 投放数据时间范围通常为近4个月
- 关注不同媒体源的 ROI 和 CPA 对比
- 分析国家层级的投放效率和 ROI 表现
- 对比 ROI 预测值与实际值，评估预测模型准确性
- 结合留存率、付费率等指标进行综合分析

**常见分析模式**：

1. **媒体源效率分析**：
   - 维度：app_name → media_source
   - 指标：act_count, 现金消耗, CPA, 1日ROI, 2日ROI, 3日ROI, 4日ROI, 7日ROI, 14日ROI, 30日ROI
   - 目的：识别高效媒体源，优化投放预算分配

2. **国家层级投放优化**：
   - 维度：app_name → country → country_tier
   - 指标：act_count, 现金消耗, CPA, 1日ROI, 7日ROI, 30日ROI, 付费率_1日, 付费率_7日, 付费率_30日
   - 目的：发现高 ROI 国家，调整投放策略

3. **Campaign 细粒度分析**：
   - 维度：app_name → media_source → campaign_name
   - 指标：act_count, 现金消耗, CPA, 1日ROI, 2日ROI, 7日ROI, 14日ROI, 30日ROI
   - 目的：Campaign 级别的效果监控和优化

4. **创意层面分析**：
   - 维度：app_name → media_source → campaign_name → video_url/img_url
   - 指标：act_count, 现金消耗, CPA, 1日ROI, 7日ROI
   - 目的：识别高效创意素材，优化创意制作策略

5. **ROI 预测对比分析**：
   - 维度：app_name → campaign
   - 指标：roi1_agg-roi180_agg, actual_roi1_agg-actual_roi180_agg
   - 目的：评估 ROI 预测准确性，优化预测模型

6. **留存与付费综合分析**：
   - 维度：app_name → media_source → country
   - 指标：2留, 3留, 4留, 7留, 14留, 30留, 付费率_1日, 付费率_3日, 付费率_7日, 付费率_14日, 付费率_30日
   - 目的：分析用户质量和付费转化能力

7. **LTV 价值分析**：
   - 维度：app_name → media_source → country
   - 指标：1日LTV_总, 3日LTV_总, 4日LTV_总, 7日LTV_总, 14日LTV_总, 30日LTV_总, 累计客单价_1日, 累计客单价_3日, 累计客单价_7日, 累计客单价_14日
   - 目的：分析用户长期价值和付费能力

8. **Axon 平台数据分析**：
   - 维度：产品 → Campaign → 国家
   - 指标：消耗, 转化数, ROI1, ROI3, ROI7
   - 目的：Axon 平台投放效果监控


- 下钻层级建议控制在3-5层，避免过度细分
- 确保每个层级的数据量足够，避免稀疏数据
- 选择聚合方式时需考虑指标特性（计数、求和、平均等）
- 注意NULL值处理，确保下钻逻辑完整
- 多维度交叉时注意数据量的指数级增长
