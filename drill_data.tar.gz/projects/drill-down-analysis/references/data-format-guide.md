# 数据格式规范

## 目录
1. 输入数据格式
2. 输出数据格式
3. 数据验证规则
4. 投放数据专用规范
5. 指标聚合计算规范
6. 常见问题与解决方案

## 概览
本文档定义了下钻分析 Skill 的输入输出数据格式规范，确保数据质量和分析准确性。

## 核心内容

### 1. 输入数据格式

#### 1.1 支持的文件类型
- **CSV文件**：推荐格式，编码为 UTF-8 或 UTF-8-SIG
- **Excel文件**：支持 .xlsx 和 .xls 格式

#### 1.2 数据结构要求

**必需列**：
- 至少包含1个维度列
- 至少包含1个指标列

**列名规范**：
- 使用英文列名，避免中文和特殊字符
- 列名不区分大小写
- 列名不应包含空格，建议使用下划线（如：order_amount）

#### 1.3 完整数据示例

**示例1：销售数据（CSV格式）**
```csv
date,year,quarter,month,region,province,city,product_category,sales_amount,order_count,profit
2024-01-15,2024,Q1,January,华东,浙江,杭州,电子产品,50000,120,8000
2024-01-16,2024,Q1,January,华东,浙江,宁波,电子产品,30000,80,5000
2024-01-17,2024,Q1,January,华南,广东,广州,服装,45000,200,9000
2024-01-18,2024,Q1,January,华南,广东,深圳,服装,55000,220,11000
```

**示例2：网站流量数据（CSV格式）**
```csv
date,year,month,day,channel,device_type,traffic_source,sessions,bounce_rate,conversion_rate
2024-01-15,2024,January,15,search,mobile,google,5000,0.45,0.03
2024-01-15,2024,January,15,social,mobile,facebook,3000,0.60,0.02
2024-01-16,2024,January,16,direct,desktop,direct,2000,0.35,0.05
```

#### 1.4 数据类型要求

**维度列**：
- 字符串类型（text）：如 region, product_category
- 数值类型（integer）：如 year, month
- 日期类型：如 date（会自动解析为字符串）

**指标列**：
- 数值类型（integer 或 float）：所有指标必须是数值类型
- 支持聚合操作：sum, count, mean, max, min

#### 1.5 数据质量要求

**必填字段**：
- 所有维度列和指标列不允许为空值
- 如果存在空值，建议在分析前进行数据清洗

**数据范围**：
- 数值指标应在合理范围内，避免异常值
- 日期字段应符合标准日期格式（YYYY-MM-DD）

**唯一性**：
- 同一组维度组合下可以有多行数据（会被聚合）
- 建议确保数据的完整性，避免重复或缺失

### 2. 输出数据格式

#### 2.1 文件格式
- 输出文件始终为 CSV 格式
- 编码为 UTF-8-SIG（支持 Excel 直接打开）

#### 2.2 输出结构

**列名**：
- 保留所有输入的维度列
- 指标列根据聚合方式命名：
  - 单指标：保持原列名
  - 多指标：列名格式为 `{指标名}_{聚合方式}`（如：sales_amount_sum）

**排序**：
- 默认按维度列的顺序排序
- 空值排在最前面

#### 2.3 输出示例

**输入**：
```csv
year,region,product,sales
2024,华东,手机,100000
2024,华东,电脑,80000
2024,华南,手机,90000
2024,华南,电脑,70000
```

**输出**（按 year,region 聚合，agg=sum）：
```csv
year,region,sales_sum
2024,华东,180000
2024,华南,160000
```

**输出**（按 year,product 聚合，多指标 avg 和 count）：
```csv
year,product,sales_avg,sales_count
2024,手机,95000,2
2024,电脑,75000,2
```

### 3. 数据验证规则

#### 3.1 必需列检查
```python
# 错误示例：缺少维度列
date,sales_amount
2024-01-15,50000
# 错误原因：没有维度列，无法进行分组聚合

# 正确示例
date,region,sales_amount
2024-01-15,华东,50000
```

#### 3.2 列类型检查
```python
# 错误示例：指标列不是数值类型
region,sales_amount
华东,50,000
# 错误原因：sales_amount 包含逗号，无法转换为数值

# 正确示例
region,sales_amount
华东,50000
```

#### 3.3 聚合方式兼容性
- **sum, min, max**：仅适用于数值类型
- **mean**：仅适用于数值类型
- **count**：适用于任何类型

#### 3.4 数据完整性验证
- 检查文件是否存在
- 检查文件格式是否正确（CSV/Excel）
- 检查是否为空文件
- 检查列名是否匹配

### 4. 投放数据专用规范

#### 4.1 日期区间选择
**规范要求**：
- 必须明确指定分析日期范围，不能使用"所有数据"
- 常用日期区间：近7天、近30天、指定日期范围（如：2024-01-01 至 2024-03-01）
- 数据源覆盖范围：内部基础数据和 ROI 预测数据包含近4个月数据

**SQL 示例**：
```sql
-- 近7天数据
SELECT * FROM activate_performance 
WHERE dt >= date('now', '-7 days')

-- 近30天数据
SELECT * FROM activate_performance 
WHERE dt >= date('now', '-30 days')

-- 指定日期范围
SELECT * FROM activate_performance 
WHERE dt >= '2024-01-01' AND dt <= '2024-03-01'
```

#### 4.2 投放类型识别
**投放类型定义**：
- `D28Ad`：28天广告投放
- `D7Ad`：7天广告投放
- `D7IAP`：7天内购投放
- `D28IAP`：28天内购投放

**识别方式**：
- 通过 `campaign_name` 字段模糊匹配
- Campaign 名称通常包含投放类型标识

**SQL 示例**：
```sql
-- 识别 D7Ad 类型投放
SELECT * FROM activate_performance 
WHERE campaign_name LIKE '%D7Ad%'

-- 识别所有广告投放类型
SELECT * FROM activate_performance 
WHERE campaign_name LIKE '%D7Ad%' 
   OR campaign_name LIKE '%D28Ad%'

-- 识别 IAP 类型投放
SELECT * FROM activate_performance 
WHERE campaign_name LIKE '%D7IAP%' 
   OR campaign_name LIKE '%D28IAP%'
```

**Python 代码示例**：
```python
import pandas as pd

# 通过 campaign_name 模糊匹配投放类型
df['投放类型'] = None
df.loc[df['campaign_name'].str.contains('D7Ad', case=False), '投放类型'] = 'D7Ad'
df.loc[df['campaign_name'].str.contains('D28Ad', case=False), '投放类型'] = 'D28Ad'
df.loc[df['campaign_name'].str.contains('D7IAP', case=False), '投放类型'] = 'D7IAP'
df.loc[df['campaign_name'].str.contains('D28IAP', case=False), '投放类型'] = 'D28IAP'
```

#### 4.3 多维度拆分分析
**支持的多维度组合**：
- 投放类型 + 产品名称
- 投放类型 + 国家
- 投放类型 + 产品名称 + 国家
- 投放类型 + 媒体源 + 国家
- 其他业务相关维度组合

**示例场景**：
```sql
-- 按投放类型和国家维度分析
SELECT 
    CASE 
        WHEN campaign_name LIKE '%D7Ad%' THEN 'D7Ad'
        WHEN campaign_name LIKE '%D28Ad%' THEN 'D28Ad'
        WHEN campaign_name LIKE '%D7IAP%' THEN 'D7IAP'
        WHEN campaign_name LIKE '%D28IAP%' THEN 'D28IAP'
        ELSE '其他'
    END as 投放类型,
    country,
    SUM(act_count) as 总激活,
    SUM(现金消耗) as 总消耗,
    AVG(ROI1) as 平均ROI1
FROM activate_performance
WHERE dt >= '2024-01-01'
GROUP BY 投放类型, country
```

### 5. 指标聚合计算规范

#### 5.1 加权平均计算
**必须使用加权平均的指标**：
- ROI（所有时间点）：ROI1, ROI2, ROI3, ..., ROI30
- 留存率：2留, 3留, 4留, 7留, 14留, 30留
- 付费率：付费率_1日, 付费率_3日, 付费率_7日, 付费率_14日, 付费率_30日

**加权方式**：
- ROI/留存率/付费率：以"现金消耗"或"激活数"为权重
- 权重选择优先级：现金消耗 > 激活数

**计算公式**：
```
加权 ROI = Σ(单条数据的 ROI × 该条数据的消耗) / Σ(该条数据的消耗)
加权留存率 = Σ(单条数据的留存率 × 该条数据的激活数) / Σ(该条数据的激活数)
```

**Python 代码示例**：
```python
import pandas as pd

# 错误做法：简单算术平均（禁止使用）
wrong_result = df.groupby(['app_name', 'media_source'])['ROI1'].mean()

# 正确做法：加权平均
def weighted_mean(group, value_col, weight_col):
    return (group[value_col] * group[weight_col]).sum() / group[weight_col].sum()

# 以消耗为权重计算加权 ROI
weighted_roi = df.groupby(['app_name', 'media_source']).apply(
    lambda g: weighted_mean(g, 'ROI1', '现金消耗')
).reset_index(name='ROI1_加权')
```

#### 5.2 CPA 聚合计算
**CPA 的正确聚合方式**：
```
聚合 CPA = 总消耗 / 总激活数
```

**Python 代码示例**：
```python
# 错误做法：简单平均（禁止使用）
wrong_cpa = df.groupby(['app_name', 'media_source'])['CPA'].mean()

# 正确做法：总消耗 / 总激活数
grouped = df.groupby(['app_name', 'media_source']).agg({
    '现金消耗': 'sum',
    'act_count': 'sum'
}).reset_index()
grouped['CPA'] = grouped['现金消耗'] / grouped['act_count']
```

#### 5.3 脚本使用限制
**当前脚本限制**：
- 脚本 `drill_analyzer.py` 仅支持简单聚合（sum, count, mean, max, min）
- 不支持加权平均、CPA 等复杂计算

**解决方案**：
- 对于需要加权平均的指标，直接在 SQL 查询中计算
- 或者先导出原始数据，使用 Python 进行复杂计算

**SQL 加权平均示例**：
```sql
-- 在 SQL 中直接计算加权 ROI
SELECT 
    app_name,
    media_source,
    SUM(现金消耗) as 总消耗,
    SUM(act_count) as 总激活,
    SUM(ROI1 * 现金消耗) / SUM(现金消耗) as 加权ROI1
FROM activate_performance
WHERE dt >= '2024-01-01'
GROUP BY app_name, media_source
```

### 6. 常见问题与解决方案

#### 问题1：指标列包含非数值字符
**错误信息**：`指标列 'xxx' 无法转换为数值类型`

**原因**：数据中包含特殊字符、逗号、货币符号等

**解决方案**：
```python
# 清洗数据示例
# 原始数据
sales_amount
¥50,000
¥30,000

# 清洗后
sales_amount
50000
30000
```

#### 问题2：维度列不存在
**错误信息**：`数据中缺少维度列: xxx`

**原因**：列名拼写错误或列名大小写不匹配

**解决方案**：
- 检查列名拼写
- 列名不区分大小写，但仍建议保持一致
- 使用数据验证脚本检查列名

#### 问题3：聚合结果为空
**可能原因**：
- 输入数据为空
- 维度列全为空值
- 过滤条件过于严格

**解决方案**：
- 检查输入数据行数
- 检查维度列的空值情况
- 简化聚合维度或调整过滤条件

#### 问题4：日期格式问题
**错误信息**：日期解析错误

**解决方案**：
```csv
# 推荐格式
date
2024-01-15

# 不推荐格式
date
15/01/2024
2024年1月15日
```

#### 问题5：Excel打开乱码
**解决方案**：
- 确保输出编码为 UTF-8-SIG
- 使用 Excel 的"导入数据"功能，选择 UTF-8 编码

### 5. 数据准备检查清单

在执行下钻分析前，请确认：

- [ ] 文件格式正确（CSV或Excel）
- [ ] 包含至少1个维度列
- [ ] 包含至少1个指标列
- [ ] 指标列全为数值类型
- [ ] 列名使用英文，无特殊字符
- [ ] 没有必需列的空值
- [ ] 日期字段格式统一
- [ ] 数据行数充足（建议 > 100 行）

## 示例

### 示例1：标准销售数据准备

**步骤1：准备CSV文件**
```csv
date,year,quarter,month,region,province,city,category,subcategory,sales_amount,order_count,profit
2024-01-15,2024,Q1,January,华东,浙江,杭州,电子产品,手机,50000,120,8000
2024-01-16,2024,Q1,January,华东,浙江,宁波,电子产品,手机,30000,80,5000
```

**步骤2：验证数据**
- 检查列名是否正确
- 检查指标列是否为数值
- 检查是否有空值

**步骤3：执行分析**
```bash
python drill_analyzer.py \
  --input sales.csv \
  --output result.csv \
  --dimensions year,quarter,region \
  --metrics sales_amount,order_count,profit \
  --agg sum
```

### 示例2：清洗异常数据

**原始数据**：
```csv
region,sales
华东,"50,000"
华南,¥30,000
```

**清洗脚本**：
```python
import pandas as pd

df = pd.read_csv('raw_data.csv')
# 移除货币符号
df['sales'] = df['sales'].str.replace('¥', '').str.replace(',', '')
# 转换为数值
df['sales'] = pd.to_numeric(df['sales'])
# 保存清洗后的数据
df.to_csv('cleaned_data.csv', index=False)
```

**清洗后数据**：
```csv
region,sales
华东,50000
华南,30000
```

## 约束与注意事项
- 所有维度和指标列必须在输入数据中存在
- 指标列必须可转换为数值类型
- 空值会被保留在聚合结果中（dropna=False）
- 大数据集建议使用分批处理或抽样分析
- 输出文件会覆盖同名文件，请确认输出路径
